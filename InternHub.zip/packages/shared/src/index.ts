export const userRoles = ["admin", "mentor", "user"] as const;
export type UserRole = (typeof userRoles)[number];

export const accountStatuses = ["active", "inactive"] as const;
export type AccountStatus = (typeof accountStatuses)[number];

export const internshipStatuses = ["active", "completed", "inactive"] as const;
export type InternshipStatus = (typeof internshipStatuses)[number];

export const reportStatuses = ["pending", "approved", "rejected"] as const;
export type ReportStatus = (typeof reportStatuses)[number];

export const scoreWeights = {
  attendance: 0.3,
  report: 0.3,
  evaluation: 0.4,
} as const;
