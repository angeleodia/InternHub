import { CanActivate, ExecutionContext, ForbiddenException, Injectable, SetMetadata } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import type { Role } from "@prisma/client";

const PUBLIC_ROUTE = "internhub:public";
const ALLOWED_ROLES = "internhub:roles";

export const PublicRoute = () => SetMetadata(PUBLIC_ROUTE, true);
export const Roles = (...roles: Role[]) => SetMetadata(ALLOWED_ROLES, roles);

@Injectable()
export class SimpleRoleGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext) {
    const isPublic = this.reflector.getAllAndOverride<boolean>(PUBLIC_ROUTE, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const roles = this.reflector.getAllAndOverride<Role[]>(ALLOWED_ROLES, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!roles?.length) return true;

    const request = context.switchToHttp().getRequest<{ headers: Record<string, string | string[] | undefined> }>();
    const roleHeader = request.headers["x-user-role"];
    const role = Array.isArray(roleHeader) ? roleHeader[0] : roleHeader;

    if (role === "admin" || role === "mentor" || role === "user") {
      if (roles.includes(role)) return true;
    }

    throw new ForbiddenException("Akses tidak tersedia untuk akun ini.");
  }
}
