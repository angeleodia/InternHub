import { createReadStream, existsSync, mkdirSync } from "node:fs";
import { basename, resolve } from "node:path";

import {
  Body,
  Controller,
  Delete,
  Get,
  Headers,
  NotFoundException,
  Param,
  Patch,
  Post,
  Query,
  StreamableFile,
  UploadedFile,
  UploadedFiles,
  UseInterceptors,
} from "@nestjs/common";
import { FileInterceptor, FilesInterceptor } from "@nestjs/platform-express";
import { diskStorage } from "multer";

import { AppService, type RequestActor } from "./app.service";
import { PublicRoute, Roles } from "./simple-role.guard";

const laporanUploadDir = resolve(process.cwd(), "apps/api/uploads/laporan");
const tugasUploadDir = resolve(process.cwd(), "apps/api/uploads/tugas");
mkdirSync(laporanUploadDir, { recursive: true });
mkdirSync(tugasUploadDir, { recursive: true });

const safeFilename = (_req: unknown, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) => {
  const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "-");
  cb(null, `${Date.now()}-${Math.floor(Math.random() * 1000)}-${safeName}`);
};

const uploadInterceptor = FileInterceptor("lampiranFile", {
  storage: diskStorage({ destination: laporanUploadDir, filename: safeFilename }),
});

const tugasUploadInterceptor = FilesInterceptor("lampiranFiles", 10, {
  storage: diskStorage({ destination: tugasUploadDir, filename: safeFilename }),
});

type HeadersMap = Record<string, string | string[] | undefined>;

function headerValue(headers: HeadersMap, key: string) {
  const value = headers[key];
  return Array.isArray(value) ? value[0] : value;
}

function actorFromHeaders(headers: HeadersMap): RequestActor {
  const role = headerValue(headers, "x-user-role");
  return {
    role: role === "admin" || role === "mentor" || role === "user" ? role : undefined,
    email: headerValue(headers, "x-user-email")?.toLowerCase(),
    pesertaId: headerValue(headers, "x-peserta-id"),
    mentorId: headerValue(headers, "x-mentor-id"),
  };
}

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get("health")
  @PublicRoute()
  getHealth() {
    return this.appService.getHealth();
  }

  @Post("auth/login")
  @PublicRoute()
  login(@Body() body: { email?: string; password?: string }) {
    return this.appService.login(body);
  }

  @Get("reference")
  @Roles("admin", "mentor", "user")
  getReferenceData() {
    return this.appService.getReferenceData();
  }

  @Get("institusi")
  @Roles("admin", "mentor", "user")
  listInstitusi() {
    return this.appService.listInstitusi();
  }

  @Get("periode")
  @Roles("admin", "mentor", "user")
  listPeriode() {
    return this.appService.listPeriode();
  }

  @Get("mentor")
  @Roles("admin", "mentor", "user")
  listMentor() {
    return this.appService.listMentor();
  }

  @Get("peserta")
  @Roles("admin", "mentor", "user")
  listPeserta(@Query() query: Record<string, string>, @Headers() headers: HeadersMap) {
    return this.appService.listPeserta(query, actorFromHeaders(headers));
  }

  @Post("peserta")
  @Roles("admin")
  createPeserta(@Body() body: Record<string, unknown>) {
    return this.appService.createPeserta(body as never);
  }

  @Patch("peserta/:id")
  @Roles("admin")
  updatePeserta(@Param("id") id: string, @Body() body: Record<string, unknown>) {
    return this.appService.updatePeserta(id, body as never);
  }

  @Delete("peserta/:id")
  @Roles("admin")
  deletePeserta(@Param("id") id: string) {
    return this.appService.deletePeserta(id);
  }

  @Get("akun")
  @Roles("admin")
  listAkun() {
    return this.appService.listAkun();
  }

  @Post("akun")
  @Roles("admin")
  createAkun(@Body() body: Record<string, unknown>) {
    return this.appService.createAkun(body as never);
  }

  @Patch("akun/:id")
  @Roles("admin")
  updateAkun(@Param("id") id: string, @Body() body: Record<string, unknown>) {
    return this.appService.updateAkun(id, body as never);
  }

  @Patch("akun/:id/toggle-status")
  @Roles("admin")
  toggleAkunStatus(@Param("id") id: string) {
    return this.appService.toggleAkunStatus(id);
  }

  @Delete("akun/:id")
  @Roles("admin")
  deleteAkun(@Param("id") id: string) {
    return this.appService.deleteAkun(id);
  }

  @Get("absensi")
  @Roles("admin", "mentor", "user")
  listAbsensi(@Query() query: Record<string, string>, @Headers() headers: HeadersMap) {
    return this.appService.listAbsensi(query, actorFromHeaders(headers));
  }

  @Post("absensi")
  @Roles("user")
  createAbsensi(@Body() body: { pesertaId?: string; tanggal?: string }, @Headers() headers: HeadersMap) {
    return this.appService.createAbsensi(body, actorFromHeaders(headers));
  }

  @Get("laporan")
  @Roles("admin", "mentor", "user")
  listLaporan(@Query() query: Record<string, string>, @Headers() headers: HeadersMap) {
    return this.appService.listLaporan(query, actorFromHeaders(headers));
  }

  @Post("laporan")
  @Roles("user")
  @UseInterceptors(uploadInterceptor)
  createLaporan(
    @Body() body: Record<string, unknown>,
    @UploadedFile() file: Express.Multer.File | undefined,
    @Headers() headers: HeadersMap,
  ) {
    return this.appService.createLaporan(body as never, file, actorFromHeaders(headers));
  }

  @Patch("laporan/:id")
  @Roles("user")
  @UseInterceptors(uploadInterceptor)
  updateLaporan(
    @Param("id") id: string,
    @Body() body: Record<string, unknown>,
    @UploadedFile() file: Express.Multer.File | undefined,
    @Headers() headers: HeadersMap,
  ) {
    return this.appService.updateLaporan(id, body as never, file, actorFromHeaders(headers));
  }

  @Patch("laporan/:id/review")
  @Roles("mentor")
  reviewLaporan(
    @Param("id") id: string,
    @Body() body: { status?: "Menunggu" | "Approved" | "Rejected"; nilai?: number; komentar?: string },
    @Headers() headers: HeadersMap,
  ) {
    return this.appService.reviewLaporan(id, body, actorFromHeaders(headers));
  }

  @Get("uploads/laporan/:filename")
  @PublicRoute()
  getUploadedLaporan(@Param("filename") filename: string) {
    const safeName = basename(filename);
    const path = resolve(laporanUploadDir, safeName);
    if (!path.startsWith(laporanUploadDir) || !existsSync(path)) {
      throw new NotFoundException("Lampiran tidak ditemukan.");
    }
    return new StreamableFile(createReadStream(path));
  }

  @Get("tugas")
  @Roles("admin", "mentor", "user")
  listTugas(@Query() query: Record<string, string>, @Headers() headers: HeadersMap) {
    return this.appService.listTugas(query, actorFromHeaders(headers));
  }

  @Post("tugas")
  @Roles("mentor")
  createTugas(@Body() body: Record<string, unknown>, @Headers() headers: HeadersMap) {
    return this.appService.createTugas(body as never, actorFromHeaders(headers));
  }

  @Patch("tugas/:id")
  @Roles("mentor")
  updateTugas(@Param("id") id: string, @Body() body: Record<string, unknown>, @Headers() headers: HeadersMap) {
    return this.appService.updateTugas(id, body as never, actorFromHeaders(headers));
  }

  @Patch("tugas/:id/review")
  @Roles("mentor")
  reviewTugas(
    @Param("id") id: string,
    @Body() body: { status?: "Ditugaskan" | "Dikerjakan" | "Revisi" | "Selesai"; nilai?: number; komentar?: string },
    @Headers() headers: HeadersMap,
  ) {
    return this.appService.reviewTugas(id, body, actorFromHeaders(headers));
  }

  @Delete("tugas/progres/:id")
  @Roles("user")
  deleteTugasProgres(@Param("id") id: string, @Headers() headers: HeadersMap) {
    return this.appService.deleteTugasProgres(id, actorFromHeaders(headers));
  }

  @Delete("tugas/:id")
  @Roles("mentor")
  deleteTugas(@Param("id") id: string, @Headers() headers: HeadersMap) {
    return this.appService.deleteTugas(id, actorFromHeaders(headers));
  }

  @Patch("subtugas/:id/status")
  @Roles("mentor")
  reviewSubTugas(
    @Param("id") id: string,
    @Body() body: { status?: "Ditugaskan" | "Dikerjakan" | "Revisi" | "Selesai" },
    @Headers() headers: HeadersMap,
  ) {
    return this.appService.reviewSubTugas(id, body, actorFromHeaders(headers));
  }

  @Post("tugas/:id/progres")
  @Roles("user")
  @UseInterceptors(tugasUploadInterceptor)
  createTugasProgres(
    @Param("id") id: string,
    @Body() body: { ringkasan?: string; links?: string },
    @UploadedFiles() files: Express.Multer.File[] | undefined,
    @Headers() headers: HeadersMap,
  ) {
    return this.appService.createTugasProgres(id, body, files ?? [], actorFromHeaders(headers));
  }

  @Get("uploads/tugas/:filename")
  @PublicRoute()
  getUploadedTugas(@Param("filename") filename: string) {
    const safeName = basename(filename);
    const path = resolve(tugasUploadDir, safeName);
    if (!path.startsWith(tugasUploadDir) || !existsSync(path)) {
      throw new NotFoundException("Lampiran tidak ditemukan.");
    }
    return new StreamableFile(createReadStream(path));
  }

  @Get("evaluasi")
  @Roles("admin", "mentor", "user")
  listEvaluasi(@Query() query: Record<string, string>, @Headers() headers: HeadersMap) {
    return this.appService.listEvaluasi(query, actorFromHeaders(headers));
  }

  @Post("evaluasi")
  @Roles("mentor")
  createEvaluasi(@Body() body: Record<string, unknown>, @Headers() headers: HeadersMap) {
    return this.appService.createEvaluasi(body as never, actorFromHeaders(headers));
  }

  @Get("nilai")
  @Roles("admin", "mentor", "user")
  listNilai(@Headers() headers: HeadersMap) {
    return this.appService.listNilai(actorFromHeaders(headers));
  }

  @Get("nilai/:pesertaId")
  @Roles("admin", "mentor", "user")
  getNilaiAkhir(@Param("pesertaId") pesertaId: string, @Headers() headers: HeadersMap) {
    return this.appService.getNilaiAkhir(pesertaId, actorFromHeaders(headers));
  }

  @Get("ranking")
  @Roles("admin")
  getRanking(@Query("periodeId") periodeId?: string) {
    return this.appService.getRanking(periodeId);
  }

  @Get("dashboard/admin")
  @Roles("admin")
  getAdminDashboard() {
    return this.appService.getAdminDashboard();
  }

  @Get("dashboard/mentor/:mentorId")
  @Roles("mentor")
  getMentorDashboard(@Param("mentorId") mentorId: string, @Headers() headers: HeadersMap) {
    return this.appService.getMentorDashboard(mentorId, actorFromHeaders(headers));
  }

  @Get("dashboard/user/:pesertaId")
  @Roles("user")
  getUserDashboard(@Param("pesertaId") pesertaId: string, @Headers() headers: HeadersMap) {
    return this.appService.getUserDashboard(pesertaId, actorFromHeaders(headers));
  }
}
