import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import type {
  Absensi,
  Akun,
  Evaluasi,
  Institusi,
  Laporan,
  Mentor,
  Periode,
  Peserta,
  Role,
  StatusAkun,
  StatusLaporan,
  StatusMagang,
  StatusTugas,
  SubTugas,
  TipeLampiran,
  Tugas,
  TugasLampiran,
  TugasProgres,
} from "@prisma/client";

import { PrismaService } from "./prisma.service";

type IdQuery = {
  id?: string;
  pesertaId?: string;
  mentorId?: string;
  institusiId?: string;
  periodeId?: string;
  status?: string;
  tanggal?: string;
};

type NilaiAkhir = {
  pesertaId: string;
  kehadiran: number;
  tugas: number;
  evaluasi: number;
  akhir: number;
};

export type RequestActor = {
  role?: Role;
  email?: string;
  pesertaId?: string;
  mentorId?: string;
};

type AkunWithMentor = Akun & { mentor?: Mentor | null };
type AkunPayload = Partial<Akun> & {
  departemen?: string;
  telepon?: string;
};
type LaporanUpload = {
  filename: string;
  originalname: string;
};

type LinkInput = { url?: string; nama?: string };

type TugasPayload = {
  pesertaId?: string;
  judul?: string;
  deskripsi?: string;
  tanggalMulai?: string;
  tanggalSelesai?: string;
  subTugas?: Array<{
    id?: string;
    judul?: string;
    tanggalMulai?: string | null;
    tanggalSelesai?: string | null;
  }>;
};

type TugasWithRelasi = Tugas & {
  subTugas?: SubTugas[];
  progres?: (TugasProgres & { lampiran?: TugasLampiran[] })[];
};

const dateOnly = (value: Date | string) => new Date(value).toISOString().slice(0, 10);
const toDbDate = (value?: string) => new Date(`${value ?? dateOnly(new Date())}T00:00:00.000Z`);
const todayStr = () => dateOnly(new Date());
const makeId = (prefix: string) => `${prefix}${Date.now()}${Math.floor(Math.random() * 1000)}`;
const uploadPath = (file?: LaporanUpload) => (file ? `/uploads/laporan/${file.filename}` : undefined);
const tugasUploadPath = (file: LaporanUpload) => `/uploads/tugas/${file.filename}`;
const stripHtml = (value?: string) => (value ?? "").replace(/<[^>]*>/g, "").replace(/&nbsp;/g, " ").trim();
const parseLinks = (raw: unknown): LinkInput[] => {
  if (!raw) return [];
  let value: unknown = raw;
  if (typeof raw === "string") {
    try {
      value = JSON.parse(raw);
    } catch {
      return [];
    }
  }
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => (typeof item === "string" ? { url: item } : (item as LinkInput)))
    .filter((item) => typeof item.url === "string" && item.url.trim().length > 0);
};
const nowTime = () => {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
};

@Injectable()
export class AppService {
  constructor(private readonly prisma: PrismaService) {}

  getHealth() {
    return {
      status: "ok",
      service: "internhub-api",
      storage: "mysql-prisma",
      timestamp: new Date().toISOString(),
    };
  }

  async login(body: { email?: string; password?: string }) {
    const email = body.email?.trim().toLowerCase();
    const password = body.password ?? "";
    if (!email || !password) return { error: "Email dan password wajib diisi." };

    const akun = await this.prisma.akun.findUnique({ where: { email } });
    if (!akun || akun.password !== password) return { error: "Email atau password tidak valid." };
    if (akun.status === "Nonaktif") return { error: "Akun nonaktif. Hubungi admin." };

    const role = akun.role;
    const user: { role: Role; nama: string; email: string; pesertaId?: string; mentorId?: string } = {
      role,
      nama: akun.nama,
      email: akun.email,
    };

    if (role === "mentor") {
      const mentor = await this.prisma.mentor.findFirst({
        where: { OR: [{ akunId: akun.id }, { email: akun.email }] },
      });
      user.mentorId = mentor?.id;
      if (mentor) user.nama = mentor.nama;
    }

    if (role === "user") {
      const peserta = await this.prisma.peserta.findFirst({
        where: { OR: [{ akunId: akun.id }, { email: akun.email }] },
      });
      user.pesertaId = peserta?.id;
      if (peserta) user.nama = peserta.nama;
    }

    return { error: null, role, user };
  }

  async getReferenceData() {
    const [institusi, periode, mentor] = await Promise.all([
      this.prisma.institusi.findMany({ orderBy: { nama: "asc" } }),
      this.prisma.periode.findMany({ orderBy: { mulai: "desc" } }),
      this.prisma.mentor.findMany({ orderBy: { nama: "asc" } }),
    ]);

    return {
      institusi: institusi.map(this.mapInstitusi),
      periode: periode.map(this.mapPeriode),
      mentor: mentor.map(this.mapMentor),
    };
  }

  async listInstitusi() {
    return (await this.prisma.institusi.findMany({ orderBy: { nama: "asc" } })).map(this.mapInstitusi);
  }

  async listPeriode() {
    return (await this.prisma.periode.findMany({ orderBy: { mulai: "desc" } })).map(this.mapPeriode);
  }

  async listMentor() {
    return (await this.prisma.mentor.findMany({ orderBy: { nama: "asc" } })).map(this.mapMentor);
  }

  async listPeserta(query: IdQuery, actor?: RequestActor) {
    const data = await this.prisma.peserta.findMany({
      where: {
        id: actor?.role === "user" ? actor.pesertaId : query.id,
        mentorId: actor?.role === "mentor" ? actor.mentorId : query.mentorId,
        periodeId: query.periodeId,
        institusiId: query.institusiId,
        status: query.status as StatusMagang | undefined,
      },
      orderBy: { nama: "asc" },
    });
    return data.map(this.mapPeserta);
  }

  async createPeserta(body: Partial<Peserta>) {
    this.requireFields(body, ["nama", "email", "telepon", "institusiId", "programStudi", "periodeId", "mentorId"]);
    const peserta = await this.prisma.peserta.create({
      data: {
        id: body.id ?? makeId("u"),
        akunId: body.akunId,
        nama: body.nama!,
        email: body.email!,
        telepon: body.telepon!,
        institusiId: body.institusiId!,
        programStudi: body.programStudi!,
        periodeId: body.periodeId!,
        mentorId: body.mentorId!,
        status: (body.status as StatusMagang | undefined) ?? "Aktif",
      },
    });
    return this.mapPeserta(peserta);
  }

  async updatePeserta(id: string, body: Partial<Peserta>) {
    await this.ensurePeserta(id);
    const peserta = await this.prisma.peserta.update({
      where: { id },
      data: {
        nama: body.nama,
        email: body.email,
        telepon: body.telepon,
        institusiId: body.institusiId,
        programStudi: body.programStudi,
        periodeId: body.periodeId,
        mentorId: body.mentorId,
        status: body.status as StatusMagang | undefined,
      },
    });
    return this.mapPeserta(peserta);
  }

  async deletePeserta(id: string) {
    await this.ensurePeserta(id);
    await this.prisma.peserta.delete({ where: { id } });
    return { success: true };
  }

  async listAkun() {
    return (
      await this.prisma.akun.findMany({
        include: { mentor: true },
        orderBy: { dibuat: "desc" },
      })
    ).map(this.mapAkun);
  }

  async createAkun(body: AkunPayload) {
    this.requireFields(body, ["nama", "email", "role", "password"]);
    const akun = await this.prisma.akun.create({
      data: {
        id: body.id ?? makeId("a"),
        nama: body.nama!,
        email: body.email!,
        role: body.role as Role,
        status: (body.status as StatusAkun | undefined) ?? "Aktif",
        password: body.password!,
        dibuat: body.dibuat ? toDbDate(String(body.dibuat)) : new Date(),
      },
    });
    if (akun.role === "mentor") {
      await this.upsertMentorProfile(akun, body);
    }
    return this.mapAkun(await this.getAkunWithMentor(akun.id));
  }

  async updateAkun(id: string, body: AkunPayload) {
    await this.ensureAkun(id);
    const akun = await this.prisma.akun.update({
      where: { id },
      data: {
        nama: body.nama,
        email: body.email,
        role: body.role as Role | undefined,
        status: body.status as StatusAkun | undefined,
        password: body.password,
      },
    });
    if (akun.role === "mentor") {
      await this.upsertMentorProfile(akun, body);
    }
    return this.mapAkun(await this.getAkunWithMentor(akun.id));
  }

  async toggleAkunStatus(id: string) {
    const akun = await this.ensureAkun(id);
    const updated = await this.prisma.akun.update({
      where: { id },
      data: { status: akun.status === "Aktif" ? "Nonaktif" : "Aktif" },
    });
    return this.mapAkun(await this.getAkunWithMentor(updated.id));
  }

  async deleteAkun(id: string) {
    await this.ensureAkun(id);
    const mentor = await this.prisma.mentor.findUnique({ where: { akunId: id } });
    if (mentor) {
      const totalPeserta = await this.prisma.peserta.count({ where: { mentorId: mentor.id } });
      if (totalPeserta === 0) {
        await this.prisma.mentor.delete({ where: { id: mentor.id } });
      }
    }
    await this.prisma.akun.delete({ where: { id } });
    return { success: true };
  }

  async listAbsensi(query: IdQuery, actor?: RequestActor) {
    const data = await this.prisma.absensi.findMany({
      where: {
        pesertaId: actor?.role === "user" ? actor.pesertaId : query.pesertaId,
        tanggal: query.tanggal ? toDbDate(query.tanggal) : undefined,
        peserta: {
          periodeId: query.periodeId,
          mentorId: actor?.role === "mentor" ? actor.mentorId : undefined,
        },
      },
      orderBy: [{ tanggal: "desc" }, { jam: "desc" }],
    });
    return data.map(this.mapAbsensi);
  }

  async createAbsensi(body: { pesertaId?: string; tanggal?: string }, actor?: RequestActor) {
    if (!body.pesertaId) throw new BadRequestException("pesertaId wajib diisi.");
    if (actor?.role === "user" && actor.pesertaId !== body.pesertaId) {
      throw new ForbiddenException("Peserta hanya dapat mengisi absensi sendiri.");
    }
    await this.ensurePeserta(body.pesertaId);

    const tanggal = body.tanggal ?? todayStr();
    const day = new Date(`${tanggal}T00:00:00.000Z`).getUTCDay();
    if (day === 0 || day === 6) throw new BadRequestException("Absensi hanya tersedia pada hari kerja.");

    const existing = await this.prisma.absensi.findFirst({
      where: { pesertaId: body.pesertaId, tanggal: toDbDate(tanggal) },
    });
    if (existing) throw new BadRequestException("Absensi hari ini sudah tercatat.");

    const absensi = await this.prisma.absensi.create({
      data: {
        id: makeId("abs"),
        pesertaId: body.pesertaId,
        tanggal: toDbDate(tanggal),
        jam: nowTime(),
      },
    });
    await this.getNilaiAkhir(body.pesertaId);
    return this.mapAbsensi(absensi);
  }

  async listLaporan(query: IdQuery, actor?: RequestActor) {
    const data = await this.prisma.laporan.findMany({
      where: {
        pesertaId: actor?.role === "user" ? actor.pesertaId : query.pesertaId,
        mentorId: actor?.role === "mentor" ? actor.mentorId : query.mentorId,
        status: query.status as StatusLaporan | undefined,
        tanggal: query.tanggal ? toDbDate(query.tanggal) : undefined,
        peserta: query.periodeId ? { periodeId: query.periodeId } : undefined,
      },
      orderBy: [{ tanggal: "desc" }, { createdAt: "desc" }],
    });
    return data.map(this.mapLaporan);
  }

  async createLaporan(body: Partial<Laporan>, file?: LaporanUpload, actor?: RequestActor) {
    this.requireFields(body, ["pesertaId", "mentorId", "tanggal", "deskripsi"]);
    if (!body.deskripsi?.trim()) throw new BadRequestException("Deskripsi kegiatan wajib diisi.");
    if (actor?.role === "user" && actor.pesertaId !== body.pesertaId) {
      throw new ForbiddenException("Peserta hanya dapat mengirim laporan sendiri.");
    }

    const existing = await this.prisma.laporan.findFirst({
      where: { pesertaId: body.pesertaId!, tanggal: toDbDate(String(body.tanggal)) },
    });
    if (existing) throw new BadRequestException("Laporan untuk tanggal ini sudah ada.");

    const laporan = await this.prisma.laporan.create({
      data: {
        id: body.id ?? makeId("lap"),
        pesertaId: body.pesertaId!,
        mentorId: body.mentorId!,
        tanggal: toDbDate(String(body.tanggal)),
        deskripsi: body.deskripsi,
        lampiran: uploadPath(file) ?? body.lampiran,
        status: "Menunggu",
      },
    });
    return this.mapLaporan(laporan);
  }

  async updateLaporan(id: string, body: Partial<Laporan>, file?: LaporanUpload, actor?: RequestActor) {
    const current = await this.ensureLaporan(id);
    if (actor?.role === "user" && actor.pesertaId !== current.pesertaId) {
      throw new ForbiddenException("Peserta hanya dapat memperbarui laporan sendiri.");
    }
    if (current.status === "Approved" && (body.deskripsi || body.lampiran)) {
      throw new BadRequestException("Laporan approved tidak dapat diubah.");
    }

    const laporan = await this.prisma.laporan.update({
      where: { id },
      data: {
        deskripsi: body.deskripsi,
        lampiran: uploadPath(file) ?? body.lampiran,
        status: body.status as StatusLaporan | undefined,
        nilai: body.nilai,
        komentar: body.komentar,
      },
    });
    return this.mapLaporan(laporan);
  }

  async reviewLaporan(id: string, body: { status?: StatusLaporan; nilai?: number; komentar?: string }, actor?: RequestActor) {
    const current = await this.ensureLaporan(id);
    if (actor?.role === "mentor" && actor.mentorId !== current.mentorId) {
      throw new ForbiddenException("Mentor hanya dapat meninjau laporan peserta bimbingan.");
    }
    const status = body.status;
    if (status !== "Approved" && status !== "Rejected") {
      throw new BadRequestException("Status review harus Approved atau Rejected.");
    }
    if (status === "Approved" && (body.nilai == null || body.nilai < 1 || body.nilai > 100)) {
      throw new BadRequestException("Nilai wajib 1-100 untuk laporan Approved.");
    }
    if (status === "Rejected" && !body.komentar?.trim()) {
      throw new BadRequestException("Komentar wajib diisi untuk laporan Rejected.");
    }

    const laporan = await this.prisma.laporan.update({
      where: { id },
      data: {
        status,
        nilai: status === "Approved" ? body.nilai : null,
        komentar: body.komentar,
        reviewedAt: new Date(),
      },
    });
    await this.getNilaiAkhir(laporan.pesertaId);
    return this.mapLaporan(laporan);
  }

  // ===== Tugas: mentor meng-assign, peserta melaporkan progres, mentor menilai =====

  async listTugas(query: IdQuery, actor?: RequestActor) {
    const data = await this.prisma.tugas.findMany({
      where: {
        pesertaId: actor?.role === "user" ? actor.pesertaId : query.pesertaId,
        mentorId: actor?.role === "mentor" ? actor.mentorId : query.mentorId,
        status: query.status as StatusTugas | undefined,
        peserta: query.periodeId ? { periodeId: query.periodeId } : undefined,
      },
      include: {
        subTugas: { orderBy: { urutan: "asc" } },
        progres: { include: { lampiran: true }, orderBy: { createdAt: "desc" } },
      },
      orderBy: [{ createdAt: "desc" }],
    });
    return data.map((item) => this.mapTugas(item));
  }

  async createTugas(body: TugasPayload, actor?: RequestActor) {
    this.requireFields(body, ["pesertaId", "judul", "deskripsi", "tanggalMulai", "tanggalSelesai"]);
    if (!stripHtml(body.deskripsi)) throw new BadRequestException("Deskripsi tugas wajib diisi.");
    const peserta = await this.ensurePeserta(body.pesertaId!);
    const mentorId = actor?.role === "mentor" ? actor.mentorId : peserta.mentorId;
    if (!mentorId) throw new BadRequestException("Mentor pembimbing tidak diketahui.");
    if (actor?.role === "mentor" && peserta.mentorId !== actor.mentorId) {
      throw new ForbiddenException("Mentor hanya dapat memberi tugas ke peserta bimbingan.");
    }
    this.validateRange(body.tanggalMulai, body.tanggalSelesai);

    const subTugas = (body.subTugas ?? [])
      .filter((item) => item.judul?.trim())
      .map((item, index) => ({
        id: makeId("st"),
        judul: item.judul!.trim(),
        tanggalMulai: item.tanggalMulai ? toDbDate(item.tanggalMulai) : null,
        tanggalSelesai: item.tanggalSelesai ? toDbDate(item.tanggalSelesai) : null,
        urutan: index,
      }));

    const tugas = await this.prisma.tugas.create({
      data: {
        id: makeId("tg"),
        pesertaId: body.pesertaId!,
        mentorId,
        judul: body.judul!.trim(),
        deskripsi: body.deskripsi!,
        tanggalMulai: toDbDate(body.tanggalMulai),
        tanggalSelesai: toDbDate(body.tanggalSelesai),
        status: "Ditugaskan",
        subTugas: subTugas.length ? { create: subTugas } : undefined,
      },
      include: {
        subTugas: { orderBy: { urutan: "asc" } },
        progres: { include: { lampiran: true }, orderBy: { createdAt: "desc" } },
      },
    });
    return this.mapTugas(tugas);
  }

  async updateTugas(id: string, body: TugasPayload, actor?: RequestActor) {
    const current = await this.ensureTugas(id);
    if (actor?.role === "mentor" && actor.mentorId !== current.mentorId) {
      throw new ForbiddenException("Mentor hanya dapat mengubah tugas yang dibuatnya.");
    }
    if (body.deskripsi != null && !stripHtml(body.deskripsi)) {
      throw new BadRequestException("Deskripsi tugas wajib diisi.");
    }
    this.validateRange(
      body.tanggalMulai ?? dateOnly(current.tanggalMulai),
      body.tanggalSelesai ?? dateOnly(current.tanggalSelesai),
    );

    await this.prisma.tugas.update({
      where: { id },
      data: {
        judul: body.judul?.trim(),
        deskripsi: body.deskripsi,
        tanggalMulai: body.tanggalMulai ? toDbDate(body.tanggalMulai) : undefined,
        tanggalSelesai: body.tanggalSelesai ? toDbDate(body.tanggalSelesai) : undefined,
      },
    });

    if (body.subTugas) await this.reconcileSubTugas(id, body.subTugas);
    return this.mapTugas(await this.getTugasWithRelasi(id));
  }

  async reviewTugas(id: string, body: { status?: StatusTugas; nilai?: number; komentar?: string }, actor?: RequestActor) {
    const current = await this.ensureTugas(id);
    if (actor?.role === "mentor" && actor.mentorId !== current.mentorId) {
      throw new ForbiddenException("Mentor hanya dapat meninjau tugas yang dibuatnya.");
    }
    const status = body.status;
    if (!status || !["Ditugaskan", "Dikerjakan", "Revisi", "Selesai"].includes(status)) {
      throw new BadRequestException("Status tugas tidak valid.");
    }
    if (status === "Selesai" && (body.nilai == null || body.nilai < 1 || body.nilai > 100)) {
      throw new BadRequestException("Nilai wajib 1-100 saat menandai tugas Selesai.");
    }
    if (status === "Revisi" && !body.komentar?.trim()) {
      throw new BadRequestException("Catatan revisi wajib diisi.");
    }

    const tugas = await this.prisma.tugas.update({
      where: { id },
      data: {
        status,
        nilai: status === "Selesai" ? body.nilai : null,
        komentar: body.komentar?.trim() || null,
        reviewedAt: new Date(),
      },
      include: {
        subTugas: { orderBy: { urutan: "asc" } },
        progres: { include: { lampiran: true }, orderBy: { createdAt: "desc" } },
      },
    });
    await this.getNilaiAkhir(tugas.pesertaId);
    return this.mapTugas(tugas);
  }

  async deleteTugas(id: string, actor?: RequestActor) {
    const current = await this.ensureTugas(id);
    if (actor?.role === "mentor" && actor.mentorId !== current.mentorId) {
      throw new ForbiddenException("Mentor hanya dapat menghapus tugas yang dibuatnya.");
    }
    await this.prisma.tugas.delete({ where: { id } });
    await this.getNilaiAkhir(current.pesertaId);
    return { success: true };
  }

  async reviewSubTugas(id: string, body: { status?: StatusTugas }, actor?: RequestActor) {
    const sub = await this.prisma.subTugas.findUnique({ where: { id }, include: { tugas: true } });
    if (!sub) throw new NotFoundException("Sub-tugas tidak ditemukan.");
    if (actor?.role === "mentor" && actor.mentorId !== sub.tugas.mentorId) {
      throw new ForbiddenException("Mentor hanya dapat mengubah sub-tugas miliknya.");
    }
    const status = body.status;
    if (!status || !["Ditugaskan", "Dikerjakan", "Revisi", "Selesai"].includes(status)) {
      throw new BadRequestException("Status sub-tugas tidak valid.");
    }
    await this.prisma.subTugas.update({ where: { id }, data: { status } });
    return this.mapTugas(await this.getTugasWithRelasi(sub.tugasId));
  }

  async createTugasProgres(
    tugasId: string,
    body: { ringkasan?: string; links?: unknown },
    files: LaporanUpload[],
    actor?: RequestActor,
  ) {
    const tugas = await this.ensureTugas(tugasId);
    if (actor?.role === "user" && actor.pesertaId !== tugas.pesertaId) {
      throw new ForbiddenException("Peserta hanya dapat melaporkan progres tugasnya sendiri.");
    }
    if (tugas.status === "Selesai") {
      throw new BadRequestException("Tugas sudah Selesai dan tidak menerima progres baru.");
    }
    if (!stripHtml(body.ringkasan)) {
      throw new BadRequestException("Ringkasan progres wajib diisi.");
    }
    const links = parseLinks(body.links);

    await this.prisma.tugasProgres.create({
      data: {
        id: makeId("pg"),
        tugasId,
        pesertaId: tugas.pesertaId,
        ringkasan: body.ringkasan!,
        lampiran: {
          create: [
            ...files.map((file) => ({
              id: makeId("att"),
              tipe: "File" as TipeLampiran,
              url: tugasUploadPath(file),
              nama: file.originalname,
            })),
            ...links.map((link) => ({
              id: makeId("att"),
              tipe: "Link" as TipeLampiran,
              url: link.url!.trim(),
              nama: link.nama?.trim() || link.url!.trim(),
            })),
          ],
        },
      },
    });
    return this.mapTugas(await this.getTugasWithRelasi(tugasId));
  }

  async deleteTugasProgres(id: string, actor?: RequestActor) {
    const progres = await this.prisma.tugasProgres.findUnique({ where: { id }, include: { tugas: true } });
    if (!progres) throw new NotFoundException("Progres tidak ditemukan.");
    if (actor?.role === "user" && actor.pesertaId !== progres.pesertaId) {
      throw new ForbiddenException("Peserta hanya dapat menghapus progresnya sendiri.");
    }
    if (progres.tugas.status === "Selesai") {
      throw new BadRequestException("Progres pada tugas yang sudah Selesai tidak dapat dihapus.");
    }
    await this.prisma.tugasProgres.delete({ where: { id } });
    return this.mapTugas(await this.getTugasWithRelasi(progres.tugasId));
  }

  async listEvaluasi(query: IdQuery, actor?: RequestActor) {
    const data = await this.prisma.evaluasi.findMany({
      where: {
        pesertaId: actor?.role === "user" ? actor.pesertaId : query.pesertaId,
        mentorId: actor?.role === "mentor" ? actor.mentorId : query.mentorId,
      },
      orderBy: { tanggal: "desc" },
    });
    return data.map(this.mapEvaluasi);
  }

  async createEvaluasi(body: Partial<Evaluasi>, actor?: RequestActor) {
    this.requireFields(body, ["pesertaId", "mentorId", "nilai", "komentar"]);
    const peserta = await this.ensurePeserta(body.pesertaId!);
    if (actor?.role === "mentor" && (actor.mentorId !== body.mentorId || actor.mentorId !== peserta.mentorId)) {
      throw new ForbiddenException("Mentor hanya dapat mengisi evaluasi peserta bimbingan.");
    }
    if (peserta.status !== "Selesai") {
      throw new BadRequestException("Evaluasi akhir tersedia setelah periode magang selesai.");
    }
    if (body.nilai == null || body.nilai < 1 || body.nilai > 100) {
      throw new BadRequestException("Nilai evaluasi harus 1-100.");
    }
    if (await this.prisma.evaluasi.findUnique({ where: { pesertaId: body.pesertaId! } })) {
      throw new BadRequestException("Evaluasi akhir hanya bisa dilakukan satu kali per peserta.");
    }

    const evaluasi = await this.prisma.evaluasi.create({
      data: {
        id: body.id ?? makeId("e"),
        pesertaId: body.pesertaId!,
        mentorId: body.mentorId!,
        nilai: body.nilai,
        komentar: body.komentar!,
        tanggal: body.tanggal ? toDbDate(String(body.tanggal)) : toDbDate(),
      },
    });
    await this.getNilaiAkhir(evaluasi.pesertaId);
    return this.mapEvaluasi(evaluasi);
  }

  async getNilaiAkhir(pesertaId: string, actor?: RequestActor): Promise<NilaiAkhir> {
    const peserta = await this.ensurePeserta(pesertaId);
    if (actor?.role === "user" && actor.pesertaId !== pesertaId) {
      throw new ForbiddenException("Peserta hanya dapat melihat nilai sendiri.");
    }
    if (actor?.role === "mentor" && actor.mentorId !== peserta.mentorId) {
      throw new ForbiddenException("Mentor hanya dapat melihat nilai peserta bimbingan.");
    }
    const [hadir, tugasSelesai, evaluasi] = await Promise.all([
      this.prisma.absensi.count({ where: { pesertaId } }),
      this.prisma.tugas.findMany({
        where: { pesertaId, status: "Selesai", nilai: { not: null } },
        select: { nilai: true },
      }),
      this.prisma.evaluasi.findUnique({ where: { pesertaId } }),
    ]);

    const totalHari = 20;
    const kehadiran = Math.min(100, Math.round((hadir / totalHari) * 100));
    const tugas = tugasSelesai.length
      ? Math.round(tugasSelesai.reduce((sum, item) => sum + (item.nilai ?? 0), 0) / tugasSelesai.length)
      : 0;
    const nilaiEvaluasi = evaluasi?.nilai ?? 0;
    const akhir = Math.round(kehadiran * 0.3 + tugas * 0.3 + nilaiEvaluasi * 0.4);

    await this.prisma.finalScore.upsert({
      where: { pesertaId },
      update: {
        attendanceScore: kehadiran,
        reportScore: tugas,
        evaluationScore: nilaiEvaluasi,
        finalScore: akhir,
        calculatedAt: new Date(),
      },
      create: {
        id: makeId("fs"),
        pesertaId,
        attendanceScore: kehadiran,
        reportScore: tugas,
        evaluationScore: nilaiEvaluasi,
        finalScore: akhir,
      },
    });

    return { pesertaId, kehadiran, tugas, evaluasi: nilaiEvaluasi, akhir };
  }

  async listNilai(actor?: RequestActor) {
    const peserta = await this.prisma.peserta.findMany({
      where: {
        id: actor?.role === "user" ? actor.pesertaId : undefined,
        mentorId: actor?.role === "mentor" ? actor.mentorId : undefined,
      },
      orderBy: { nama: "asc" },
    });
    return Promise.all(
      peserta.map(async (item) => ({
        ...this.mapPeserta(item),
        nilai: await this.getNilaiAkhir(item.id),
      })),
    );
  }

  async getRanking(periodeId?: string) {
    const periode = periodeId ?? (await this.prisma.periode.findFirst({ orderBy: { mulai: "desc" } }))?.id;
    if (!periode) return [];

    const peserta = await this.prisma.peserta.findMany({
      where: { periodeId: periode },
      include: { institusi: true },
    });

    const grouped = new Map<string, { institusiId: string; institusi: string; scores: number[] }>();
    for (const item of peserta) {
      const nilai = await this.getNilaiAkhir(item.id);
      if (nilai.akhir <= 0) continue;
      const current = grouped.get(item.institusiId) ?? {
        institusiId: item.institusiId,
        institusi: item.institusi.nama,
        scores: [],
      };
      current.scores.push(nilai.akhir);
      grouped.set(item.institusiId, current);
    }

    const ranking = Array.from(grouped.values())
      .map((item) => ({
        institusiId: item.institusiId,
        institusi: item.institusi,
        total: item.scores.length,
        totalInterns: item.scores.length,
        rata: Math.round(item.scores.reduce((sum, score) => sum + score, 0) / item.scores.length),
      }))
      .sort((a, b) => b.rata - a.rata)
      .map((item, index) => ({ ...item, rankPosition: index + 1 }));

    await this.prisma.institutionRanking.deleteMany({
      where: {
        periodeId: periode,
        institusiId: { notIn: ranking.map((item) => item.institusiId) },
      },
    });
    await Promise.all(
      ranking.map((item) =>
        this.prisma.institutionRanking.upsert({
          where: { institusiId_periodeId: { institusiId: item.institusiId, periodeId: periode } },
          update: {
            averageScore: item.rata,
            totalInterns: item.totalInterns,
            rankPosition: item.rankPosition,
            calculatedAt: new Date(),
          },
          create: {
            id: makeId("rank"),
            institusiId: item.institusiId,
            periodeId: periode,
            averageScore: item.rata,
            totalInterns: item.totalInterns,
            rankPosition: item.rankPosition,
          },
        }),
      ),
    );

    return ranking;
  }

  async getAdminDashboard() {
    const today = todayStr();
    const [peserta, mentor, institusi, laporan, hadirHariIni] = await Promise.all([
      this.prisma.peserta.findMany(),
      this.prisma.mentor.findMany(),
      this.prisma.institusi.findMany(),
      this.prisma.laporan.findMany(),
      this.prisma.absensi.count({ where: { tanggal: toDbDate(today) } }),
    ]);

    const aktif = peserta.filter((item) => item.status === "Aktif");
    const belumLapor = aktif.filter(
      (item) => !laporan.some((lap) => lap.pesertaId === item.id && dateOnly(lap.tanggal) === today),
    );
    const nilai = await Promise.all(peserta.map((item) => this.getNilaiAkhir(item.id)));

    return {
      pesertaAktif: aktif.length,
      totalMentor: mentor.length,
      totalInstitusi: institusi.length,
      kehadiranHariIni: aktif.length ? Math.round((hadirHariIni / aktif.length) * 100) : 0,
      laporanMenunggu: laporan.filter((item) => item.status === "Menunggu").length,
      laporanApproved: laporan.filter((item) => item.status === "Approved").length,
      laporanRejected: laporan.filter((item) => item.status === "Rejected").length,
      belumLaporHariIni: belumLapor.map(this.mapPeserta),
      rataNilai: nilai.length ? Math.round(nilai.reduce((sum, item) => sum + item.akhir, 0) / nilai.length) : 0,
    };
  }

  async getMentorDashboard(mentorId: string, actor?: RequestActor) {
    if (actor?.role === "mentor" && actor.mentorId !== mentorId) {
      throw new ForbiddenException("Mentor hanya dapat melihat dashboard sendiri.");
    }
    const [peserta, laporan, evaluasi] = await Promise.all([
      this.prisma.peserta.findMany({ where: { mentorId } }),
      this.prisma.laporan.findMany({ where: { mentorId } }),
      this.prisma.evaluasi.findMany({ where: { mentorId } }),
    ]);
    return {
      pesertaBimbingan: peserta.length,
      menungguReview: laporan.filter((item) => item.status === "Menunggu").length,
      approved: laporan.filter((item) => item.status === "Approved").length,
      rejected: laporan.filter((item) => item.status === "Rejected").length,
      evaluasiBelumDiisi: peserta.filter(
        (item) => item.status === "Selesai" && !evaluasi.some((ev) => ev.pesertaId === item.id),
      ).length,
    };
  }

  async getUserDashboard(pesertaId: string, actor?: RequestActor) {
    if (actor?.role === "user" && actor.pesertaId !== pesertaId) {
      throw new ForbiddenException("Peserta hanya dapat melihat dashboard sendiri.");
    }
    const today = todayStr();
    const peserta = await this.ensurePeserta(pesertaId);
    const [absensi, laporan, nilai] = await Promise.all([
      this.prisma.absensi.findFirst({ where: { pesertaId, tanggal: toDbDate(today) } }),
      this.prisma.laporan.findMany({ where: { pesertaId }, orderBy: { tanggal: "desc" } }),
      this.getNilaiAkhir(pesertaId),
    ]);
    return {
      peserta: this.mapPeserta(peserta),
      sudahAbsen: !!absensi,
      laporanHariIni: laporan.find((item) => dateOnly(item.tanggal) === today) ?? null,
      totalLaporan: laporan.length,
      nilai,
    };
  }

  private mapAkun(item: AkunWithMentor) {
    return {
      ...item,
      dibuat: dateOnly(item.dibuat),
      departemen: item.mentor?.departemen,
      telepon: item.mentor?.telepon ?? undefined,
    };
  }

  private mapInstitusi(item: Institusi) {
    return { id: item.id, nama: item.nama };
  }

  private mapPeriode(item: Periode) {
    return {
      id: item.id,
      nama: item.nama,
      mulai: dateOnly(item.mulai),
      selesai: dateOnly(item.selesai),
      aktif: item.aktif,
    };
  }

  private mapMentor(item: Mentor) {
    return {
      id: item.id,
      nama: item.nama,
      email: item.email,
      departemen: item.departemen,
      telepon: item.telepon ?? undefined,
    };
  }

  private mapPeserta(item: Peserta) {
    return {
      id: item.id,
      nama: item.nama,
      email: item.email,
      telepon: item.telepon,
      institusiId: item.institusiId,
      programStudi: item.programStudi,
      periodeId: item.periodeId,
      mentorId: item.mentorId,
      status: item.status,
    };
  }

  private mapAbsensi(item: Absensi) {
    return { id: item.id, pesertaId: item.pesertaId, tanggal: dateOnly(item.tanggal), jam: item.jam };
  }

  private mapLaporan(item: Laporan) {
    return {
      id: item.id,
      pesertaId: item.pesertaId,
      mentorId: item.mentorId,
      tanggal: dateOnly(item.tanggal),
      deskripsi: item.deskripsi,
      lampiran: item.lampiran ?? undefined,
      status: item.status,
      nilai: item.nilai ?? undefined,
      komentar: item.komentar ?? undefined,
    };
  }

  private mapEvaluasi(item: Evaluasi) {
    return {
      id: item.id,
      pesertaId: item.pesertaId,
      mentorId: item.mentorId,
      nilai: item.nilai,
      komentar: item.komentar,
      tanggal: dateOnly(item.tanggal),
    };
  }

  private mapTugas(item: TugasWithRelasi) {
    return {
      id: item.id,
      pesertaId: item.pesertaId,
      mentorId: item.mentorId,
      judul: item.judul,
      deskripsi: item.deskripsi,
      tanggalMulai: dateOnly(item.tanggalMulai),
      tanggalSelesai: dateOnly(item.tanggalSelesai),
      status: item.status,
      nilai: item.nilai ?? undefined,
      komentar: item.komentar ?? undefined,
      reviewedAt: item.reviewedAt ? item.reviewedAt.toISOString() : undefined,
      urutan: item.urutan,
      subTugas: (item.subTugas ?? []).map((sub) => this.mapSubTugas(sub)),
      progres: (item.progres ?? []).map((progres) => this.mapProgres(progres)),
    };
  }

  private mapSubTugas(item: SubTugas) {
    return {
      id: item.id,
      tugasId: item.tugasId,
      judul: item.judul,
      tanggalMulai: item.tanggalMulai ? dateOnly(item.tanggalMulai) : undefined,
      tanggalSelesai: item.tanggalSelesai ? dateOnly(item.tanggalSelesai) : undefined,
      status: item.status,
      urutan: item.urutan,
    };
  }

  private mapProgres(item: TugasProgres & { lampiran?: TugasLampiran[] }) {
    return {
      id: item.id,
      tugasId: item.tugasId,
      pesertaId: item.pesertaId,
      ringkasan: item.ringkasan,
      createdAt: item.createdAt.toISOString(),
      lampiran: (item.lampiran ?? []).map((lampiran) => this.mapLampiran(lampiran)),
    };
  }

  private mapLampiran(item: TugasLampiran) {
    return { id: item.id, tipe: item.tipe, url: item.url, nama: item.nama ?? undefined };
  }

  private validateRange(mulai?: string, selesai?: string) {
    if (mulai && selesai && new Date(mulai) > new Date(selesai)) {
      throw new BadRequestException("Tanggal selesai tidak boleh sebelum tanggal mulai.");
    }
  }

  private async reconcileSubTugas(tugasId: string, items: NonNullable<TugasPayload["subTugas"]>) {
    const existing = await this.prisma.subTugas.findMany({ where: { tugasId } });
    const incomingIds = new Set(items.filter((item) => item.id).map((item) => item.id));
    const toDelete = existing.filter((item) => !incomingIds.has(item.id)).map((item) => item.id);
    if (toDelete.length) {
      await this.prisma.subTugas.deleteMany({ where: { id: { in: toDelete } } });
    }

    let urutan = 0;
    for (const item of items) {
      if (!item.judul?.trim()) continue;
      const data = {
        judul: item.judul.trim(),
        tanggalMulai: item.tanggalMulai ? toDbDate(item.tanggalMulai) : null,
        tanggalSelesai: item.tanggalSelesai ? toDbDate(item.tanggalSelesai) : null,
        urutan,
      };
      if (item.id && existing.some((row) => row.id === item.id)) {
        await this.prisma.subTugas.update({ where: { id: item.id }, data });
      } else {
        await this.prisma.subTugas.create({ data: { id: makeId("st"), tugasId, status: "Ditugaskan", ...data } });
      }
      urutan += 1;
    }
  }

  private async ensureTugas(id: string) {
    const item = await this.prisma.tugas.findUnique({ where: { id } });
    if (!item) throw new NotFoundException("Tugas tidak ditemukan.");
    return item;
  }

  private async getTugasWithRelasi(id: string) {
    const item = await this.prisma.tugas.findUnique({
      where: { id },
      include: {
        subTugas: { orderBy: { urutan: "asc" } },
        progres: { include: { lampiran: true }, orderBy: { createdAt: "desc" } },
      },
    });
    if (!item) throw new NotFoundException("Tugas tidak ditemukan.");
    return item;
  }

  private async ensureAkun(id: string) {
    const item = await this.prisma.akun.findUnique({ where: { id } });
    if (!item) throw new NotFoundException("Akun tidak ditemukan.");
    return item;
  }

  private async getAkunWithMentor(id: string) {
    const item = await this.prisma.akun.findUnique({ where: { id }, include: { mentor: true } });
    if (!item) throw new NotFoundException("Akun tidak ditemukan.");
    return item;
  }

  private async upsertMentorProfile(akun: Akun, body: AkunPayload) {
    const departemen = body.departemen?.trim() || "Umum";
    const telepon = body.telepon?.trim() || undefined;
    const existing = await this.prisma.mentor.findFirst({
      where: { OR: [{ akunId: akun.id }, { email: akun.email }] },
    });

    if (existing) {
      await this.prisma.mentor.update({
        where: { id: existing.id },
        data: {
          akunId: akun.id,
          nama: akun.nama,
          email: akun.email,
          departemen,
          telepon,
        },
      });
      return;
    }

    await this.prisma.mentor.create({
      data: {
        id: makeId("m"),
        akunId: akun.id,
        nama: akun.nama,
        email: akun.email,
        departemen,
        telepon,
      },
    });
  }

  private async ensurePeserta(id: string) {
    const item = await this.prisma.peserta.findUnique({ where: { id } });
    if (!item) throw new NotFoundException("Peserta tidak ditemukan.");
    return item;
  }

  private async ensureLaporan(id: string) {
    const item = await this.prisma.laporan.findUnique({ where: { id } });
    if (!item) throw new NotFoundException("Laporan tidak ditemukan.");
    return item;
  }

  private requireFields(body: Record<string, unknown>, fields: string[]) {
    for (const field of fields) {
      if (body[field] == null || body[field] === "") {
        throw new BadRequestException(`${field} wajib diisi.`);
      }
    }
  }
}
