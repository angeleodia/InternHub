import { existsSync } from "node:fs";
import { resolve } from "node:path";

import { PrismaMariaDb } from "@prisma/adapter-mariadb";
import { PrismaClient } from "@prisma/client";
import { config } from "dotenv";

for (const envPath of [resolve(process.cwd(), ".env"), resolve(process.cwd(), "apps/api/.env")]) {
  if (existsSync(envPath)) config({ path: envPath, override: false });
}

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  throw new Error("DATABASE_URL belum diatur.");
}

const prisma = new PrismaClient({
  adapter: new PrismaMariaDb(databaseUrl),
});

const REF_DATE = "2026-05-18";
const date = (value: string) => new Date(`${value}T00:00:00.000Z`);
const iso = (d: Date) => d.toISOString().slice(0, 10);
const daysAgo = (n: number) => {
  const d = new Date(`${REF_DATE}T00:00:00.000Z`);
  d.setUTCDate(d.getUTCDate() - n);
  return iso(d);
};

type TugasStatus = "Ditugaskan" | "Dikerjakan" | "Revisi" | "Selesai";

const institusi = [
  { id: "i1", nama: "Universitas Indonesia" },
  { id: "i2", nama: "Institut Teknologi Bandung" },
  { id: "i3", nama: "Universitas Gadjah Mada" },
  { id: "i4", nama: "Universitas Brawijaya" },
  { id: "i5", nama: "Politeknik Negeri Jakarta" },
  { id: "i6", nama: "Universitas Bina Nusantara" },
];

const periode = [
  { id: "p1", nama: "Periode Jan - Jun 2026", mulai: date("2026-01-01"), selesai: date("2026-06-30"), aktif: true },
  { id: "p2", nama: "Periode Jul - Des 2025", mulai: date("2025-07-01"), selesai: date("2025-12-31"), aktif: false },
];

const mentor = [
  { id: "m1", akunId: "a-m1", nama: "Bapak Andi Wijaya", email: "andi@internhub.test", departemen: "IT" },
  { id: "m2", akunId: "a-m2", nama: "Ibu Sari Lestari", email: "sari@internhub.test", departemen: "HRD" },
  { id: "m3", akunId: "a-m3", nama: "Bapak Budi Santoso", email: "budi@internhub.test", departemen: "Finance" },
];

const peserta = [
  { id: "u1", akunId: "a-u1", nama: "Rizky Pratama", email: "rizky@student.ui.ac.id", telepon: "081234567001", institusiId: "i1", programStudi: "Ilmu Komputer", periodeId: "p1", mentorId: "m1", status: "Aktif" as const },
  { id: "u2", akunId: "a-u2", nama: "Aulia Rahma", email: "aulia@student.itb.ac.id", telepon: "081234567002", institusiId: "i2", programStudi: "Sistem Informasi", periodeId: "p1", mentorId: "m1", status: "Aktif" as const },
  { id: "u3", akunId: "a-u3", nama: "Dimas Saputra", email: "dimas@student.ugm.ac.id", telepon: "081234567003", institusiId: "i3", programStudi: "Manajemen", periodeId: "p1", mentorId: "m2", status: "Aktif" as const },
  { id: "u4", akunId: "a-u4", nama: "Putri Maharani", email: "putri@student.ub.ac.id", telepon: "081234567004", institusiId: "i4", programStudi: "Akuntansi", periodeId: "p1", mentorId: "m3", status: "Aktif" as const },
  { id: "u5", akunId: "a-u5", nama: "Fajar Nugroho", email: "fajar@student.pnj.ac.id", telepon: "081234567005", institusiId: "i5", programStudi: "Teknik Informatika", periodeId: "p1", mentorId: "m1", status: "Aktif" as const },
  { id: "u6", akunId: "a-u6", nama: "Nadia Kusuma", email: "nadia@student.ui.ac.id", telepon: "081234567006", institusiId: "i1", programStudi: "Psikologi", periodeId: "p2", mentorId: "m2", status: "Selesai" as const },
  { id: "u7", akunId: "a-u7", nama: "Reza Hakim", email: "reza@student.itb.ac.id", telepon: "081234567007", institusiId: "i2", programStudi: "Teknik Industri", periodeId: "p2", mentorId: "m3", status: "Selesai" as const },
  { id: "u8", akunId: "a-u8", nama: "Sinta Dewi", email: "sinta@student.ugm.ac.id", telepon: "081234567008", institusiId: "i3", programStudi: "Ekonomi", periodeId: "p2", mentorId: "m2", status: "Selesai" as const },
];

async function main() {
  await prisma.institutionRanking.deleteMany();
  await prisma.finalScore.deleteMany();
  await prisma.evaluasi.deleteMany();
  await prisma.laporan.deleteMany();
  await prisma.tugasLampiran.deleteMany();
  await prisma.tugasProgres.deleteMany();
  await prisma.subTugas.deleteMany();
  await prisma.tugas.deleteMany();
  await prisma.absensi.deleteMany();
  await prisma.peserta.deleteMany();
  await prisma.mentor.deleteMany();
  await prisma.akun.deleteMany();
  await prisma.periode.deleteMany();
  await prisma.institusi.deleteMany();

  await prisma.institusi.createMany({ data: institusi });
  await prisma.periode.createMany({ data: periode });

  await prisma.akun.createMany({
    data: [
      { id: "a1", nama: "Admin HRD", email: "admin@internhub.test", role: "admin", status: "Aktif", password: "admin123", dibuat: date("2025-01-10") },
      ...mentor.map((item) => ({ id: item.akunId, nama: item.nama, email: item.email, role: "mentor" as const, status: "Aktif" as const, password: "mentor123", dibuat: date("2025-02-01") })),
      ...peserta.map((item) => ({ id: item.akunId, nama: item.nama, email: item.email, role: "user" as const, status: "Aktif" as const, password: "user123", dibuat: date("2025-06-15") })),
    ],
  });

  await prisma.mentor.createMany({ data: mentor });
  await prisma.peserta.createMany({ data: peserta });

  let absensiId = 1;
  for (const item of peserta) {
    const totalDays = item.status === "Aktif" ? 12 : 20;
    for (let i = 1; i <= totalDays; i++) {
      if (i % 7 === 0) continue;
      await prisma.absensi.create({
        data: {
          id: `abs${absensiId++}`,
          pesertaId: item.id,
          tanggal: date(daysAgo(i)),
          jam: `${String(7 + (i % 2)).padStart(2, "0")}:${String((i * 7) % 60).padStart(2, "0")}`,
        },
      });
    }
  }

  let laporanId = 1;
  const statuses = ["Approved", "Approved", "Menunggu", "Rejected", "Approved"] as const;
  for (const item of peserta) {
    const totalDays = item.status === "Aktif" ? 8 : 15;
    for (let i = 1; i <= totalDays; i++) {
      const status = statuses[i % statuses.length];
      const tanggal = daysAgo(i);
      await prisma.laporan.create({
        data: {
          id: `lap${laporanId++}`,
          pesertaId: item.id,
          mentorId: item.mentorId,
          tanggal: date(tanggal),
          deskripsi: `Mengerjakan tugas hari ke-${i}: analisis dan dokumentasi modul terkait.`,
          lampiran: i % 4 === 0 ? `laporan-${item.id}-${tanggal}.pdf` : undefined,
          status,
          nilai: status === "Approved" ? 75 + ((i * 3) % 20) : undefined,
          komentar: status === "Rejected" ? "Mohon lengkapi detail kegiatan dan output yang dihasilkan." : undefined,
        },
      });
    }
  }

  type SubSeed = { judul: string; status: TugasStatus; mulai: string; selesai: string };
  type ProgSeed = { ringkasan: string; createdAt: string; lampiran: { tipe: "File" | "Link"; url: string; nama: string }[] };
  type TugasSeed = {
    id: string; pesertaId: string; mentorId: string; judul: string; deskripsi: string;
    mulai: string; selesai: string; status: TugasStatus; nilai?: number; komentar?: string;
    sub: SubSeed[]; progres: ProgSeed[];
  };

  const tugasSeed: TugasSeed[] = [
    {
      id: "tg1", pesertaId: "u1", mentorId: "m1", judul: "Bangun Modul Pembayaran",
      deskripsi:
        "<p>Rancang dan implementasikan modul pembayaran untuk aplikasi internal.</p><ul><li>Mendukung transfer bank & e-wallet</li><li>Validasi input dan status transaksi</li></ul>",
      mulai: daysAgo(10), selesai: daysAgo(-5), status: "Dikerjakan",
      sub: [
        { judul: "Desain modul & alur", status: "Selesai", mulai: daysAgo(10), selesai: daysAgo(5) },
        { judul: "Breakdown detail teknis", status: "Dikerjakan", mulai: daysAgo(5), selesai: daysAgo(-1) },
        { judul: "Development", status: "Ditugaskan", mulai: daysAgo(-1), selesai: daysAgo(-5) },
      ],
      progres: [
        {
          ringkasan:
            "<p>Telah menyelesaikan <b>desain modul</b> dan alur pembayaran.</p><ul><li>ERD selesai</li><li>Wireframe disetujui</li></ul>",
          createdAt: daysAgo(4),
          lampiran: [{ tipe: "Link", url: "https://drive.google.com/contoh-desain-pembayaran", nama: "Dokumen Desain" }],
        },
      ],
    },
    {
      id: "tg2", pesertaId: "u2", mentorId: "m1", judul: "Riset Kompetitor Produk",
      deskripsi: "<p>Lakukan riset terhadap 5 kompetitor utama dan rangkum dalam tabel perbandingan.</p>",
      mulai: daysAgo(8), selesai: daysAgo(-2), status: "Revisi", komentar: "Tambahkan analisis harga dan sumber datanya.",
      sub: [
        { judul: "Kumpulkan data 5 kompetitor", status: "Selesai", mulai: daysAgo(8), selesai: daysAgo(3) },
        { judul: "Buat tabel perbandingan", status: "Revisi", mulai: daysAgo(3), selesai: daysAgo(-2) },
      ],
      progres: [
        {
          ringkasan: "<p>Draft tabel perbandingan awal terlampir.</p>",
          createdAt: daysAgo(2),
          lampiran: [{ tipe: "Link", url: "https://docs.google.com/contoh-riset", nama: "Draft Riset" }],
        },
      ],
    },
    {
      id: "tg3", pesertaId: "u5", mentorId: "m1", judul: "Integrasi API Notifikasi",
      deskripsi: "<p>Integrasikan layanan notifikasi email & WhatsApp ke aplikasi.</p>",
      mulai: daysAgo(-1), selesai: daysAgo(-10), status: "Ditugaskan",
      sub: [], progres: [],
    },
    {
      id: "tg4", pesertaId: "u3", mentorId: "m2", judul: "Analisis Kebutuhan Rekrutmen",
      deskripsi: "<p>Susun dokumen kebutuhan rekrutmen untuk Q3.</p>",
      mulai: daysAgo(14), selesai: daysAgo(2), status: "Selesai", nilai: 88, komentar: "Analisis lengkap dan rapi. Bagus!",
      sub: [{ judul: "Wawancara user", status: "Selesai", mulai: daysAgo(14), selesai: daysAgo(8) }],
      progres: [
        {
          ringkasan: "<p>Dokumen kebutuhan rekrutmen final.</p><ul><li>5 posisi prioritas</li><li>Estimasi timeline</li></ul>",
          createdAt: daysAgo(3),
          lampiran: [{ tipe: "Link", url: "https://docs.google.com/kebutuhan-rekrutmen", nama: "Dokumen Final" }],
        },
      ],
    },
    {
      id: "tg5", pesertaId: "u4", mentorId: "m3", judul: "Rekap Laporan Keuangan Bulanan",
      deskripsi: "<p>Rekap dan verifikasi laporan keuangan bulan berjalan.</p>",
      mulai: daysAgo(6), selesai: daysAgo(-3), status: "Dikerjakan",
      sub: [
        { judul: "Kumpulkan bukti transaksi", status: "Selesai", mulai: daysAgo(6), selesai: daysAgo(2) },
        { judul: "Verifikasi & rekap", status: "Dikerjakan", mulai: daysAgo(2), selesai: daysAgo(-3) },
      ],
      progres: [{ ringkasan: "<p>Bukti transaksi terkumpul, mulai proses verifikasi.</p>", createdAt: daysAgo(1), lampiran: [] }],
    },
    {
      id: "tg6", pesertaId: "u6", mentorId: "m2", judul: "Onboarding Karyawan Baru",
      deskripsi: "<p>Susun materi onboarding karyawan baru.</p>",
      mulai: daysAgo(40), selesai: daysAgo(25), status: "Selesai", nilai: 90, komentar: "Materi sangat membantu tim.",
      sub: [], progres: [{ ringkasan: "<p>Materi onboarding selesai dan sudah dipakai.</p>", createdAt: daysAgo(26), lampiran: [] }],
    },
    {
      id: "tg7", pesertaId: "u7", mentorId: "m3", judul: "Optimasi Proses Gudang",
      deskripsi: "<p>Analisis dan usulkan perbaikan proses gudang.</p>",
      mulai: daysAgo(45), selesai: daysAgo(30), status: "Selesai", nilai: 84, komentar: "Usulan realistis dan terukur.",
      sub: [], progres: [{ ringkasan: "<p>Laporan optimasi proses terlampir.</p>", createdAt: daysAgo(31), lampiran: [] }],
    },
    {
      id: "tg8", pesertaId: "u8", mentorId: "m2", judul: "Studi Kelayakan Program",
      deskripsi: "<p>Buat studi kelayakan program pelatihan internal.</p>",
      mulai: daysAgo(50), selesai: daysAgo(35), status: "Selesai", nilai: 92, komentar: "Analisis tajam, presentasi memukau.",
      sub: [], progres: [{ ringkasan: "<p>Studi kelayakan final beserta rekomendasi.</p>", createdAt: daysAgo(36), lampiran: [] }],
    },
  ];

  let stId = 1;
  let pgId = 1;
  let attId = 1;
  for (const t of tugasSeed) {
    await prisma.tugas.create({
      data: {
        id: t.id,
        pesertaId: t.pesertaId,
        mentorId: t.mentorId,
        judul: t.judul,
        deskripsi: t.deskripsi,
        tanggalMulai: date(t.mulai),
        tanggalSelesai: date(t.selesai),
        status: t.status,
        nilai: t.nilai,
        komentar: t.komentar,
        reviewedAt: t.status === "Selesai" || t.status === "Revisi" ? date(t.selesai) : undefined,
        subTugas: {
          create: t.sub.map((s, i) => ({
            id: `st${stId++}`,
            judul: s.judul,
            status: s.status,
            tanggalMulai: date(s.mulai),
            tanggalSelesai: date(s.selesai),
            urutan: i,
          })),
        },
        progres: {
          create: t.progres.map((p) => ({
            id: `pg${pgId++}`,
            pesertaId: t.pesertaId,
            ringkasan: p.ringkasan,
            createdAt: date(p.createdAt),
            lampiran: { create: p.lampiran.map((l) => ({ id: `att${attId++}`, tipe: l.tipe, url: l.url, nama: l.nama })) },
          })),
        },
      },
    });
  }

  await prisma.evaluasi.createMany({
    data: [
      { id: "e1", pesertaId: "u6", mentorId: "m2", nilai: 88, komentar: "Sangat baik dalam komunikasi dan inisiatif.", tanggal: date("2025-12-20") },
      { id: "e2", pesertaId: "u7", mentorId: "m3", nilai: 82, komentar: "Disiplin dan teliti.", tanggal: date("2025-12-22") },
      { id: "e3", pesertaId: "u8", mentorId: "m2", nilai: 90, komentar: "Performa luar biasa.", tanggal: date("2025-12-23") },
    ],
  });
}

main()
  .then(async () => {
    await prisma.$disconnect();
    console.log("Seed data berhasil dibuat.");
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
