import { Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useStore } from "@/lib/store";
import { useEffect, useState } from "react";
import {
  LayoutDashboard,
  Users,
  UserCog,
  ClipboardCheck,
  FileText,
  Award,
  Trophy,
  GraduationCap,
  ClipboardList,
  CalendarCheck,
  BookOpenCheck,
  LogOut,
  Menu,
  Building2,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

function LogoutButton({
  onConfirm,
  variant = "sidebar",
}: {
  onConfirm: () => void;
  variant?: "sidebar" | "header";
}) {
  const trigger =
    variant === "sidebar" ? (
      <Button
        variant="secondary"
        size="sm"
        className="w-full bg-white/10 hover:bg-white/20 text-white border-0"
      >
        <LogOut className="h-4 w-4 mr-2" /> Keluar
      </Button>
    ) : (
      <Button variant="ghost" size="sm" className="text-[#0B2D72] hover:bg-[#0B2D72]/5">
        <LogOut className="h-4 w-4 mr-2" /> Keluar
      </Button>
    );
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>{trigger}</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Keluar dari akun?</AlertDialogTitle>
          <AlertDialogDescription>
            Anda akan keluar dari sesi saat ini dan diarahkan ke halaman login.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Batal</AlertDialogCancel>
          <AlertDialogAction className="bg-[#0B2D72] hover:bg-[#0B2D72]/90" onClick={onConfirm}>
            Ya, Keluar
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

type NavItem = { to: string; label: string; icon: React.ComponentType<{ className?: string }> };

const adminNav: NavItem[] = [
  { to: "/admin/dashboard", label: "Ringkasan", icon: LayoutDashboard },
  { to: "/admin/peserta", label: "Data Peserta", icon: Users },
  { to: "/admin/akun", label: "Akun Pengguna", icon: UserCog },
  { to: "/admin/tugas", label: "Pantau Tugas", icon: ClipboardList },
  { to: "/admin/absensi", label: "Absensi", icon: ClipboardCheck },
  { to: "/admin/laporan", label: "Logbook Harian", icon: FileText },
  { to: "/admin/nilai", label: "Rekap Nilai Akhir", icon: Award },
  { to: "/admin/ranking", label: "Ranking Institusi", icon: Trophy },
];
const mentorNav: NavItem[] = [
  { to: "/mentor/dashboard", label: "Ringkasan", icon: LayoutDashboard },
  { to: "/mentor/peserta", label: "Peserta Bimbingan", icon: GraduationCap },
  { to: "/mentor/tugas", label: "Tugas & Bimbingan", icon: ClipboardList },
  { to: "/mentor/laporan", label: "Logbook Harian", icon: FileText },
  { to: "/mentor/evaluasi", label: "Evaluasi Akhir", icon: BookOpenCheck },
];
const userNav: NavItem[] = [
  { to: "/user/dashboard", label: "Ringkasan", icon: LayoutDashboard },
  { to: "/user/tugas", label: "Tugas Saya", icon: ClipboardList },
  { to: "/user/absensi", label: "Absensi Harian", icon: CalendarCheck },
  { to: "/user/laporan", label: "Logbook Harian", icon: FileText },
  { to: "/user/nilai", label: "Nilai Akhir", icon: Award },
];

export function AppLayout({ role }: { role: "admin" | "mentor" | "user" }) {
  const { user, sessionReady, dataReady, dataError, refreshData, logout } = useStore();
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (sessionReady && (!user || user.role !== role)) navigate({ to: "/login" });
  }, [sessionReady, user, role, navigate]);

  const handleLogout = () => {
    logout();
    toast.success("Berhasil keluar dari akun");
    navigate({ to: "/login" });
  };

  if (!sessionReady || !dataReady) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#f7f8fb] text-sm text-muted-foreground">
        Menyiapkan data...
      </div>
    );
  }

  if (dataError) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#f7f8fb] px-4">
        <div className="w-full max-w-md rounded-lg border bg-white p-6 text-center shadow-sm">
          <div className="text-lg font-semibold text-[#0B2D72]">Data belum dapat ditampilkan</div>
          <p className="mt-2 text-sm text-muted-foreground">{dataError}</p>
          <Button
            onClick={() => void refreshData()}
            className="mt-5 bg-[#0B2D72] hover:bg-[#0B2D72]/90"
          >
            <RefreshCw className="mr-2 h-4 w-4" /> Coba Lagi
          </Button>
        </div>
      </div>
    );
  }

  if (!user || user.role !== role) {
    return null;
  }

  const nav = role === "admin" ? adminNav : role === "mentor" ? mentorNav : userNav;
  const roleLabel =
    role === "admin" ? "Admin / HRD" : role === "mentor" ? "Mentor" : "Peserta Magang";

  const Sidebar = (
    <aside className="flex h-full w-64 flex-col bg-[#0B2D72] text-white">
      <div className="flex items-center gap-2 px-5 py-5 border-b border-white/10">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0992C2]">
          <Building2 className="h-5 w-5" />
        </div>
        <div className="leading-tight">
          <div className="text-sm font-semibold">InternHub</div>
          <div className="text-[11px] text-white/60">Sistem Magang</div>
        </div>
      </div>
      <nav className="flex-1 space-y-1 px-3 py-4 overflow-y-auto">
        {nav.map((item) => {
          const active = path === item.to;
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setOpen(false)}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition",
                active
                  ? "bg-white text-[#0B2D72] font-semibold shadow-sm"
                  : "text-white/80 hover:bg-white/10 hover:text-white",
              )}
            >
              <Icon className="h-4 w-4" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-white/10 p-4">
        <div className="text-xs text-white/60">Masuk sebagai</div>
        <div className="text-sm font-medium truncate">{user.nama}</div>
        <div className="text-[11px] text-white/60 mb-3">{roleLabel}</div>
        <LogoutButton onConfirm={handleLogout} />
      </div>
    </aside>
  );

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#f7f8fb]">
      <div className="hidden md:block h-screen flex-shrink-0">{Sidebar}</div>

      {open && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <div className="relative z-50 h-full">{Sidebar}</div>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <header className="flex items-center justify-between bg-white border-b px-4 md:px-6 h-14 flex-shrink-0">
          <div className="flex items-center gap-2">
            <button onClick={() => setOpen(true)} className="p-2 -ml-2 md:hidden">
              <Menu className="h-5 w-5" />
            </button>
            <div className="text-sm font-semibold text-[#0B2D72] md:hidden">InternHub</div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex flex-col items-end leading-tight">
              <span className="text-sm font-medium text-[#0B2D72]">{user.nama}</span>
              <span className="text-[11px] text-muted-foreground">{roleLabel}</span>
            </div>
            <LogoutButton onConfirm={handleLogout} variant="header" />
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-4 md:p-8 max-w-full">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold text-[#0B2D72]">{title}</h1>
        {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
      </div>
      {actions}
    </div>
  );
}
