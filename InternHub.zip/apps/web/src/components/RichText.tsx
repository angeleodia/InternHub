import { useEffect, useRef } from "react";
import { Bold, Italic, Underline, List, ListOrdered, Heading } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Pembersih HTML ringan: buang elemen/atribut berbahaya sebelum disimpan/ditampilkan.
 * Cukup untuk aplikasi internal; menghapus <script>/<style>, atribut on*, dan href javascript:.
 */
export function sanitizeHtml(html: string): string {
  if (!html) return "";
  return html
    .replace(/<\/?(script|style|iframe|object|embed|link|meta)[^>]*>/gi, "")
    .replace(/\son\w+\s*=\s*"[^"]*"/gi, "")
    .replace(/\son\w+\s*=\s*'[^']*'/gi, "")
    .replace(/\son\w+\s*=\s*[^\s>]+/gi, "")
    .replace(/(href|src)\s*=\s*("|')\s*javascript:[^"']*\2/gi, '$1="#"');
}

/** Cek apakah HTML hanya berisi tag kosong (untuk validasi "wajib diisi"). */
export function isRichTextEmpty(html: string): boolean {
  return !html
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;/g, " ")
    .trim();
}

const exec = (command: string, value?: string) => {
  if (typeof document !== "undefined") document.execCommand(command, false, value);
};

type ToolButton = {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  command: string;
  value?: string;
};

const TOOLBAR: ToolButton[] = [
  { icon: Bold, title: "Tebal", command: "bold" },
  { icon: Italic, title: "Miring", command: "italic" },
  { icon: Underline, title: "Garis bawah", command: "underline" },
  { icon: Heading, title: "Judul", command: "formatBlock", value: "<h2>" },
  { icon: List, title: "Daftar poin", command: "insertUnorderedList" },
  { icon: ListOrdered, title: "Daftar bernomor", command: "insertOrderedList" },
];

export function RichTextEditor({
  value,
  onChange,
  placeholder,
  className,
}: {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);

  // Isi konten awal sekali saja agar kursor tidak melompat saat mengetik.
  useEffect(() => {
    if (ref.current && ref.current.innerHTML !== value) ref.current.innerHTML = value ?? "";
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const emit = () => onChange(ref.current?.innerHTML ?? "");

  return (
    <div
      className={cn(
        "rounded-md border bg-white focus-within:ring-2 focus-within:ring-[#0992C2]/40",
        className,
      )}
    >
      <div className="flex flex-wrap items-center gap-0.5 border-b px-2 py-1.5">
        {TOOLBAR.map((btn) => {
          const Icon = btn.icon;
          return (
            <button
              key={btn.title}
              type="button"
              title={btn.title}
              aria-label={btn.title}
              onMouseDown={(e) => {
                e.preventDefault();
                ref.current?.focus();
                exec(btn.command, btn.value);
                emit();
              }}
              className="inline-flex h-7 w-7 items-center justify-center rounded text-muted-foreground hover:bg-muted hover:text-[#0B2D72]"
            >
              <Icon className="h-4 w-4" />
            </button>
          );
        })}
      </div>
      <div
        ref={ref}
        contentEditable
        suppressContentEditableWarning
        role="textbox"
        aria-multiline="true"
        data-placeholder={placeholder}
        onInput={emit}
        onBlur={emit}
        className="rt-content min-h-[140px] px-3 py-2 text-sm"
      />
    </div>
  );
}

export function RichText({ html, className }: { html: string; className?: string }) {
  return (
    <div
      className={cn("rt-content text-sm text-[#0f172a]", className)}
      dangerouslySetInnerHTML={{ __html: sanitizeHtml(html) }}
    />
  );
}
