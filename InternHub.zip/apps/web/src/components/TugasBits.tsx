import { Paperclip, LinkIcon, Trash2, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import { RichText } from "@/components/RichText";
import type { Tugas, TugasLampiran, TugasProgres } from "@/lib/api";
import { attachmentHref, deadlineInfo, deadlineToneClass } from "@/lib/tugas";

export function DeadlineBadge({ tugas, className }: { tugas: Tugas; className?: string }) {
  const info = deadlineInfo(tugas.tanggalSelesai, tugas.status);
  if (!info) return null;
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium",
        deadlineToneClass[info.tone],
        className,
      )}
    >
      {info.text}
    </span>
  );
}

export function LampiranList({ items }: { items: TugasLampiran[] }) {
  if (!items.length)
    return <span className="text-xs italic text-muted-foreground">Tidak ada lampiran</span>;
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item) => {
        const Icon = item.tipe === "Link" ? LinkIcon : Paperclip;
        return (
          <a
            key={item.id}
            href={attachmentHref(item.url)}
            target="_blank"
            rel="noreferrer"
            className="inline-flex max-w-[220px] items-center gap-1.5 rounded-md border bg-white px-2 py-1 text-xs text-[#0B2D72] hover:bg-muted"
          >
            <Icon className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">{item.nama ?? item.url}</span>
          </a>
        );
      })}
    </div>
  );
}

export function ProgresList({
  progres,
  emptyText = "Belum ada laporan progres.",
  onDelete,
}: {
  progres: TugasProgres[];
  emptyText?: string;
  onDelete?: (id: string) => void;
}) {
  if (!progres.length) {
    return (
      <div className="flex items-center gap-2 rounded-md border border-dashed px-3 py-4 text-sm text-muted-foreground">
        <FileText className="h-4 w-4" /> {emptyText}
      </div>
    );
  }
  return (
    <div className="space-y-3">
      {progres.map((item) => (
        <div key={item.id} className="rounded-md border bg-muted/30 p-3">
          <div className="mb-2 flex items-center justify-between">
            <div className="text-xs font-medium text-muted-foreground">
              {new Date(item.createdAt).toLocaleString("id-ID", {
                dateStyle: "medium",
                timeStyle: "short",
              })}
            </div>
            {onDelete && (
              <button
                type="button"
                onClick={() => onDelete(item.id)}
                className="inline-flex items-center gap-1 text-xs text-red-600 hover:underline"
              >
                <Trash2 className="h-3.5 w-3.5" /> Hapus
              </button>
            )}
          </div>
          <RichText html={item.ringkasan} />
          {item.lampiran.length > 0 && (
            <div className="mt-2 border-t pt-2">
              <LampiranList items={item.lampiran} />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
