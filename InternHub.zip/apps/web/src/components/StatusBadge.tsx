import { cn } from "@/lib/utils";

type Variant =
  | "Menunggu"
  | "Approved"
  | "Rejected"
  | "Aktif"
  | "Selesai"
  | "Nonaktif"
  | "Hadir"
  | "Belum Hadir"
  | "Belum Lapor"
  | "Ditugaskan"
  | "Dikerjakan"
  | "Revisi";

const map: Record<Variant, string> = {
  Menunggu: "bg-amber-100 text-amber-800 border-amber-200",
  Approved: "bg-[#0AC4E0]/15 text-[#076e7f] border-[#0AC4E0]/40",
  Rejected: "bg-red-100 text-red-700 border-red-200",
  Aktif: "bg-[#0AC4E0]/15 text-[#076e7f] border-[#0AC4E0]/40",
  Selesai: "bg-emerald-100 text-emerald-700 border-emerald-200",
  Nonaktif: "bg-gray-100 text-gray-600 border-gray-200",
  Hadir: "bg-[#0AC4E0]/15 text-[#076e7f] border-[#0AC4E0]/40",
  "Belum Hadir": "bg-gray-100 text-gray-600 border-gray-200",
  "Belum Lapor": "bg-gray-100 text-gray-600 border-gray-200",
  Ditugaskan: "bg-gray-100 text-gray-600 border-gray-200",
  Dikerjakan: "bg-[#0992C2]/15 text-[#0B2D72] border-[#0992C2]/30",
  Revisi: "bg-amber-100 text-amber-800 border-amber-200",
};

const labels: Record<Variant, string> = {
  Menunggu: "Menunggu",
  Approved: "Disetujui",
  Rejected: "Ditolak",
  Aktif: "Aktif",
  Selesai: "Selesai",
  Nonaktif: "Nonaktif",
  Hadir: "Hadir",
  "Belum Hadir": "Belum Hadir",
  "Belum Lapor": "Belum Lapor",
  Ditugaskan: "Ditugaskan",
  Dikerjakan: "Dikerjakan",
  Revisi: "Perlu Revisi",
};

export function StatusBadge({
  status,
  className,
}: {
  status: Variant | string;
  className?: string;
}) {
  const key = (status as Variant) in map ? (status as Variant) : "Nonaktif";
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        map[key],
        className,
      )}
    >
      {labels[key] ?? status}
    </span>
  );
}
