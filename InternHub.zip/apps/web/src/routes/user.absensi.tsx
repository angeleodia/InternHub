import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CalendarCheck, CheckCircle2 } from "lucide-react";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { toast } from "sonner";

export const Route = createFileRoute("/user/absensi")({ component: Page });

function Page() {
  const { user, absensi, addAbsensi } = useStore();
  const me = user?.pesertaId!;
  const today = new Date().toISOString().slice(0, 10);
  const sudah = absensi.some(a => a.pesertaId === me && a.tanggal === today);
  const dow = new Date().getDay(); // 0 sun, 6 sat
  const isHariKerja = dow >= 1 && dow <= 5;

  const klik = async () => {
    if (!isHariKerja) { toast.error("Absensi hanya tersedia pada hari kerja (Senin-Jumat)."); return; }
    const err = await addAbsensi(me);
    if (err) toast.error(err); else toast.success("Absensi tercatat.");
  };

  const riwayat = absensi.filter(a => a.pesertaId === me).sort((a,b) => b.tanggal.localeCompare(a.tanggal));
  const pg = usePagination(riwayat);

  return (
    <>
      <PageHeader title="Absensi Harian" />
      <Card className="p-6 mb-6 bg-[#F6E7BC]/40 border-[#0992C2]/20">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="text-sm text-muted-foreground">Tanggal Hari Ini</div>
            <div className="text-2xl font-bold text-[#0B2D72]">{new Date().toLocaleDateString("id-ID", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</div>
            {sudah && <div className="mt-2 inline-flex items-center gap-2 text-sm text-[#076e7f]"><CheckCircle2 className="h-4 w-4" />Absensi hari ini sudah tercatat.</div>}
            {!isHariKerja && <div className="mt-2 text-sm text-amber-700">Hari ini bukan hari kerja.</div>}
          </div>
          <Button size="lg" onClick={klik} disabled={sudah || !isHariKerja} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">
            <CalendarCheck className="h-5 w-5 mr-2" />{sudah ? "Sudah Absen" : "Hadir"}
          </Button>
        </div>
      </Card>

      <Card>
        <div className="px-5 py-3 border-b font-semibold text-[#0B2D72]">Riwayat Absensi</div>
        <Table>
          <TableHeader><TableRow><TableHead>Tanggal</TableHead><TableHead>Jam Absen</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
          <TableBody>
            {riwayat.length === 0 && <TableRow><TableCell colSpan={3} className="text-center py-8 text-muted-foreground">Belum ada riwayat absensi.</TableCell></TableRow>}
            {pg.pageItems.map(a => (
              <TableRow key={a.id}><TableCell>{a.tanggal}</TableCell><TableCell>{a.jam}</TableCell><TableCell><span className="text-xs text-[#076e7f] font-medium">Hadir</span></TableCell></TableRow>
            ))}
          </TableBody>
        </Table>
        <DataPagination {...pg} />
      </Card>
    </>
  );
}
