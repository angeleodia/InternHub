import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { StatusBadge } from "@/components/StatusBadge";
import { RichTextEditor, RichText, isRichTextEmpty } from "@/components/RichText";
import { DeadlineBadge, ProgresList } from "@/components/TugasBits";
import { formatTanggal } from "@/lib/tugas";
import {
  Send,
  Plus,
  Paperclip,
  LinkIcon,
  X,
  ClipboardList,
  MessageSquareWarning,
  Calendar,
  Award,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import type { LinkLampiranInput, Tugas } from "@/lib/api";

export const Route = createFileRoute("/user/tugas")({ component: Page });

const STATUS_ORDER = { Revisi: 0, Dikerjakan: 1, Ditugaskan: 2, Selesai: 3 } as const;

function Page() {
  const { user, peserta, tugas, mentor, addProgres, deleteProgres } = useStore();
  const me = peserta.find((p) => p.id === user?.pesertaId);
  const mine = useMemo(
    () =>
      tugas
        .filter((t) => t.pesertaId === me?.id)
        .sort(
          (a, b) =>
            STATUS_ORDER[a.status] - STATUS_ORDER[b.status] ||
            a.tanggalSelesai.localeCompare(b.tanggalSelesai),
        ),
    [tugas, me?.id],
  );
  const namaMentor = (id: string) => mentor.find((m) => m.id === id)?.nama ?? "Mentor";

  const [progresForId, setProgresForId] = useState<string | null>(null);
  const progresFor = useMemo(
    () => tugas.find((t) => t.id === progresForId) ?? null,
    [tugas, progresForId],
  );
  const [ringkasan, setRingkasan] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [links, setLinks] = useState<LinkLampiranInput[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const openProgres = (t: Tugas) => {
    setProgresForId(t.id);
    setRingkasan("");
    setFiles([]);
    setLinks([]);
  };

  const submitProgres = async () => {
    if (!progresFor) return;
    if (isRichTextEmpty(ringkasan)) return toast.error("Ringkasan progres wajib diisi.");
    const cleanLinks = links.filter((l) => l.url.trim());
    setSubmitting(true);
    const err = await addProgres(progresFor.id, { ringkasan, files, links: cleanLinks });
    setSubmitting(false);
    if (err) return toast.error(err);
    toast.success("Laporan progres terkirim.");
    setProgresForId(null);
  };

  const hapusProgres = async (id: string) => {
    const err = await deleteProgres(id);
    if (err) return toast.error(err);
    toast.success("Laporan progres dihapus.");
  };

  if (!me) return null;

  return (
    <>
      <PageHeader
        title="Tugas Saya"
        description="Tugas dari mentor beserta tenggatnya. Laporkan progres Anda sebagai bukti penyelesaian."
      />

      {mine.length === 0 ? (
        <Card className="p-10 text-center text-sm text-muted-foreground">
          <ClipboardList className="mx-auto mb-3 h-10 w-10 text-[#0992C2]" />
          Belum ada tugas dari mentor. Tugas yang diberikan akan muncul di sini.
        </Card>
      ) : (
        <div className="space-y-4">
          {mine.map((t) => {
            const subSelesai = t.subTugas.filter((s) => s.status === "Selesai").length;
            return (
              <Card key={t.id} className="p-5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold text-[#0B2D72]">{t.judul}</span>
                  <StatusBadge status={t.status} />
                  <DeadlineBadge tugas={t} />
                  {t.status === "Selesai" && t.nilai != null && (
                    <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[11px] font-medium text-emerald-700">
                      <Award className="h-3 w-3" /> Nilai {t.nilai}
                    </span>
                  )}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  <Calendar className="inline h-3 w-3" /> {formatTanggal(t.tanggalMulai)} –{" "}
                  {formatTanggal(t.tanggalSelesai)} • dari {namaMentor(t.mentorId)}
                </div>

                <div className="mt-3 rounded-md bg-muted/40 p-3">
                  <div className="mb-1 text-xs font-medium text-muted-foreground">Instruksi</div>
                  <RichText html={t.deskripsi} />
                </div>

                {t.subTugas.length > 0 && (
                  <div className="mt-3">
                    <div className="mb-1.5 text-xs font-medium text-muted-foreground">
                      Tahapan ({subSelesai}/{t.subTugas.length} selesai)
                    </div>
                    <div className="space-y-1.5">
                      {t.subTugas.map((s) => (
                        <div
                          key={s.id}
                          className="flex flex-wrap items-center justify-between gap-2 rounded-md border px-3 py-1.5 text-sm"
                        >
                          <span>{s.judul}</span>
                          <div className="flex items-center gap-2">
                            {(s.tanggalMulai || s.tanggalSelesai) && (
                              <span className="text-xs text-muted-foreground">
                                {formatTanggal(s.tanggalMulai)} – {formatTanggal(s.tanggalSelesai)}
                              </span>
                            )}
                            <StatusBadge status={s.status} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {t.komentar && (
                  <div
                    className={`mt-3 flex items-start gap-2 rounded-md border px-3 py-2 text-sm ${t.status === "Revisi" ? "border-amber-200 bg-amber-50 text-amber-800" : "border-[#0AC4E0]/30 bg-[#0AC4E0]/10 text-[#076e7f]"}`}
                  >
                    <MessageSquareWarning className="mt-0.5 h-4 w-4 shrink-0" />
                    <div>
                      <span className="font-medium">Feedback {namaMentor(t.mentorId)}:</span>{" "}
                      {t.komentar}
                    </div>
                  </div>
                )}

                <div className="mt-4">
                  <div className="mb-1.5 flex items-center justify-between">
                    <div className="text-xs font-medium text-muted-foreground">
                      Laporan Progres Saya
                    </div>
                    {t.status !== "Selesai" && (
                      <Button
                        size="sm"
                        onClick={() => openProgres(t)}
                        className="bg-[#0B2D72] hover:bg-[#0B2D72]/90"
                      >
                        <Send className="mr-1.5 h-3.5 w-3.5" /> Lapor Progres
                      </Button>
                    )}
                  </div>
                  <ProgresList
                    progres={t.progres}
                    emptyText={
                      'Belum ada laporan. Klik "Lapor Progres" untuk mengunggah bukti pekerjaan.'
                    }
                    onDelete={t.status !== "Selesai" ? hapusProgres : undefined}
                  />
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Dialog lapor progres */}
      <Dialog open={!!progresForId} onOpenChange={(o) => !o && setProgresForId(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Lapor Progres — {progresFor?.judul}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Ringkasan Progres *</Label>
              <RichTextEditor
                value={ringkasan}
                onChange={setRingkasan}
                placeholder="Tuliskan poin-poin yang sudah dikerjakan…"
              />
            </div>

            <div className="space-y-1.5">
              <Label>Lampiran Bukti (dokumen/foto/video — bisa banyak)</Label>
              <label className="flex cursor-pointer items-center gap-2 rounded-md border border-dashed px-3 py-2 text-sm text-muted-foreground hover:bg-muted">
                <Paperclip className="h-4 w-4" /> Pilih berkas…
                <input
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    setFiles((prev) => [...prev, ...Array.from(e.target.files ?? [])]);
                    e.target.value = "";
                  }}
                />
              </label>
              {files.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {files.map((f, i) => (
                    <span
                      key={i}
                      className="inline-flex max-w-[220px] items-center gap-1.5 rounded-md border bg-white px-2 py-1 text-xs"
                    >
                      <Paperclip className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">{f.name}</span>
                      <button
                        type="button"
                        onClick={() => setFiles((arr) => arr.filter((_, j) => j !== i))}
                      >
                        <X className="h-3.5 w-3.5 text-muted-foreground hover:text-red-600" />
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label>Tautan / Screenshot (opsional)</Label>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => setLinks((l) => [...l, { url: "", nama: "" }])}
                >
                  <Plus className="mr-1 h-3.5 w-3.5" /> Tambah Tautan
                </Button>
              </div>
              {links.map((l, i) => (
                <div key={i} className="grid gap-2 sm:grid-cols-[1fr_1fr_auto] sm:items-center">
                  <Input
                    value={l.url}
                    placeholder="https://…"
                    onChange={(e) =>
                      setLinks((arr) =>
                        arr.map((x, j) => (j === i ? { ...x, url: e.target.value } : x)),
                      )
                    }
                  />
                  <Input
                    value={l.nama ?? ""}
                    placeholder="Label (opsional)"
                    onChange={(e) =>
                      setLinks((arr) =>
                        arr.map((x, j) => (j === i ? { ...x, nama: e.target.value } : x)),
                      )
                    }
                  />
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    className="text-red-600"
                    onClick={() => setLinks((arr) => arr.filter((_, j) => j !== i))}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              {links.length === 0 && (
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <LinkIcon className="h-3.5 w-3.5" /> Lampirkan tautan Google Drive, repo, atau
                  screenshot online.
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setProgresForId(null)}>
              Batal
            </Button>
            <Button
              onClick={submitProgres}
              disabled={submitting}
              className="bg-[#0B2D72] hover:bg-[#0B2D72]/90"
            >
              {submitting ? "Mengirim…" : "Kirim Progres"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
