import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { Eye, Paperclip } from "lucide-react";
import { useMemo, useState } from "react";
import { API_BASE_URL, type Laporan } from "@/lib/api";

export const Route = createFileRoute("/admin/laporan")({ component: Page });

function Page() {
  const { laporan, peserta, mentor, periode } = useStore();
  const [st, setSt] = useState("semua");
  const [mt, setMt] = useState("semua");
  const [pr, setPr] = useState("semua");
  const [detail, setDetail] = useState<Laporan | null>(null);

  const nmP = (id: string) => peserta.find((p) => p.id === id)?.nama ?? "-";
  const nmM = (id: string) => mentor.find((m) => m.id === id)?.nama ?? "-";

  const filtered = useMemo(
    () =>
      laporan
        .filter((l) => st === "semua" || l.status === st)
        .filter((l) => mt === "semua" || l.mentorId === mt)
        .filter(
          (l) => pr === "semua" || peserta.find((p) => p.id === l.pesertaId)?.periodeId === pr,
        )
        .sort((a, b) => b.tanggal.localeCompare(a.tanggal)),
    [laporan, peserta, st, mt, pr],
  );
  const pg = usePagination(filtered);

  return (
    <>
      <PageHeader
        title="Logbook Harian"
        description="Catatan kegiatan harian peserta (logbook). Penilaian utama mengikuti progres tugas."
      />
      <Card className="p-4 mb-4">
        <div className="grid gap-3 sm:grid-cols-3">
          <Select value={st} onValueChange={setSt}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Status</SelectItem>
              <SelectItem value="Menunggu">Menunggu</SelectItem>
              <SelectItem value="Approved">Disetujui</SelectItem>
              <SelectItem value="Rejected">Ditolak</SelectItem>
            </SelectContent>
          </Select>
          <Select value={mt} onValueChange={setMt}>
            <SelectTrigger>
              <SelectValue placeholder="Mentor" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Mentor</SelectItem>
              {mentor.map((m) => (
                <SelectItem key={m.id} value={m.id}>
                  {m.nama}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={pr} onValueChange={setPr}>
            <SelectTrigger>
              <SelectValue placeholder="Periode" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Periode</SelectItem>
              {periode.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.nama}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tanggal</TableHead>
                <TableHead>Peserta</TableHead>
                <TableHead>Mentor</TableHead>
                <TableHead>Deskripsi</TableHead>
                <TableHead>Lampiran</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Nilai</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                    Tidak ada laporan.
                  </TableCell>
                </TableRow>
              )}
              {pg.pageItems.map((l) => (
                <TableRow key={l.id}>
                  <TableCell>{l.tanggal}</TableCell>
                  <TableCell>{nmP(l.pesertaId)}</TableCell>
                  <TableCell>{nmM(l.mentorId)}</TableCell>
                  <TableCell className="max-w-xs truncate">{l.deskripsi}</TableCell>
                  <TableCell>{l.lampiran ? <LampiranLink lampiran={l.lampiran} /> : "-"}</TableCell>
                  <TableCell>
                    <StatusBadge status={l.status} />
                  </TableCell>
                  <TableCell>{l.nilai ?? "-"}</TableCell>
                  <TableCell>
                    <Button size="icon" variant="ghost" onClick={() => setDetail(l)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>

      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Detail Laporan</DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-muted-foreground">Tanggal:</span> {detail.tanggal}
              </div>
              <div>
                <span className="text-muted-foreground">Peserta:</span> {nmP(detail.pesertaId)}
              </div>
              <div>
                <span className="text-muted-foreground">Mentor:</span> {nmM(detail.mentorId)}
              </div>
              <div>
                <span className="text-muted-foreground">Status:</span>{" "}
                <StatusBadge status={detail.status} />
              </div>
              <div>
                <span className="text-muted-foreground">Nilai:</span> {detail.nilai ?? "-"}
              </div>
              <div>
                <span className="text-muted-foreground">Lampiran:</span>{" "}
                {detail.lampiran ? <LampiranLink lampiran={detail.lampiran} /> : "-"}
              </div>
              <div className="pt-2">
                <div className="text-muted-foreground mb-1">Deskripsi</div>
                <div className="bg-muted/40 rounded p-3">{detail.deskripsi}</div>
              </div>
              {detail.komentar && (
                <div className="pt-2">
                  <div className="text-muted-foreground mb-1">Komentar Mentor</div>
                  <div className="bg-amber-50 border border-amber-200 rounded p-3">
                    {detail.komentar}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

function fileLabel(value: string) {
  return value.split("/").pop() ?? value;
}

function LampiranLink({ lampiran }: { lampiran: string }) {
  const href = lampiran.startsWith("/uploads/") ? `${API_BASE_URL}${lampiran}` : undefined;
  const content = (
    <span className="inline-flex max-w-[160px] items-center gap-1 truncate text-xs text-[#0B2D72]">
      <Paperclip className="h-3 w-3 shrink-0" />
      {fileLabel(lampiran)}
    </span>
  );
  if (!href) return content;
  return (
    <a href={href} target="_blank" rel="noreferrer" className="hover:underline">
      {content}
    </a>
  );
}
