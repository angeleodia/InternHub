import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Index });

function Index() {
  const navigate = useNavigate();
  const { user, sessionReady } = useStore();
  useEffect(() => {
    if (!sessionReady) return;
    if (user) navigate({ to: `/${user.role}/dashboard` as any });
    else navigate({ to: "/login" });
  }, [sessionReady, user, navigate]);
  return null;
}
