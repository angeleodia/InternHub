import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { API_BASE_URL, type Laporan, type StatusLaporan } from "@/lib/api";

export const Route = createFileRoute("/mentor/laporan")({ component: Page });

function Page() {
  const { user, laporan, peserta, reviewLaporan } = useStore();
  const mine = laporan.filter((l) => l.mentorId === user?.mentorId);
  const [st, setSt] = useState("semua");
  const [tgl, setTgl] = useState("");
  const [open, setOpen] = useState<Laporan | null>(null);
  const [status, setStatus] = useState<StatusLaporan>("Approved");
  const [nilai, setNilai] = useState<string>("80");
  const [komentar, setKomentar] = useState("");

  const filtered = useMemo(
    () =>
      mine
        .filter((l) => st === "semua" || l.status === st)
        .filter((l) => !tgl || l.tanggal === tgl)
        .sort((a, b) => b.tanggal.localeCompare(a.tanggal)),
    [mine, st, tgl],
  );
  const pg = usePagination(filtered);

  const nmP = (id: string) => peserta.find((p) => p.id === id)?.nama ?? "-";

  const openReview = (l: Laporan) => {
    setOpen(l);
    setStatus(l.status === "Rejected" ? "Rejected" : "Approved");
    setNilai(String(l.nilai ?? 80));
    setKomentar(l.komentar ?? "");
  };

  const submit = async () => {
    if (!open) return;
    const n = parseInt(nilai, 10);
    const err = await reviewLaporan(open.id, status, isNaN(n) ? undefined : n, komentar);
    if (err) {
      toast.error(err);
      return;
    }
    toast.success("Tinjauan tersimpan.");
    setOpen(null);
  };

  return (
    <>
      <PageHeader
        title="Tinjau Logbook Harian"
        description="Tinjau catatan kegiatan harian (logbook) peserta bimbingan. Penilaian utama ada di menu Tugas & Bimbingan."
      />
      <Card className="p-4 mb-4">
        <div className="grid gap-3 sm:grid-cols-3">
          <Select value={st} onValueChange={setSt}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Status</SelectItem>
              <SelectItem value="Menunggu">Menunggu</SelectItem>
              <SelectItem value="Approved">Disetujui</SelectItem>
              <SelectItem value="Rejected">Ditolak</SelectItem>
            </SelectContent>
          </Select>
          <Input type="date" value={tgl} onChange={(e) => setTgl(e.target.value)} />
          <Button
            variant="outline"
            onClick={() => {
              setSt("semua");
              setTgl("");
            }}
          >
            Reset Filter
          </Button>
        </div>
      </Card>
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tanggal</TableHead>
                <TableHead>Peserta</TableHead>
                <TableHead>Deskripsi</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Nilai</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pg.pageItems.map((l) => (
                <TableRow key={l.id}>
                  <TableCell>{l.tanggal}</TableCell>
                  <TableCell>{nmP(l.pesertaId)}</TableCell>
                  <TableCell className="max-w-xs truncate">{l.deskripsi}</TableCell>
                  <TableCell>
                    <StatusBadge status={l.status} />
                  </TableCell>
                  <TableCell>{l.nilai ?? "-"}</TableCell>
                  <TableCell>
                    <Button size="sm" variant="outline" onClick={() => openReview(l)}>
                      Tinjau
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>

      <Dialog open={!!open} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tinjau Laporan</DialogTitle>
          </DialogHeader>
          {open && (
            <div className="space-y-3 text-sm">
              <div>
                <b>Peserta:</b> {nmP(open.pesertaId)} •{" "}
                <span className="text-muted-foreground">{open.tanggal}</span>
              </div>
              <div className="bg-muted/40 rounded p-3">
                <div className="text-xs text-muted-foreground mb-1">Deskripsi</div>
                {open.deskripsi}
              </div>
              <div className="text-xs text-muted-foreground">
                Lampiran:{" "}
                {open.lampiran ? (
                  <LampiranLink lampiran={open.lampiran} />
                ) : (
                  <span className="italic">-</span>
                )}
              </div>
              <div className="space-y-1.5">
                <Label>Keputusan</Label>
                <Select value={status} onValueChange={(v) => setStatus(v as StatusLaporan)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Approved">Disetujui</SelectItem>
                    <SelectItem value="Rejected">Ditolak</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {status === "Approved" && (
                <div className="space-y-1.5">
                  <Label>Nilai (1-100) *</Label>
                  <Input
                    type="number"
                    min={1}
                    max={100}
                    value={nilai}
                    onChange={(e) => setNilai(e.target.value)}
                  />
                </div>
              )}
              <div className="space-y-1.5">
                <Label>Komentar {status === "Rejected" && "*"}</Label>
                <Textarea
                  value={komentar}
                  onChange={(e) => setKomentar(e.target.value)}
                  placeholder={
                    status === "Rejected" ? "Komentar wajib diisi jika ditolak" : "Opsional"
                  }
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(null)}>
              Batal
            </Button>
            <Button onClick={submit} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">
              Simpan Tinjauan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function fileLabel(value: string) {
  return value.split("/").pop() ?? value;
}

function LampiranLink({ lampiran }: { lampiran: string }) {
  const href = lampiran.startsWith("/uploads/") ? `${API_BASE_URL}${lampiran}` : undefined;
  const content = <span className="text-[#0B2D72]">{fileLabel(lampiran)}</span>;
  if (!href) return content;
  return (
    <a href={href} target="_blank" rel="noreferrer" className="hover:underline">
      {content}
    </a>
  );
}
