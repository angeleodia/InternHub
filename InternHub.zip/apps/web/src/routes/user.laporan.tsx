import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { StatusBadge } from "@/components/StatusBadge";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { Send, Paperclip, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { API_BASE_URL, type Laporan } from "@/lib/api";

export const Route = createFileRoute("/user/laporan")({ component: Page });

function Page() {
  const { user, peserta, laporan, addLaporan, updateLaporan } = useStore();
  const me = peserta.find((p) => p.id === user?.pesertaId)!;
  const today = new Date().toISOString().slice(0, 10);
  const [tanggal, setTanggal] = useState(today);
  const [deskripsi, setDeskripsi] = useState("");
  const [lampiran, setLampiran] = useState("");
  const [lampiranFile, setLampiranFile] = useState<File | null>(null);
  const [edit, setEdit] = useState<Laporan | null>(null);
  const [editDesk, setEditDesk] = useState("");
  const [editLampiran, setEditLampiran] = useState("");
  const [editLampiranFile, setEditLampiranFile] = useState<File | null>(null);

  const mine = laporan
    .filter((l) => l.pesertaId === me.id)
    .sort((a, b) => b.tanggal.localeCompare(a.tanggal));
  const pg = usePagination(mine);

  const kirim = async () => {
    const err = await addLaporan({
      pesertaId: me.id,
      mentorId: me.mentorId,
      tanggal,
      deskripsi,
      lampiran,
      lampiranFile,
    });
    if (err) {
      toast.error(err);
      return;
    }
    toast.success("Laporan dikirim.");
    setDeskripsi("");
    setLampiran("");
    setLampiranFile(null);
  };

  const openPerbaiki = (l: Laporan) => {
    setEdit(l);
    setEditDesk(l.deskripsi);
    setEditLampiran(l.lampiran ?? "");
    setEditLampiranFile(null);
  };
  const simpanPerbaikan = async () => {
    if (!edit) return;
    if (!editDesk.trim()) {
      toast.error("Deskripsi wajib diisi.");
      return;
    }
    const err = await updateLaporan(edit.id, {
      deskripsi: editDesk,
      lampiran: editLampiran || undefined,
      lampiranFile: editLampiranFile,
      status: "Menunggu",
      komentar: undefined,
      nilai: undefined,
    });
    if (err) {
      toast.error(err);
      return;
    }
    toast.success("Laporan diperbaiki dan dikirim ulang.");
    setEdit(null);
  };

  return (
    <>
      <PageHeader
        title="Logbook Harian"
        description="Catatan kegiatan harian. Untuk tugas dari mentor & penilaian, buka menu Tugas Saya."
      />
      <Card className="p-5 mb-6">
        <div className="font-semibold text-[#0B2D72] mb-3">Buat Laporan Harian</div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Tanggal</Label>
            <Input type="date" value={tanggal} onChange={(e) => setTanggal(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Lampiran (opsional)</Label>
            <div className="flex items-center gap-2 rounded-md border px-3 py-2 text-sm">
              <Paperclip className="h-4 w-4 text-muted-foreground" />
              <input
                type="file"
                className="text-xs flex-1"
                onChange={(e) => {
                  const file = e.target.files?.[0] ?? null;
                  setLampiranFile(file);
                  setLampiran(file?.name ?? "");
                }}
              />
            </div>
            {lampiran && (
              <div className="text-xs text-muted-foreground">
                Dipilih dan akan diunggah: {lampiran}
              </div>
            )}
          </div>
        </div>
        <div className="space-y-1.5 mt-3">
          <Label>Deskripsi Kegiatan *</Label>
          <Textarea
            rows={4}
            value={deskripsi}
            onChange={(e) => setDeskripsi(e.target.value)}
            placeholder="Ceritakan kegiatan magang hari ini…"
          />
        </div>
        <div className="mt-4 flex justify-end">
          <Button onClick={kirim} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">
            <Send className="h-4 w-4 mr-2" />
            Kirim Laporan
          </Button>
        </div>
      </Card>

      <Card>
        <div className="px-5 py-3 border-b font-semibold text-[#0B2D72]">Riwayat Laporan</div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tanggal</TableHead>
              <TableHead>Deskripsi</TableHead>
              <TableHead>Lampiran</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Nilai</TableHead>
              <TableHead>Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mine.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  Belum ada laporan.
                </TableCell>
              </TableRow>
            )}
            {pg.pageItems.map((l) => (
              <TableRow key={l.id}>
                <TableCell>{l.tanggal}</TableCell>
                <TableCell className="max-w-md">
                  <div className="truncate">{l.deskripsi}</div>
                  {l.status === "Rejected" && l.komentar && (
                    <div className="mt-1 flex items-start gap-1 text-xs text-red-700 bg-red-50 border border-red-200 rounded px-2 py-1">
                      <AlertCircle className="h-3 w-3 mt-0.5" />
                      <span>{l.komentar}</span>
                    </div>
                  )}
                </TableCell>
                <TableCell>{l.lampiran ? <LampiranLink lampiran={l.lampiran} /> : "-"}</TableCell>
                <TableCell>
                  <StatusBadge status={l.status} />
                </TableCell>
                <TableCell>{l.nilai ?? "-"}</TableCell>
                <TableCell>
                  {l.status === "Rejected" && (
                    <Button size="sm" variant="outline" onClick={() => openPerbaiki(l)}>
                      Perbaiki Laporan
                    </Button>
                  )}
                  {l.status === "Approved" && (
                    <span className="text-xs text-muted-foreground italic">Sudah disetujui</span>
                  )}
                  {l.status === "Menunggu" && (
                    <span className="text-xs text-muted-foreground italic">Menunggu ditinjau</span>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <DataPagination {...pg} />
      </Card>

      <Dialog open={!!edit} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Perbaiki Laporan</DialogTitle>
          </DialogHeader>
          {edit?.komentar && (
            <div className="text-xs text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2 mb-2">
              Komentar mentor: {edit.komentar}
            </div>
          )}
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Deskripsi Kegiatan</Label>
              <Textarea rows={5} value={editDesk} onChange={(e) => setEditDesk(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Lampiran (opsional)</Label>
              <div className="flex items-center gap-2 rounded-md border px-3 py-2 text-sm">
                <Paperclip className="h-4 w-4 text-muted-foreground" />
                <input
                  type="file"
                  className="text-xs flex-1"
                  onChange={(e) => {
                    const file = e.target.files?.[0] ?? null;
                    setEditLampiranFile(file);
                    setEditLampiran(file?.name ?? editLampiran);
                  }}
                />
              </div>
              {editLampiran && (
                <div className="text-xs text-muted-foreground">
                  Lampiran: {fileLabel(editLampiran)}
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEdit(null)}>
              Batal
            </Button>
            <Button onClick={simpanPerbaikan} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">
              Kirim Ulang
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function fileLabel(value: string) {
  return value.split("/").pop() ?? value;
}

function LampiranLink({ lampiran }: { lampiran: string }) {
  const href = lampiran.startsWith("/uploads/") ? `${API_BASE_URL}${lampiran}` : undefined;
  const content = (
    <span className="inline-flex max-w-[180px] items-center gap-1 truncate text-xs text-[#0B2D72]">
      <Paperclip className="h-3 w-3 shrink-0" />
      {fileLabel(lampiran)}
    </span>
  );

  if (!href) return content;
  return (
    <a href={href} target="_blank" rel="noreferrer" className="hover:underline">
      {content}
    </a>
  );
}
