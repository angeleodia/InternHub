import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { Progress } from "@/components/ui/progress";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { Eye } from "lucide-react";
import { useState } from "react";
import type { Peserta } from "@/lib/api";

export const Route = createFileRoute("/mentor/peserta")({ component: Page });

function Page() {
  const { user, peserta, institusi, periode, laporan, getNilaiAkhir } = useStore();
  const bimbingan = peserta.filter(p => p.mentorId === user?.mentorId);
  const [detail, setDetail] = useState<Peserta | null>(null);
  const nm = (id: string, list: { id: string; nama: string }[]) => list.find(x => x.id === id)?.nama ?? "-";
  const pg = usePagination(bimbingan);

  return (
    <>
      <PageHeader title="Peserta Bimbingan" />
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Nama</TableHead><TableHead>Institusi</TableHead><TableHead>Program</TableHead>
              <TableHead>Periode</TableHead><TableHead>Status</TableHead>
              <TableHead>Progress Laporan</TableHead><TableHead>Nilai Sementara</TableHead><TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {pg.pageItems.map(p => {
                const total = laporan.filter(l => l.pesertaId === p.id).length;
                const approved = laporan.filter(l => l.pesertaId === p.id && l.status === "Approved").length;
                const progress = total ? Math.round((approved / total) * 100) : 0;
                const nilai = getNilaiAkhir(p.id).akhir;
                return (
                  <TableRow key={p.id}>
                    <TableCell className="font-medium">{p.nama}</TableCell>
                    <TableCell>{nm(p.institusiId, institusi)}</TableCell>
                    <TableCell>{p.programStudi}</TableCell>
                    <TableCell>{nm(p.periodeId, periode)}</TableCell>
                    <TableCell><StatusBadge status={p.status} /></TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 min-w-[140px]"><Progress value={progress} className="h-2 flex-1" /><span className="text-xs w-10 text-right">{progress}%</span></div>
                    </TableCell>
                    <TableCell className="font-semibold text-[#0B2D72]">{nilai || "-"}</TableCell>
                    <TableCell><Button size="icon" variant="ghost" onClick={() => setDetail(p)}><Eye className="h-4 w-4" /></Button></TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>

      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Detail Peserta</DialogTitle></DialogHeader>
          {detail && (
            <div className="space-y-2 text-sm">
              <div><b>Nama:</b> {detail.nama}</div>
              <div><b>Email:</b> {detail.email}</div>
              <div><b>Telepon:</b> {detail.telepon}</div>
              <div><b>Institusi:</b> {nm(detail.institusiId, institusi)}</div>
              <div><b>Program Studi:</b> {detail.programStudi}</div>
              <div><b>Periode:</b> {nm(detail.periodeId, periode)}</div>
              <div><b>Status:</b> <StatusBadge status={detail.status} /></div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
