import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import { RichTextEditor, RichText, isRichTextEmpty } from "@/components/RichText";
import { DeadlineBadge, ProgresList } from "@/components/TugasBits";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { STATUS_TUGAS, formatTanggal, adaProgresBaru } from "@/lib/tugas";
import { Plus, Pencil, Trash2, ClipboardList, Bell, Calendar } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import type { StatusTugas, SubTugasInput, Tugas } from "@/lib/api";

export const Route = createFileRoute("/mentor/tugas")({ component: Page });

type SubRow = { id?: string; judul: string; tanggalMulai: string; tanggalSelesai: string };
const today = () => new Date().toISOString().slice(0, 10);

function Page() {
  const {
    user,
    tugas,
    peserta,
    addTugas,
    updateTugas,
    reviewTugas,
    deleteTugas,
    setSubTugasStatus,
  } = useStore();
  const mentorId = user?.mentorId;
  const bimbingan = useMemo(
    () => peserta.filter((p) => p.mentorId === mentorId),
    [peserta, mentorId],
  );
  const mine = useMemo(() => tugas.filter((t) => t.mentorId === mentorId), [tugas, mentorId]);

  const [pesertaFilter, setPesertaFilter] = useState("semua");
  const [statusFilter, setStatusFilter] = useState("semua");

  const filtered = useMemo(
    () =>
      mine
        .filter((t) => pesertaFilter === "semua" || t.pesertaId === pesertaFilter)
        .filter((t) => statusFilter === "semua" || t.status === statusFilter)
        .sort((a, b) => a.tanggalSelesai.localeCompare(b.tanggalSelesai)),
    [mine, pesertaFilter, statusFilter],
  );
  const pg = usePagination(filtered);

  const namaPeserta = (id: string) => peserta.find((p) => p.id === id)?.nama ?? "-";

  // --- Form buat / ubah tugas ---
  const [formOpen, setFormOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [fPeserta, setFPeserta] = useState("");
  const [fJudul, setFJudul] = useState("");
  const [fDeskripsi, setFDeskripsi] = useState("");
  const [fMulai, setFMulai] = useState(today());
  const [fSelesai, setFSelesai] = useState(today());
  const [fSub, setFSub] = useState<SubRow[]>([]);

  const openCreate = () => {
    setEditId(null);
    setFPeserta(bimbingan[0]?.id ?? "");
    setFJudul("");
    setFDeskripsi("");
    setFMulai(today());
    setFSelesai(today());
    setFSub([]);
    setFormOpen(true);
  };

  const openEdit = (t: Tugas) => {
    setEditId(t.id);
    setFPeserta(t.pesertaId);
    setFJudul(t.judul);
    setFDeskripsi(t.deskripsi);
    setFMulai(t.tanggalMulai);
    setFSelesai(t.tanggalSelesai);
    setFSub(
      t.subTugas.map((s) => ({
        id: s.id,
        judul: s.judul,
        tanggalMulai: s.tanggalMulai ?? "",
        tanggalSelesai: s.tanggalSelesai ?? "",
      })),
    );
    setFormOpen(true);
  };

  const submitForm = async () => {
    if (!fPeserta) return toast.error("Pilih peserta terlebih dulu.");
    if (!fJudul.trim()) return toast.error("Judul tugas wajib diisi.");
    if (isRichTextEmpty(fDeskripsi)) return toast.error("Deskripsi tugas wajib diisi.");
    if (fSelesai < fMulai) return toast.error("Tanggal selesai tidak boleh sebelum tanggal mulai.");

    const subTugas: SubTugasInput[] = fSub
      .filter((s) => s.judul.trim())
      .map((s) => ({
        id: s.id,
        judul: s.judul.trim(),
        tanggalMulai: s.tanggalMulai || null,
        tanggalSelesai: s.tanggalSelesai || null,
      }));

    const payload = {
      judul: fJudul.trim(),
      deskripsi: fDeskripsi,
      tanggalMulai: fMulai,
      tanggalSelesai: fSelesai,
      subTugas,
    };
    const err = editId
      ? await updateTugas(editId, payload)
      : await addTugas({ pesertaId: fPeserta, ...payload });
    if (err) return toast.error(err);
    toast.success(editId ? "Tugas diperbarui." : "Tugas berhasil diberikan ke peserta.");
    setFormOpen(false);
  };

  // --- Tinjau tugas ---
  const [reviewId, setReviewId] = useState<string | null>(null);
  const reviewTask = useMemo(() => tugas.find((t) => t.id === reviewId) ?? null, [tugas, reviewId]);
  const [rStatus, setRStatus] = useState<StatusTugas>("Dikerjakan");
  const [rNilai, setRNilai] = useState("85");
  const [rKomentar, setRKomentar] = useState("");

  const openReview = (t: Tugas) => {
    setReviewId(t.id);
    setRStatus(t.status === "Ditugaskan" ? "Dikerjakan" : t.status);
    setRNilai(String(t.nilai ?? 85));
    setRKomentar(t.komentar ?? "");
  };

  const submitReview = async () => {
    if (!reviewTask) return;
    const nilai = parseInt(rNilai, 10);
    const err = await reviewTugas(
      reviewTask.id,
      rStatus,
      Number.isNaN(nilai) ? undefined : nilai,
      rKomentar,
    );
    if (err) return toast.error(err);
    toast.success("Tinjauan tersimpan.");
    setReviewId(null);
  };

  const [hapus, setHapus] = useState<Tugas | null>(null);
  const confirmHapus = async () => {
    if (!hapus) return;
    const err = await deleteTugas(hapus.id);
    setHapus(null);
    if (err) return toast.error(err);
    toast.success("Tugas dihapus.");
  };

  return (
    <>
      <PageHeader
        title="Tugas & Bimbingan"
        description="Berikan tugas bertahap ke peserta, lalu tinjau progres dan beri penilaian."
        actions={
          <Button
            onClick={openCreate}
            className="bg-[#0B2D72] hover:bg-[#0B2D72]/90"
            disabled={bimbingan.length === 0}
          >
            <Plus className="mr-2 h-4 w-4" /> Buat Tugas
          </Button>
        }
      />

      <Card className="mb-4 p-4">
        <div className="grid gap-3 sm:grid-cols-3">
          <Select value={pesertaFilter} onValueChange={setPesertaFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Peserta" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Peserta</SelectItem>
              {bimbingan.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.nama}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Status</SelectItem>
              {STATUS_TUGAS.map((s) => (
                <SelectItem key={s} value={s}>
                  {s === "Revisi" ? "Perlu Revisi" : s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            onClick={() => {
              setPesertaFilter("semua");
              setStatusFilter("semua");
            }}
          >
            Reset Filter
          </Button>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <Card className="p-10 text-center text-sm text-muted-foreground">
          <ClipboardList className="mx-auto mb-3 h-10 w-10 text-[#0992C2]" />
          {mine.length === 0
            ? 'Belum ada tugas. Klik "Buat Tugas" untuk memberi tugas pertama.'
            : "Tidak ada tugas yang cocok dengan filter."}
        </Card>
      ) : (
        <div className="space-y-3">
          {pg.pageItems.map((t) => {
            const progresBaru = adaProgresBaru(t);
            const subSelesai = t.subTugas.filter((s) => s.status === "Selesai").length;
            return (
              <Card key={t.id} className="p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-[#0B2D72]">{t.judul}</span>
                      <StatusBadge status={t.status} />
                      <DeadlineBadge tugas={t} />
                      {progresBaru && (
                        <span className="inline-flex items-center gap-1 rounded-full border border-[#0AC4E0]/40 bg-[#0AC4E0]/10 px-2 py-0.5 text-[11px] font-medium text-[#076e7f]">
                          <Bell className="h-3 w-3" /> Progres baru
                        </span>
                      )}
                    </div>
                    <div className="mt-1 text-sm text-muted-foreground">
                      {namaPeserta(t.pesertaId)} • <Calendar className="inline h-3 w-3" />{" "}
                      {formatTanggal(t.tanggalMulai)} – {formatTanggal(t.tanggalSelesai)}
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {t.subTugas.length > 0 && (
                        <>
                          Sub-tugas {subSelesai}/{t.subTugas.length} selesai •{" "}
                        </>
                      )}
                      {t.progres.length} laporan progres{t.nilai != null && <> • Nilai {t.nilai}</>}
                    </div>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button
                      size="sm"
                      onClick={() => openReview(t)}
                      className="bg-[#0B2D72] hover:bg-[#0B2D72]/90"
                    >
                      Tinjau
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => openEdit(t)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-600"
                      onClick={() => setHapus(t)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
          <DataPagination {...pg} />
        </div>
      )}

      {/* Dialog buat / ubah tugas */}
      <Dialog open={formOpen} onOpenChange={(o) => !o && setFormOpen(false)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editId ? "Ubah Tugas" : "Buat Tugas Baru"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Peserta *</Label>
              <Select value={fPeserta} onValueChange={setFPeserta} disabled={!!editId}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih peserta" />
                </SelectTrigger>
                <SelectContent>
                  {bimbingan.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.nama}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Judul Tugas *</Label>
              <Input
                value={fJudul}
                onChange={(e) => setFJudul(e.target.value)}
                placeholder="mis. Buat Modul Pembayaran"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Deskripsi & Instruksi *</Label>
              <RichTextEditor
                value={fDeskripsi}
                onChange={setFDeskripsi}
                placeholder="Jelaskan kebutuhan tugas, ekspektasi output, dan acuan…"
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Tanggal Mulai *</Label>
                <Input type="date" value={fMulai} onChange={(e) => setFMulai(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Deadline *</Label>
                <Input type="date" value={fSelesai} onChange={(e) => setFSelesai(e.target.value)} />
              </div>
            </div>

            <div className="space-y-2 rounded-md border p-3">
              <div className="flex items-center justify-between">
                <Label>Sub-tugas (tahapan)</Label>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() =>
                    setFSub((s) => [...s, { judul: "", tanggalMulai: "", tanggalSelesai: "" }])
                  }
                >
                  <Plus className="mr-1 h-3.5 w-3.5" /> Tambah
                </Button>
              </div>
              {fSub.length === 0 && (
                <div className="text-xs text-muted-foreground">
                  Opsional. Pecah tugas besar menjadi tahapan, mis. desain → breakdown →
                  development.
                </div>
              )}
              {fSub.map((s, i) => (
                <div
                  key={i}
                  className="grid gap-2 sm:grid-cols-[1fr_auto_auto_auto] sm:items-center"
                >
                  <Input
                    value={s.judul}
                    placeholder={`Tahap ${i + 1}`}
                    onChange={(e) =>
                      setFSub((arr) =>
                        arr.map((x, j) => (j === i ? { ...x, judul: e.target.value } : x)),
                      )
                    }
                  />
                  <Input
                    type="date"
                    className="sm:w-36"
                    value={s.tanggalMulai}
                    onChange={(e) =>
                      setFSub((arr) =>
                        arr.map((x, j) => (j === i ? { ...x, tanggalMulai: e.target.value } : x)),
                      )
                    }
                  />
                  <Input
                    type="date"
                    className="sm:w-36"
                    value={s.tanggalSelesai}
                    onChange={(e) =>
                      setFSub((arr) =>
                        arr.map((x, j) => (j === i ? { ...x, tanggalSelesai: e.target.value } : x)),
                      )
                    }
                  />
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    className="text-red-600"
                    onClick={() => setFSub((arr) => arr.filter((_, j) => j !== i))}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>
              Batal
            </Button>
            <Button onClick={submitForm} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">
              {editId ? "Simpan Perubahan" : "Berikan Tugas"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog tinjau tugas */}
      <Dialog open={!!reviewId} onOpenChange={(o) => !o && setReviewId(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Tinjau Tugas</DialogTitle>
          </DialogHeader>
          {reviewTask && (
            <div className="space-y-4 text-sm">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold text-[#0B2D72]">{reviewTask.judul}</span>
                  <StatusBadge status={reviewTask.status} />
                  <DeadlineBadge tugas={reviewTask} />
                </div>
                <div className="mt-0.5 text-xs text-muted-foreground">
                  {namaPeserta(reviewTask.pesertaId)} • {formatTanggal(reviewTask.tanggalMulai)} –{" "}
                  {formatTanggal(reviewTask.tanggalSelesai)}
                </div>
              </div>

              <div className="rounded-md bg-muted/40 p-3">
                <div className="mb-1 text-xs font-medium text-muted-foreground">
                  Instruksi Tugas
                </div>
                <RichText html={reviewTask.deskripsi} />
              </div>

              {reviewTask.subTugas.length > 0 && (
                <div>
                  <div className="mb-1.5 text-xs font-medium text-muted-foreground">
                    Sub-tugas — Anda yang menetapkan status tiap tahap
                  </div>
                  <div className="space-y-2">
                    {reviewTask.subTugas.map((s) => (
                      <div
                        key={s.id}
                        className="flex flex-wrap items-center justify-between gap-2 rounded-md border px-3 py-2"
                      >
                        <div className="min-w-0">
                          <div className="truncate font-medium">{s.judul}</div>
                          {(s.tanggalMulai || s.tanggalSelesai) && (
                            <div className="text-xs text-muted-foreground">
                              {formatTanggal(s.tanggalMulai)} – {formatTanggal(s.tanggalSelesai)}
                            </div>
                          )}
                        </div>
                        <Select
                          value={s.status}
                          onValueChange={(v) => void setSubTugasStatus(s.id, v as StatusTugas)}
                        >
                          <SelectTrigger className="h-8 w-36">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {STATUS_TUGAS.map((st) => (
                              <SelectItem key={st} value={st}>
                                {st === "Revisi" ? "Perlu Revisi" : st}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <div className="mb-1.5 text-xs font-medium text-muted-foreground">
                  Laporan Progres & Bukti dari Peserta
                </div>
                <ProgresList
                  progres={reviewTask.progres}
                  emptyText="Peserta belum mengirim laporan progres."
                />
              </div>

              <div className="space-y-3 rounded-md border border-[#0B2D72]/15 bg-[#0B2D72]/5 p-3">
                <div className="text-xs font-semibold text-[#0B2D72]">Keputusan Mentor</div>
                <div className="space-y-1.5">
                  <Label>Status Penyelesaian</Label>
                  <Select value={rStatus} onValueChange={(v) => setRStatus(v as StatusTugas)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS_TUGAS.map((st) => (
                        <SelectItem key={st} value={st}>
                          {st === "Revisi" ? "Perlu Revisi" : st}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {rStatus === "Selesai" && (
                  <div className="space-y-1.5">
                    <Label>Nilai Tugas (1-100) *</Label>
                    <Input
                      type="number"
                      min={1}
                      max={100}
                      value={rNilai}
                      onChange={(e) => setRNilai(e.target.value)}
                    />
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label>Feedback {rStatus === "Revisi" && "*"}</Label>
                  <Textarea
                    value={rKomentar}
                    onChange={(e) => setRKomentar(e.target.value)}
                    placeholder={
                      rStatus === "Revisi"
                        ? "Jelaskan apa yang perlu diperbaiki"
                        : "Catatan / apresiasi untuk peserta (opsional)"
                    }
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setReviewId(null)}>
              Tutup
            </Button>
            <Button onClick={submitReview} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">
              Simpan Tinjauan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!hapus} onOpenChange={(o) => !o && setHapus(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus tugas ini?</AlertDialogTitle>
            <AlertDialogDescription>
              Tugas "{hapus?.judul}" beserta sub-tugas dan laporan progresnya akan dihapus permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-600/90" onClick={confirmHapus}>
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
