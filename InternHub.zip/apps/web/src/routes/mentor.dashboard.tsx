import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { StatusBadge } from "@/components/StatusBadge";
import { DeadlineBadge } from "@/components/TugasBits";
import { adaProgresBaru } from "@/lib/tugas";
import { Users, ClipboardList, Bell, CheckCircle2, BookOpenCheck } from "lucide-react";

export const Route = createFileRoute("/mentor/dashboard")({ component: Page });

function Stat({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: any;
  label: string;
  value: number;
  accent: string;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-muted-foreground">{label}</div>
          <div className="text-2xl font-bold text-[#0B2D72] mt-1">{value}</div>
        </div>
        <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${accent}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}

function Page() {
  const { user, peserta, tugas, evaluasi, institusi } = useStore();
  const mentorId = user?.mentorId;
  const bimbingan = peserta.filter((p) => p.mentorId === mentorId);
  const mineTugas = tugas.filter((t) => t.mentorId === mentorId);

  const berjalan = mineTugas.filter((t) => t.status !== "Selesai");
  const perluTinjau = mineTugas.filter((t) => t.status !== "Selesai" && adaProgresBaru(t));
  const selesai = mineTugas.filter((t) => t.status === "Selesai").length;
  const belumEval = bimbingan.filter(
    (p) => p.status === "Selesai" && !evaluasi.find((e) => e.pesertaId === p.id),
  ).length;

  const nmInst = (id: string) => institusi.find((i) => i.id === id)?.nama ?? "-";
  const nmP = (id: string) => peserta.find((p) => p.id === id)?.nama ?? "-";

  const antrian = [...perluTinjau, ...berjalan.filter((t) => !perluTinjau.includes(t))].slice(0, 6);

  return (
    <>
      <PageHeader
        title={`Halo, ${user?.nama ?? "Mentor"}`}
        description="Ringkasan bimbingan dan penugasan Anda."
      />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Stat
          icon={Users}
          label="Peserta Bimbingan"
          value={bimbingan.length}
          accent="bg-[#0B2D72]/10 text-[#0B2D72]"
        />
        <Stat
          icon={ClipboardList}
          label="Tugas Berjalan"
          value={berjalan.length}
          accent="bg-[#0992C2]/15 text-[#0992C2]"
        />
        <Stat
          icon={Bell}
          label="Perlu Ditinjau"
          value={perluTinjau.length}
          accent="bg-amber-50 text-amber-600"
        />
        <Stat
          icon={CheckCircle2}
          label="Tugas Selesai"
          value={selesai}
          accent="bg-emerald-50 text-emerald-600"
        />
        <Stat
          icon={BookOpenCheck}
          label="Evaluasi Belum Diisi"
          value={belumEval}
          accent="bg-[#0992C2]/15 text-[#0992C2]"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2 mt-6">
        <Card className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <div className="font-semibold text-[#0B2D72]">Tugas Perlu Perhatian</div>
            <Button asChild size="sm" variant="outline">
              <Link to="/mentor/tugas">Kelola Tugas</Link>
            </Button>
          </div>
          {antrian.length === 0 ? (
            <div className="py-4 text-sm text-muted-foreground">
              Tidak ada tugas yang berjalan saat ini.
            </div>
          ) : (
            <div className="space-y-2">
              {antrian.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center justify-between gap-3 rounded-md border p-3"
                >
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">{t.judul}</div>
                    <div className="truncate text-xs text-muted-foreground">{nmP(t.pesertaId)}</div>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    {adaProgresBaru(t) && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-[#076e7f]">
                        <Bell className="h-3 w-3" />
                        baru
                      </span>
                    )}
                    <DeadlineBadge tugas={t} />
                    <StatusBadge status={t.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
        <Card className="p-5">
          <div className="font-semibold text-[#0B2D72] mb-3">Peserta Bimbingan</div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nama</TableHead>
                <TableHead>Institusi</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {bimbingan.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.nama}</TableCell>
                  <TableCell>{nmInst(p.institusiId)}</TableCell>
                  <TableCell>
                    <StatusBadge status={p.status} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>
    </>
  );
}
