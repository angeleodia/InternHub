import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { StatusBadge } from "@/components/StatusBadge";
import { usePagination, DataPagination } from "@/components/DataPagination";

export const Route = createFileRoute("/admin/nilai")({ component: Page });

function Page() {
  const { peserta, institusi, periode, getNilaiAkhir } = useStore();
  const nm = (id: string, list: { id: string; nama: string }[]) =>
    list.find((x) => x.id === id)?.nama ?? "-";
  const pg = usePagination(peserta);

  return (
    <>
      <PageHeader
        title="Rekap Nilai Akhir"
        description="Perhitungan: kehadiran 30%, nilai tugas 30%, dan evaluasi akhir 40%."
      />
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nama</TableHead>
                <TableHead>Institusi</TableHead>
                <TableHead>Periode</TableHead>
                <TableHead>Kehadiran</TableHead>
                <TableHead>Tugas</TableHead>
                <TableHead>Evaluasi</TableHead>
                <TableHead>Nilai Akhir</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pg.pageItems.map((p) => {
                const n = getNilaiAkhir(p.id);
                return (
                  <TableRow key={p.id}>
                    <TableCell className="font-medium">{p.nama}</TableCell>
                    <TableCell>{nm(p.institusiId, institusi)}</TableCell>
                    <TableCell>{nm(p.periodeId, periode)}</TableCell>
                    <TableCell>{n.kehadiran}</TableCell>
                    <TableCell>{n.tugas}</TableCell>
                    <TableCell>{n.evaluasi || "-"}</TableCell>
                    <TableCell>
                      <span className="font-bold text-[#0B2D72]">{n.akhir}</span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={p.status} />
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>
    </>
  );
}
