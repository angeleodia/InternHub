import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Award } from "lucide-react";

export const Route = createFileRoute("/user/nilai")({ component: Page });

function Page() {
  const { user, peserta, evaluasi, getNilaiAkhir } = useStore();
  const me = peserta.find((p) => p.id === user?.pesertaId)!;
  const n = getNilaiAkhir(me.id);
  const evaluasiAkhir = evaluasi.find((e) => e.pesertaId === me.id);
  const selesai = me.status === "Selesai";

  return (
    <>
      <PageHeader
        title="Nilai Akhir"
        description="Perhitungan: kehadiran 30%, nilai tugas 30%, dan evaluasi akhir 40%."
      />
      {!selesai ? (
        <Card className="p-10 text-center bg-[#F6E7BC]/30">
          <Award className="h-10 w-10 mx-auto text-[#0992C2] mb-3" />
          <div className="font-medium text-[#0B2D72]">
            Nilai akhir akan tersedia setelah periode magang selesai.
          </div>
          <div className="text-sm text-muted-foreground mt-1">
            Tetap semangat menyelesaikan program magang!
          </div>
        </Card>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-3">
            <Bar label="Nilai Kehadiran" value={n.kehadiran} weight="30%" />
            <Bar label="Nilai Tugas" value={n.tugas} weight="30%" />
            <Bar label="Nilai Evaluasi Akhir" value={n.evaluasi} weight="40%" />
          </div>
          <Card className="p-8 mt-6 bg-gradient-to-br from-[#0B2D72] to-[#0992C2] text-white text-center">
            <div className="text-sm text-white/70">Nilai Akhir</div>
            <div className="text-6xl font-bold mt-2">{n.akhir}</div>
            <div className="text-xs text-white/60 mt-3">
              Berdasarkan formula gabungan kehadiran, nilai tugas, dan evaluasi mentor.
            </div>
          </Card>
          <Card className="p-5 mt-4">
            <div className="text-sm text-muted-foreground">Catatan Evaluasi Akhir</div>
            <div className="mt-2 text-sm leading-6 whitespace-pre-line text-[#0B2D72]">
              {evaluasiAkhir?.komentar?.trim() || "Catatan evaluasi belum tersedia."}
            </div>
            {evaluasiAkhir?.tanggal && (
              <div className="text-xs text-muted-foreground mt-3">
                Tanggal evaluasi: {evaluasiAkhir.tanggal}
              </div>
            )}
          </Card>
        </>
      )}
    </>
  );
}

function Bar({ label, value, weight }: { label: string; value: number; weight: string }) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">{label}</div>
        <span className="text-xs bg-[#0992C2]/10 text-[#0992C2] px-2 py-0.5 rounded">{weight}</span>
      </div>
      <div className="text-3xl font-bold text-[#0B2D72] my-2">{value}</div>
      <Progress value={value} className="h-2" />
    </Card>
  );
}
