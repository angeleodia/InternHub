import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/StatusBadge";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { useState } from "react";
import { Plus, Pencil, Power, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { Akun, Role, StatusAkun } from "@/lib/api";

export const Route = createFileRoute("/admin/akun")({ component: Page });

function Page() {
  const { akun, mentor, addAkun, updateAkun, toggleAkunStatus, deleteAkun } = useStore();
  const pg = usePagination(akun);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Akun | null>(null);
  const [delId, setDelId] = useState<string | null>(null);
  const [form, setForm] = useState<{ nama: string; email: string; role: Role; status: StatusAkun; password: string; departemen: string; telepon: string }>({
    nama: "",
    email: "",
    role: "user",
    status: "Aktif",
    password: "",
    departemen: "",
    telepon: "",
  });

  const mentorByEmail = (email: string) => mentor.find((item) => item.email === email);
  const emptyForm = { nama: "", email: "", role: "user" as Role, status: "Aktif" as StatusAkun, password: "", departemen: "", telepon: "" };
  const openAdd = () => { setEditing(null); setForm(emptyForm); setOpen(true); };
  const openEdit = (a: Akun) => {
    const profile = mentorByEmail(a.email);
    setEditing(a);
    setForm({
      nama: a.nama,
      email: a.email,
      role: a.role,
      status: a.status,
      password: "",
      departemen: a.departemen ?? profile?.departemen ?? "",
      telepon: a.telepon ?? profile?.telepon ?? "",
    });
    setOpen(true);
  };
  const submit = async () => {
    if (!form.nama || !form.email) { toast.error("Nama dan email wajib diisi."); return; }
    if (form.role === "mentor" && !form.departemen.trim()) { toast.error("Departemen mentor wajib diisi."); return; }
    if (!editing && form.password.trim().length < 6) { toast.error("Password awal minimal 6 karakter."); return; }
    if (editing && form.password.trim() && form.password.trim().length < 6) { toast.error("Password baru minimal 6 karakter."); return; }

    let err: string | null;
    if (editing) {
      const payload: Partial<Akun> = {
        nama: form.nama,
        email: form.email,
        role: form.role,
        status: form.status,
        departemen: form.role === "mentor" ? form.departemen.trim() : undefined,
        telepon: form.role === "mentor" ? form.telepon.trim() : undefined,
      };
      if (form.password.trim()) payload.password = form.password.trim();
      err = await updateAkun(editing.id, payload);
      if (err) { toast.error(err); return; }
      toast.success("Akun diperbarui.");
    } else {
      err = await addAkun({
        ...form,
        departemen: form.role === "mentor" ? form.departemen.trim() : undefined,
        telepon: form.role === "mentor" ? form.telepon.trim() : undefined,
        password: form.password.trim(),
      });
      if (err) { toast.error(err); return; }
      toast.success("Akun ditambahkan.");
    }
    setOpen(false);
  };

  return (
    <>
      <PageHeader title="Akun Pengguna" description="Kelola akses admin, mentor, dan peserta."
        actions={<Button onClick={openAdd} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90"><Plus className="h-4 w-4 mr-2" />Tambah Akun</Button>}
      />
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Nama</TableHead><TableHead>Email</TableHead>
              <TableHead>Jenis Akun</TableHead><TableHead>Departemen</TableHead><TableHead>Status</TableHead>
              <TableHead>Tanggal Dibuat</TableHead><TableHead className="text-right">Aksi</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {pg.pageItems.map(a => (
                <TableRow key={a.id}>
                  <TableCell className="font-medium">{a.nama}</TableCell>
                  <TableCell>{a.email}</TableCell>
                  <TableCell><span className="text-xs font-medium text-[#0992C2]">{roleLabel(a.role)}</span></TableCell>
                  <TableCell className="text-sm text-muted-foreground">{a.role === "mentor" ? (a.departemen ?? mentorByEmail(a.email)?.departemen ?? "-") : "-"}</TableCell>
                  <TableCell><StatusBadge status={a.status} /></TableCell>
                  <TableCell className="text-sm text-muted-foreground">{a.dibuat}</TableCell>
                  <TableCell className="text-right">
                    <Button size="icon" variant="ghost" onClick={() => openEdit(a)}><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={async () => {
                      const err = await toggleAkunStatus(a.id);
                      if (err) toast.error(err); else toast.success("Status akun diubah.");
                    }}>
                      <Power className={`h-4 w-4 ${a.status === "Aktif" ? "text-red-600" : "text-[#0AC4E0]"}`} />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => setDelId(a.id)}>
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit Akun" : "Tambah Akun"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5"><Label>Nama</Label><Input value={form.nama} onChange={e => setForm({ ...form, nama: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-1.5">
              <Label>{editing ? "Password Baru (opsional)" : "Password Awal"}</Label>
              <Input
                type="password"
                value={form.password}
                placeholder={editing ? "Kosongkan jika tidak diubah" : "Minimal 6 karakter"}
                onChange={e => setForm({ ...form, password: e.target.value })}
              />
            </div>
            <div className="space-y-1.5"><Label>Jenis Akun</Label>
              <Select value={form.role} onValueChange={v => setForm({ ...form, role: v as Role })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="mentor">Mentor</SelectItem>
                  <SelectItem value="user">Peserta</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {form.role === "mentor" && (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label>Departemen Mentor</Label>
                  <Input value={form.departemen} placeholder="Contoh: IT" onChange={e => setForm({ ...form, departemen: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Nomor Telepon Mentor</Label>
                  <Input value={form.telepon} placeholder="Opsional" onChange={e => setForm({ ...form, telepon: e.target.value })} />
                </div>
              </div>
            )}
            <div className="space-y-1.5"><Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm({ ...form, status: v as StatusAkun })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Aktif">Aktif</SelectItem>
                  <SelectItem value="Nonaktif">Nonaktif</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Batal</Button>
            <Button onClick={submit} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Akun?</AlertDialogTitle>
            <AlertDialogDescription>
              Akun akan dihapus dari daftar pengguna InternHub.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={async () => {
                if (delId) {
                  const err = await deleteAkun(delId);
                  if (err) toast.error(err); else toast.success("Akun dihapus.");
                }
                setDelId(null);
              }}
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function roleLabel(role: Role) {
  if (role === "admin") return "Admin";
  if (role === "mentor") return "Mentor";
  return "Peserta";
}
