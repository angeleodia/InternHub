import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/StatusBadge";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { useMemo, useState } from "react";

export const Route = createFileRoute("/admin/absensi")({ component: Page });

function Page() {
  const { peserta, periode, absensi } = useStore();
  const today = new Date().toISOString().slice(0, 10);
  const [tgl, setTgl] = useState(today);
  const [per, setPer] = useState("semua");
  const [pst, setPst] = useState("semua");

  const list = useMemo(() => peserta
    .filter(p => per === "semua" || p.periodeId === per)
    .filter(p => pst === "semua" || p.id === pst)
    .map(p => {
      const a = absensi.find(x => x.pesertaId === p.id && x.tanggal === tgl);
      return { p, hadir: !!a, jam: a?.jam };
    }), [peserta, absensi, per, pst, tgl]);
  const pg = usePagination(list);

  const hadir = list.filter(x => x.hadir).length;

  return (
    <>
      <PageHeader title="Absensi Peserta" description="Pantau kehadiran peserta magang per tanggal." />
      <Card className="p-4 mb-4">
        <div className="grid gap-3 sm:grid-cols-4">
          <div><label className="text-xs text-muted-foreground">Tanggal</label><Input type="date" value={tgl} onChange={e => setTgl(e.target.value)} /></div>
          <div>
            <label className="text-xs text-muted-foreground">Periode</label>
            <Select value={per} onValueChange={setPer}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="semua">Semua Periode</SelectItem>
                {periode.map(p => <SelectItem key={p.id} value={p.id}>{p.nama}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Peserta</label>
            <Select value={pst} onValueChange={setPst}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="semua">Semua Peserta</SelectItem>
                {peserta.map(p => <SelectItem key={p.id} value={p.id}>{p.nama}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end gap-3 text-sm">
            <div className="rounded-md bg-[#0AC4E0]/10 text-[#076e7f] px-3 py-2 flex-1 text-center"><div className="text-xs">Hadir</div><div className="font-bold">{hadir}</div></div>
            <div className="rounded-md bg-gray-100 text-gray-700 px-3 py-2 flex-1 text-center"><div className="text-xs">Belum</div><div className="font-bold">{list.length - hadir}</div></div>
          </div>
        </div>
      </Card>
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Peserta</TableHead><TableHead>Status</TableHead><TableHead>Jam Absen</TableHead><TableHead>Tanggal</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {pg.pageItems.map(({ p, hadir, jam }) => (
                <TableRow key={p.id}>
                  <TableCell>
                    <div className="font-medium">{p.nama}</div>
                    <div className="text-xs text-muted-foreground">{p.email}</div>
                  </TableCell>
                  <TableCell><StatusBadge status={hadir ? "Hadir" : "Belum Hadir"} /></TableCell>
                  <TableCell>{jam ?? "-"}</TableCell>
                  <TableCell>{tgl}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>
    </>
  );
}
