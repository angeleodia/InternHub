import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { CalendarCheck, FileText, Award, ClipboardList } from "lucide-react";

export const Route = createFileRoute("/user/dashboard")({ component: Page });

function Page() {
  const { user, peserta, periode, mentor, absensi, laporan, tugas, getNilaiAkhir } = useStore();
  const me = peserta.find((p) => p.id === user?.pesertaId);
  const today = new Date().toISOString().slice(0, 10);
  if (!me) return null;
  const sudahAbsen = absensi.some((a) => a.pesertaId === me.id && a.tanggal === today);
  const mine = laporan.filter((l) => l.pesertaId === me.id);
  const myTugas = tugas.filter((t) => t.pesertaId === me.id);
  const tugasAktif = myTugas.filter((t) => t.status !== "Selesai");
  const tugasRevisi = myTugas.filter((t) => t.status === "Revisi").length;
  const nilai = getNilaiAkhir(me.id);
  const per = periode.find((p) => p.id === me.periodeId);
  const mn = mentor.find((m) => m.id === me.mentorId);

  return (
    <>
      <PageHeader
        title={`Halo, ${me.nama.split(" ")[0]}`}
        description="Ringkasan aktivitas magang Anda."
      />

      <Card className="p-5 bg-gradient-to-br from-[#0B2D72] to-[#0992C2] text-white mb-6">
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <div className="text-xs text-white/70">Status Magang</div>
            <div className="font-semibold text-lg">{me.status}</div>
          </div>
          <div>
            <div className="text-xs text-white/70">Periode</div>
            <div className="font-semibold">{per?.nama}</div>
          </div>
          <div>
            <div className="text-xs text-white/70">Mentor</div>
            <div className="font-semibold">{mn?.nama}</div>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="p-5">
          <div className="text-xs text-muted-foreground">Absensi Hari Ini</div>
          <div className="mt-2">
            <StatusBadge status={sudahAbsen ? "Hadir" : "Belum Hadir"} />
          </div>
          <Button
            asChild
            size="sm"
            className="mt-4 w-full bg-[#0B2D72] hover:bg-[#0B2D72]/90"
            disabled={sudahAbsen}
          >
            <Link to="/user/absensi">
              <CalendarCheck className="h-4 w-4 mr-2" />
              {sudahAbsen ? "Sudah Absen" : "Absen Sekarang"}
            </Link>
          </Button>
        </Card>
        <Card className="p-5">
          <div className="text-xs text-muted-foreground">Tugas Aktif</div>
          <div className="text-2xl font-bold text-[#0B2D72] mt-1">{tugasAktif.length}</div>
          {tugasRevisi > 0 ? (
            <div className="mt-1 text-[11px] font-medium text-amber-700">
              {tugasRevisi} perlu direvisi
            </div>
          ) : (
            <div className="mt-1 text-[11px] text-muted-foreground">
              dari {myTugas.length} total tugas
            </div>
          )}
          <Button asChild size="sm" className="mt-3 w-full bg-[#0B2D72] hover:bg-[#0B2D72]/90">
            <Link to="/user/tugas">
              <ClipboardList className="h-4 w-4 mr-2" />
              Lihat Tugas
            </Link>
          </Button>
        </Card>
        <Card className="p-5">
          <div className="text-xs text-muted-foreground">Logbook Harian</div>
          <div className="text-2xl font-bold text-[#0B2D72] mt-1">{mine.length}</div>
          <div className="mt-1 text-[11px] text-muted-foreground">catatan kegiatan</div>
          <Button asChild size="sm" variant="outline" className="mt-3 w-full">
            <Link to="/user/laporan">
              <FileText className="h-4 w-4 mr-2" />
              Buka Logbook
            </Link>
          </Button>
        </Card>
        <Card className="p-5">
          <div className="text-xs text-muted-foreground">Nilai Akhir</div>
          {me.status === "Selesai" ? (
            <div className="flex items-center gap-2 mt-1">
              <Award className="h-6 w-6 text-[#0AC4E0]" />
              <span className="text-2xl font-bold text-[#0B2D72]">{nilai.akhir}</span>
            </div>
          ) : (
            <div className="text-xs text-muted-foreground mt-2">
              Tersedia setelah periode selesai.
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
