import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { RichText } from "@/components/RichText";
import { DeadlineBadge, ProgresList } from "@/components/TugasBits";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { STATUS_TUGAS, formatTanggal } from "@/lib/tugas";
import { Eye } from "lucide-react";
import { useMemo, useState } from "react";
import type { Tugas } from "@/lib/api";

export const Route = createFileRoute("/admin/tugas")({ component: Page });

function Page() {
  const { tugas, peserta, mentor, periode } = useStore();
  const [st, setSt] = useState("semua");
  const [mt, setMt] = useState("semua");
  const [pr, setPr] = useState("semua");
  const [detail, setDetail] = useState<Tugas | null>(null);

  const nmP = (id: string) => peserta.find((p) => p.id === id)?.nama ?? "-";
  const nmM = (id: string) => mentor.find((m) => m.id === id)?.nama ?? "-";

  const filtered = useMemo(
    () =>
      tugas
        .filter((t) => st === "semua" || t.status === st)
        .filter((t) => mt === "semua" || t.mentorId === mt)
        .filter(
          (t) => pr === "semua" || peserta.find((p) => p.id === t.pesertaId)?.periodeId === pr,
        )
        .sort((a, b) => a.tanggalSelesai.localeCompare(b.tanggalSelesai)),
    [tugas, peserta, st, mt, pr],
  );
  const pg = usePagination(filtered);

  const hitung = (status: string) => tugas.filter((t) => t.status === status).length;

  return (
    <>
      <PageHeader
        title="Pantau Tugas"
        description="Pantau penugasan dan progres peserta di seluruh program."
      />

      <div className="mb-4 grid gap-4 sm:grid-cols-4">
        {STATUS_TUGAS.map((s) => (
          <Card key={s} className="p-4">
            <div className="text-xs text-muted-foreground">
              {s === "Revisi" ? "Perlu Revisi" : s}
            </div>
            <div className="mt-1 text-2xl font-bold text-[#0B2D72]">{hitung(s)}</div>
          </Card>
        ))}
      </div>

      <Card className="mb-4 p-4">
        <div className="grid gap-3 sm:grid-cols-3">
          <Select value={st} onValueChange={setSt}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Status</SelectItem>
              {STATUS_TUGAS.map((s) => (
                <SelectItem key={s} value={s}>
                  {s === "Revisi" ? "Perlu Revisi" : s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={mt} onValueChange={setMt}>
            <SelectTrigger>
              <SelectValue placeholder="Mentor" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Mentor</SelectItem>
              {mentor.map((m) => (
                <SelectItem key={m.id} value={m.id}>
                  {m.nama}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={pr} onValueChange={setPr}>
            <SelectTrigger>
              <SelectValue placeholder="Periode" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Periode</SelectItem>
              {periode.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.nama}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Peserta</TableHead>
                <TableHead>Mentor</TableHead>
                <TableHead>Tugas</TableHead>
                <TableHead>Deadline</TableHead>
                <TableHead>Sub-tugas</TableHead>
                <TableHead>Progres</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Nilai</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={9} className="py-10 text-center text-muted-foreground">
                    Tidak ada tugas.
                  </TableCell>
                </TableRow>
              )}
              {pg.pageItems.map((t) => (
                <TableRow key={t.id}>
                  <TableCell>{nmP(t.pesertaId)}</TableCell>
                  <TableCell>{nmM(t.mentorId)}</TableCell>
                  <TableCell className="max-w-xs truncate font-medium">{t.judul}</TableCell>
                  <TableCell className="whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      {formatTanggal(t.tanggalSelesai)} <DeadlineBadge tugas={t} />
                    </div>
                  </TableCell>
                  <TableCell>
                    {t.subTugas.filter((s) => s.status === "Selesai").length}/{t.subTugas.length}
                  </TableCell>
                  <TableCell>{t.progres.length}</TableCell>
                  <TableCell>
                    <StatusBadge status={t.status} />
                  </TableCell>
                  <TableCell>{t.nilai ?? "-"}</TableCell>
                  <TableCell>
                    <Button size="icon" variant="ghost" onClick={() => setDetail(t)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>

      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detail Tugas</DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="space-y-4 text-sm">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold text-[#0B2D72]">{detail.judul}</span>
                  <StatusBadge status={detail.status} />
                  <DeadlineBadge tugas={detail} />
                  {detail.nilai != null && (
                    <span className="text-xs text-muted-foreground">Nilai {detail.nilai}</span>
                  )}
                </div>
                <div className="mt-0.5 text-xs text-muted-foreground">
                  {nmP(detail.pesertaId)} • Mentor {nmM(detail.mentorId)} •{" "}
                  {formatTanggal(detail.tanggalMulai)} – {formatTanggal(detail.tanggalSelesai)}
                </div>
              </div>
              <div className="rounded-md bg-muted/40 p-3">
                <div className="mb-1 text-xs font-medium text-muted-foreground">Instruksi</div>
                <RichText html={detail.deskripsi} />
              </div>
              {detail.subTugas.length > 0 && (
                <div className="space-y-1.5">
                  <div className="text-xs font-medium text-muted-foreground">Sub-tugas</div>
                  {detail.subTugas.map((s) => (
                    <div
                      key={s.id}
                      className="flex items-center justify-between rounded-md border px-3 py-1.5"
                    >
                      <span>{s.judul}</span>
                      <StatusBadge status={s.status} />
                    </div>
                  ))}
                </div>
              )}
              {detail.komentar && (
                <div className="rounded-md border border-amber-200 bg-amber-50 p-3">
                  <div className="mb-1 text-xs font-medium text-muted-foreground">
                    Feedback Mentor
                  </div>
                  {detail.komentar}
                </div>
              )}
              <div>
                <div className="mb-1.5 text-xs font-medium text-muted-foreground">
                  Laporan Progres Peserta
                </div>
                <ProgresList progres={detail.progres} />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
