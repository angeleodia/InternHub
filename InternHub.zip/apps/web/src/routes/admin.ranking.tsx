import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trophy } from "lucide-react";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { useEffect, useState } from "react";
import { api, toFriendlyError, type RankingInstitusi } from "@/lib/api";

export const Route = createFileRoute("/admin/ranking")({ component: Page });

function Page() {
  const { periode } = useStore();
  const [pid, setPid] = useState(periode[0]?.id ?? "");
  const [ranking, setRanking] = useState<RankingInstitusi[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!pid) {
      setRanking([]);
      return;
    }

    let mounted = true;
    setError(null);
    void api.ranking(pid)
      .then((items) => {
        if (mounted) setRanking(items);
      })
      .catch((err) => {
        if (mounted) {
          setRanking([]);
          setError(toFriendlyError(err));
        }
      });

    return () => {
      mounted = false;
    };
  }, [pid]);

  const pg = usePagination(ranking);

  const ket = (n: number) => n >= 85 ? "Sangat Baik" : n >= 75 ? "Baik" : n >= 65 ? "Cukup" : "Perlu Peningkatan";

  return (
    <>
      <PageHeader title="Ranking Institusi" description="Peringkat berdasarkan rata-rata nilai akhir peserta." />
      <Card className="p-4 mb-4">
        <div className="max-w-sm">
          <label className="text-xs text-muted-foreground">Periode Magang</label>
          <Select value={pid} onValueChange={setPid}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{periode.map(p => <SelectItem key={p.id} value={p.id}>{p.nama}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </Card>

      {ranking.length === 0 ? (
        <Card className="p-10 text-center bg-[#F6E7BC]/30">
          <Trophy className="h-10 w-10 mx-auto text-[#0992C2] mb-3" />
          <div className="font-medium text-[#0B2D72]">{error ? "Ranking belum dapat ditampilkan." : "Data ranking belum tersedia untuk periode ini."}</div>
          <div className="text-sm text-muted-foreground mt-1">{error ?? "Data akan tersedia setelah peserta memiliki nilai akhir."}</div>
        </Card>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="w-20">Peringkat</TableHead>
                <TableHead>Institusi</TableHead><TableHead>Total Peserta</TableHead>
                <TableHead>Rata-rata Nilai</TableHead><TableHead>Performa</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {pg.pageItems.map((r, idx) => {
                  const i = (pg.page - 1) * pg.pageSize + idx;
                  return (
                  <TableRow key={r.institusi}>
                    <TableCell>
                      <div className={`inline-flex h-8 w-8 items-center justify-center rounded-full font-bold ${i === 0 ? "bg-[#0AC4E0] text-white" : i === 1 ? "bg-[#0992C2] text-white" : i === 2 ? "bg-[#0B2D72] text-white" : "bg-muted"}`}>{i + 1}</div>
                    </TableCell>
                    <TableCell className="font-medium">{r.institusi}</TableCell>
                    <TableCell>{r.total}</TableCell>
                    <TableCell className="font-bold text-[#0B2D72]">{r.rata}</TableCell>
                    <TableCell>{ket(r.rata)}</TableCell>
                  </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
          <DataPagination {...pg} />
        </Card>
      )}
    </>
  );
}
