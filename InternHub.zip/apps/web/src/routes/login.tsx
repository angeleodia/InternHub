import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Building2 } from "lucide-react";
import { toast } from "sonner";
import type { Role } from "@/lib/api";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
  const { login } = useStore();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    if (!email || !password) { setErr("Email dan password wajib diisi."); return; }
    setLoading(true);
    const { error, role } = await login(email, password);
    setLoading(false);
    if (error || !role) { setErr(error ?? "Gagal masuk."); return; }
    toast.success("Berhasil masuk");
    navigate({ to: `/${role}/dashboard` as any });
  };

  const fillDemo = async (r: Role) => {
    const creds = r === "admin"
      ? { email: "admin@internhub.test", password: "admin123" }
      : r === "mentor"
      ? { email: "andi@internhub.test", password: "mentor123" }
      : { email: "rizky@student.ui.ac.id", password: "user123" };
    setEmail(creds.email);
    setPassword(creds.password);
    setErr(null);
    setLoading(true);
    const { error, role } = await login(creds.email, creds.password);
    setLoading(false);
    if (error || !role) { setErr(error ?? "Gagal masuk."); return; }
    toast.success(`Berhasil masuk sebagai ${roleLabel(role)}`);
    navigate({ to: `/${role}/dashboard` as any });
  };

  return (
    <div className="min-h-screen grid md:grid-cols-2">
      <div className="hidden md:flex flex-col justify-between bg-[#0B2D72] text-white p-10 relative overflow-hidden">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#0992C2]"><Building2 className="h-6 w-6" /></div>
          <div>
            <div className="font-semibold">InternHub</div>
            <div className="text-xs text-white/60">Sistem Informasi Magang</div>
          </div>
        </div>
        <div className="relative z-10">
          <h2 className="text-3xl font-bold leading-tight">Kelola program magang<br />dengan rapi & terukur.</h2>
          <p className="mt-4 text-white/70 max-w-md">Monitor absensi, laporan kegiatan, evaluasi mentor, dan rekap nilai akhir peserta magang dalam satu platform.</p>
        </div>
        <div className="text-xs text-white/40">© 2026 InternHub</div>
        <div className="absolute -right-32 -bottom-32 w-96 h-96 rounded-full bg-[#0992C2]/30 blur-3xl" />
        <div className="absolute -right-10 top-20 w-72 h-72 rounded-full bg-[#0AC4E0]/20 blur-3xl" />
      </div>

      <div className="flex items-center justify-center p-6 md:p-10 bg-[#F6E7BC]/40">
        <Card className="w-full max-w-md p-8 shadow-lg">
          <div className="md:hidden flex items-center gap-2 mb-6">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0B2D72]"><Building2 className="h-5 w-5 text-white" /></div>
            <div className="font-semibold text-[#0B2D72]">InternHub</div>
          </div>
          <h1 className="text-2xl font-bold text-[#0B2D72]">Masuk</h1>
          <p className="text-sm text-muted-foreground mb-6">Silakan masuk untuk melanjutkan ke dashboard.</p>

          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="nama@perusahaan.com" value={email} onChange={e => setEmail(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pwd">Password</Label>
              <Input id="pwd" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />
            </div>

            {err && <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-md px-3 py-2">{err}</div>}

            <Button type="submit" disabled={loading} className="w-full bg-[#0B2D72] hover:bg-[#0B2D72]/90">
              {loading ? "Memeriksa..." : "Masuk"}
            </Button>
          </form>

          <div className="mt-6 border-t pt-4">
            <div className="text-xs text-muted-foreground mb-2">Akun contoh cepat:</div>
            <div className="grid grid-cols-3 gap-2">
              <Button variant="outline" size="sm" disabled={loading} onClick={() => void fillDemo("admin")}>Admin</Button>
              <Button variant="outline" size="sm" disabled={loading} onClick={() => void fillDemo("mentor")}>Mentor</Button>
              <Button variant="outline" size="sm" disabled={loading} onClick={() => void fillDemo("user")}>Peserta</Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

function roleLabel(role: Role) {
  if (role === "admin") return "Admin";
  if (role === "mentor") return "Mentor";
  return "Peserta";
}
