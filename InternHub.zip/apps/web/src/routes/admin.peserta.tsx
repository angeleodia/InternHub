import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/StatusBadge";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { useMemo, useState } from "react";
import { Plus, Pencil, Trash2, Eye, Search } from "lucide-react";
import { toast } from "sonner";
import type { Peserta, StatusMagang } from "@/lib/api";

export const Route = createFileRoute("/admin/peserta")({ component: Page });

const empty: Omit<Peserta, "id"> = {
  nama: "", email: "", telepon: "", institusiId: "", programStudi: "", periodeId: "", mentorId: "", status: "Aktif",
};

function Page() {
  const { peserta, institusi, periode, mentor, addPeserta, updatePeserta, deletePeserta } = useStore();
  const [q, setQ] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("semua");
  const [filterPeriode, setFilterPeriode] = useState<string>("semua");

  const [openForm, setOpenForm] = useState(false);
  const [editing, setEditing] = useState<Peserta | null>(null);
  const [form, setForm] = useState<Omit<Peserta, "id">>(empty);
  const [delId, setDelId] = useState<string | null>(null);
  const [detail, setDetail] = useState<Peserta | null>(null);

  const filtered = useMemo(() => peserta.filter(p => {
    const matchQ = !q || p.nama.toLowerCase().includes(q.toLowerCase()) || p.email.toLowerCase().includes(q.toLowerCase());
    const matchS = filterStatus === "semua" || p.status === filterStatus;
    const matchP = filterPeriode === "semua" || p.periodeId === filterPeriode;
    return matchQ && matchS && matchP;
  }), [peserta, q, filterStatus, filterPeriode]);
  const pg = usePagination(filtered);

  const openAdd = () => { setEditing(null); setForm(empty); setOpenForm(true); };
  const openEdit = (p: Peserta) => { setEditing(p); const { id, ...rest } = p; setForm(rest); setOpenForm(true); };

  const submit = async () => {
    if (!form.nama || !form.email || !form.institusiId || !form.periodeId || !form.mentorId) {
      toast.error("Lengkapi semua field wajib."); return;
    }
    const err = editing ? await updatePeserta(editing.id, form) : await addPeserta(form);
    if (err) { toast.error(err); return; }
    toast.success(editing ? "Peserta diperbarui." : "Peserta ditambahkan.");
    setOpenForm(false);
  };

  const nm = (id: string, list: { id: string; nama: string }[]) => list.find(x => x.id === id)?.nama ?? "-";

  return (
    <>
      <PageHeader title="Data Peserta" description="Kelola data peserta magang."
        actions={<Button onClick={openAdd} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90"><Plus className="h-4 w-4 mr-2" />Tambah Peserta</Button>}
      />

      <Card className="p-4 mb-4">
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Cari nama / email…" className="pl-9" value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Status</SelectItem>
              <SelectItem value="Aktif">Aktif</SelectItem>
              <SelectItem value="Selesai">Selesai</SelectItem>
              <SelectItem value="Nonaktif">Nonaktif</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterPeriode} onValueChange={setFilterPeriode}>
            <SelectTrigger><SelectValue placeholder="Periode" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="semua">Semua Periode</SelectItem>
              {periode.map(p => <SelectItem key={p.id} value={p.id}>{p.nama}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nama</TableHead>
                <TableHead>Institusi</TableHead>
                <TableHead>Program Studi</TableHead>
                <TableHead>Periode</TableHead>
                <TableHead>Mentor</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-10">Tidak ada data.</TableCell></TableRow>}
              {pg.pageItems.map(p => (
                <TableRow key={p.id}>
                  <TableCell>
                    <div className="font-medium">{p.nama}</div>
                    <div className="text-xs text-muted-foreground">{p.email}</div>
                  </TableCell>
                  <TableCell>{nm(p.institusiId, institusi)}</TableCell>
                  <TableCell>{p.programStudi}</TableCell>
                  <TableCell>{nm(p.periodeId, periode)}</TableCell>
                  <TableCell>{nm(p.mentorId, mentor)}</TableCell>
                  <TableCell><StatusBadge status={p.status} /></TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => setDetail(p)}><Eye className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => openEdit(p)}><Pencil className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => setDelId(p.id)}><Trash2 className="h-4 w-4 text-red-600" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>

      <Dialog open={openForm} onOpenChange={setOpenForm}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Peserta" : "Tambah Peserta"}</DialogTitle>
            <DialogDescription>Lengkapi data peserta magang di bawah ini.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Nama"><Input value={form.nama} onChange={e => setForm({ ...form, nama: e.target.value })} /></Field>
            <Field label="Email"><Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></Field>
            <Field label="Nomor Telepon"><Input value={form.telepon} onChange={e => setForm({ ...form, telepon: e.target.value })} /></Field>
            <Field label="Program Studi"><Input value={form.programStudi} onChange={e => setForm({ ...form, programStudi: e.target.value })} /></Field>
            <Field label="Institusi">
              <Select value={form.institusiId} onValueChange={v => setForm({ ...form, institusiId: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih institusi" /></SelectTrigger>
                <SelectContent>{institusi.map(i => <SelectItem key={i.id} value={i.id}>{i.nama}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Periode">
              <Select value={form.periodeId} onValueChange={v => setForm({ ...form, periodeId: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih periode" /></SelectTrigger>
                <SelectContent>{periode.map(p => <SelectItem key={p.id} value={p.id}>{p.nama}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Mentor">
              <Select value={form.mentorId} onValueChange={v => setForm({ ...form, mentorId: v })}>
                <SelectTrigger><SelectValue placeholder="Pilih mentor" /></SelectTrigger>
                <SelectContent>{mentor.map(m => <SelectItem key={m.id} value={m.id}>{m.nama}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Status">
              <Select value={form.status} onValueChange={v => setForm({ ...form, status: v as StatusMagang })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Aktif">Aktif</SelectItem>
                  <SelectItem value="Selesai">Selesai</SelectItem>
                  <SelectItem value="Nonaktif">Nonaktif</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenForm(false)}>Batal</Button>
            <Button onClick={submit} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Peserta?</AlertDialogTitle>
            <AlertDialogDescription>Tindakan ini akan menghapus data peserta dari daftar.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={async () => {
              if (delId) {
                const err = await deletePeserta(delId);
                if (err) toast.error(err); else toast.success("Peserta dihapus.");
              }
              setDelId(null);
            }}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Detail Peserta</DialogTitle></DialogHeader>
          {detail && (
            <div className="space-y-2 text-sm">
              <Row label="Nama" value={detail.nama} />
              <Row label="Email" value={detail.email} />
              <Row label="Telepon" value={detail.telepon} />
              <Row label="Institusi" value={nm(detail.institusiId, institusi)} />
              <Row label="Program Studi" value={detail.programStudi} />
              <Row label="Periode" value={nm(detail.periodeId, periode)} />
              <Row label="Mentor" value={nm(detail.mentorId, mentor)} />
              <Row label="Status" value={<StatusBadge status={detail.status} />} />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-1.5"><Label className="text-xs">{label}</Label>{children}</div>;
}
function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return <div className="grid grid-cols-3 gap-2"><div className="text-muted-foreground">{label}</div><div className="col-span-2 font-medium">{value}</div></div>;
}
