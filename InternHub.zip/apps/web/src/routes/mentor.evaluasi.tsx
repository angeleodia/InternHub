import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import { usePagination, DataPagination } from "@/components/DataPagination";
import { useState } from "react";
import { toast } from "sonner";
import type { Peserta } from "@/lib/api";

export const Route = createFileRoute("/mentor/evaluasi")({ component: Page });

function Page() {
  const { user, peserta, evaluasi, addEvaluasi } = useStore();
  const bimbingan = peserta.filter(p => p.mentorId === user?.mentorId);
  const pg = usePagination(bimbingan);
  const [open, setOpen] = useState<Peserta | null>(null);
  const [nilai, setNilai] = useState("85");
  const [komentar, setKomentar] = useState("");

  const ev = (id: string) => evaluasi.find(e => e.pesertaId === id);

  const openForm = (p: Peserta) => {
    if (p.status !== "Selesai") {
      toast.error("Evaluasi akhir tersedia setelah periode magang selesai.");
      return;
    }
    setOpen(p);
    setNilai("85");
    setKomentar("");
  };

  const submit = async () => {
    if (!open) return;
    if (!komentar.trim()) { toast.error("Komentar wajib diisi."); return; }
    const n = parseInt(nilai, 10);
    const err = await addEvaluasi({ pesertaId: open.id, mentorId: user!.mentorId!, nilai: n, komentar, tanggal: new Date().toISOString().slice(0,10) });
    if (err) { toast.error(err); return; }
    toast.success("Evaluasi tersimpan.");
    setOpen(null);
  };

  return (
    <>
      <PageHeader title="Evaluasi Akhir" description="Berikan evaluasi akhir untuk peserta bimbingan yang sudah menyelesaikan periode magang." />
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Nama</TableHead><TableHead>Status</TableHead>
              <TableHead>Nilai Evaluasi</TableHead><TableHead>Tanggal</TableHead><TableHead>Aksi</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {pg.pageItems.map(p => {
                const e = ev(p.id);
                const selesai = p.status === "Selesai";
                return (
                  <TableRow key={p.id}>
                    <TableCell className="font-medium">{p.nama}</TableCell>
                    <TableCell><StatusBadge status={p.status} /></TableCell>
                    <TableCell>{e?.nilai ?? "-"}</TableCell>
                    <TableCell>{e?.tanggal ?? "-"}</TableCell>
                    <TableCell>
                      {e ? <span className="text-xs text-muted-foreground italic">Sudah dievaluasi</span>
                        : !selesai ? <span className="text-xs text-muted-foreground italic">Tersedia setelah periode selesai</span>
                        : <Button size="sm" variant="outline" onClick={() => openForm(p)}>Beri Evaluasi</Button>}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        <DataPagination {...pg} />
      </Card>

      <Dialog open={!!open} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Evaluasi Akhir — {open?.nama}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5"><Label>Nilai Evaluasi (1-100)</Label><Input type="number" min={1} max={100} value={nilai} onChange={e => setNilai(e.target.value)} /></div>
            <div className="space-y-1.5"><Label>Komentar Akhir</Label><Textarea value={komentar} onChange={e => setKomentar(e.target.value)} placeholder="Catatan evaluasi performa peserta…" /></div>
            <div className="text-xs text-muted-foreground">Tanggal evaluasi: {new Date().toISOString().slice(0,10)}</div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(null)}>Batal</Button>
            <Button onClick={submit} className="bg-[#0B2D72] hover:bg-[#0B2D72]/90">Simpan Evaluasi</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
