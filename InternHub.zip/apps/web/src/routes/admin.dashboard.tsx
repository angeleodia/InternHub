import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppLayout";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { DeadlineBadge } from "@/components/TugasBits";
import { deadlineInfo, formatTanggal } from "@/lib/tugas";
import {
  Users,
  GraduationCap,
  Building2,
  ClipboardCheck,
  ClipboardList,
  CheckCircle2,
  AlertTriangle,
  RefreshCcw,
  Award,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import {
  BarChart,
  Bar,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

export const Route = createFileRoute("/admin/dashboard")({ component: Page });

function Stat({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: any;
  label: string;
  value: string | number;
  accent?: string;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-muted-foreground">{label}</div>
          <div className="text-2xl font-bold text-[#0B2D72] mt-1">{value}</div>
        </div>
        <div
          className={`h-10 w-10 rounded-lg flex items-center justify-center ${accent ?? "bg-[#0992C2]/10 text-[#0992C2]"}`}
        >
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}

function Page() {
  const { peserta, mentor, institusi, periode, absensi, tugas, getNilaiAkhir } = useStore();
  const today = new Date().toISOString().slice(0, 10);

  const aktif = peserta.filter((p) => p.status === "Aktif");
  const hadirHariIni = absensi.filter((a) => a.tanggal === today).length;
  const persenHadir = aktif.length ? Math.round((hadirHariIni / aktif.length) * 100) : 0;

  const berjalan = tugas.filter((t) => t.status !== "Selesai");
  const tugasRevisi = tugas.filter((t) => t.status === "Revisi").length;
  const tugasSelesai = tugas.filter((t) => t.status === "Selesai").length;
  const mendesak = berjalan
    .map((t) => ({ t, info: deadlineInfo(t.tanggalSelesai, t.status) }))
    .filter((x) => x.info && x.info.tone !== "netral")
    .sort((a, b) => a.t.tanggalSelesai.localeCompare(b.t.tanggalSelesai));

  const nilaiAkhirSemua = peserta.map((p) => getNilaiAkhir(p.id).akhir).filter((n) => n > 0);
  const avgNilai = nilaiAkhirSemua.length
    ? Math.round(nilaiAkhirSemua.reduce((a, b) => a + b, 0) / nilaiAkhirSemua.length)
    : 0;

  const perPeriode = periode.map((per) => {
    const ps = peserta.filter((p) => p.periodeId === per.id);
    const nilai = ps.map((p) => getNilaiAkhir(p.id).akhir).filter((n) => n > 0);
    return {
      nama: per.nama.replace("Periode ", ""),
      peserta: ps.length,
      rata: nilai.length ? Math.round(nilai.reduce((a, b) => a + b, 0) / nilai.length) : 0,
    };
  });

  const pieData = [
    {
      name: "Ditugaskan",
      value: tugas.filter((t) => t.status === "Ditugaskan").length,
      color: "#94a3b8",
    },
    {
      name: "Dikerjakan",
      value: tugas.filter((t) => t.status === "Dikerjakan").length,
      color: "#0992C2",
    },
    { name: "Perlu Revisi", value: tugasRevisi, color: "#f59e0b" },
    { name: "Selesai", value: tugasSelesai, color: "#10b981" },
  ];
  const namaMentor = (id: string) => mentor.find((m) => m.id === id)?.nama ?? "-";
  const namaPeserta = (id: string) => peserta.find((p) => p.id === id)?.nama ?? "-";

  return (
    <>
      <PageHeader
        title="Ringkasan Admin"
        description="Pantau kondisi program magang secara keseluruhan."
      />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat icon={Users} label="Peserta Aktif" value={aktif.length} />
        <Stat
          icon={GraduationCap}
          label="Total Mentor"
          value={mentor.length}
          accent="bg-[#0B2D72]/10 text-[#0B2D72]"
        />
        <Stat
          icon={Building2}
          label="Total Institusi"
          value={institusi.length}
          accent="bg-[#0AC4E0]/15 text-[#076e7f]"
        />
        <Stat
          icon={ClipboardCheck}
          label="Kehadiran Hari Ini"
          value={`${persenHadir}%`}
          accent="bg-amber-50 text-amber-600"
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mt-4">
        <Stat
          icon={ClipboardList}
          label="Tugas Berjalan"
          value={berjalan.length}
          accent="bg-[#0992C2]/15 text-[#0992C2]"
        />
        <Stat
          icon={RefreshCcw}
          label="Perlu Revisi"
          value={tugasRevisi}
          accent="bg-amber-50 text-amber-600"
        />
        <Stat
          icon={CheckCircle2}
          label="Tugas Selesai"
          value={tugasSelesai}
          accent="bg-emerald-50 text-emerald-600"
        />
        <Stat
          icon={AlertTriangle}
          label="Mendekati / Lewat Deadline"
          value={mendesak.length}
          accent="bg-red-50 text-red-600"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3 mt-6">
        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="font-semibold text-[#0B2D72]">Ringkasan Performa per Periode</div>
              <div className="text-xs text-muted-foreground">Rata-rata nilai akhir peserta</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted-foreground">Rata-rata Keseluruhan</div>
              <div className="text-xl font-bold text-[#0B2D72] flex items-center gap-1">
                <Award className="h-4 w-4" />
                {avgNilai}
              </div>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={perPeriode}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="nama" tick={{ fontSize: 12 }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="rata" fill="#0992C2" radius={[6, 6, 0, 0]} name="Rata-rata Nilai" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <div className="font-semibold text-[#0B2D72] mb-1">Distribusi Status Tugas</div>
          <div className="text-xs text-muted-foreground mb-2">Total {tugas.length} tugas</div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  nameKey="name"
                  outerRadius={70}
                  innerRadius={40}
                >
                  {pieData.map((d, i) => (
                    <Cell key={i} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2 mt-6">
        <Card className="p-5">
          <div className="font-semibold text-[#0B2D72] mb-4">
            Kehadiran Hari Ini per Peserta Aktif
          </div>
          <div className="space-y-3">
            {aktif.slice(0, 8).map((p) => {
              const sudah = absensi.some((a) => a.pesertaId === p.id && a.tanggal === today);
              return (
                <div key={p.id} className="flex items-center gap-3">
                  <div className="w-40 text-sm truncate">{p.nama}</div>
                  <Progress value={sudah ? 100 : 0} className="flex-1 h-2" />
                  <div className="w-24 text-right text-xs text-muted-foreground">
                    {sudah ? "Sudah Absen" : "Belum"}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-start justify-between gap-3 mb-4">
            <div>
              <div className="font-semibold text-[#0B2D72]">Tugas Mendekati / Lewat Deadline</div>
              <div className="text-xs text-muted-foreground">Perlu perhatian mentor & peserta</div>
            </div>
            <Button asChild size="sm" variant="outline">
              <Link to="/admin/tugas">Pantau Tugas</Link>
            </Button>
          </div>
          {mendesak.length === 0 ? (
            <div className="rounded-md border border-emerald-200 bg-emerald-50 px-3 py-4 text-sm text-emerald-700">
              Tidak ada tugas yang mendekati atau melewati deadline.
            </div>
          ) : (
            <div className="space-y-2">
              {mendesak.slice(0, 8).map(({ t }) => (
                <div
                  key={t.id}
                  className="flex items-center justify-between gap-3 rounded-md border px-3 py-2"
                >
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">{t.judul}</div>
                    <div className="truncate text-xs text-muted-foreground">
                      {namaPeserta(t.pesertaId)} • {namaMentor(t.mentorId)} •{" "}
                      {formatTanggal(t.tanggalSelesai)}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <DeadlineBadge tugas={t} />
                    <StatusBadge status={t.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
