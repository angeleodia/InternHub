import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

import {
  api,
  toFriendlyError,
  type Akun,
  type Absensi,
  type CurrentUser,
  type Evaluasi,
  type Institusi,
  type Laporan,
  type LaporanInput,
  type LaporanUpdateInput,
  type Mentor,
  type Periode,
  type Peserta,
  type ProgresInput,
  type Role,
  type StatusLaporan,
  type StatusTugas,
  type Tugas,
  type TugasInput,
} from "./api";

type ActionResult = Promise<string | null>;

interface StoreCtx {
  user: CurrentUser | null;
  sessionReady: boolean;
  dataReady: boolean;
  dataError: string | null;
  refreshData: () => Promise<void>;
  login: (email: string, password: string) => Promise<{ error: string | null; role?: Role }>;
  logout: () => void;

  institusi: Institusi[];
  periode: Periode[];
  mentor: Mentor[];

  peserta: Peserta[];
  addPeserta: (p: Omit<Peserta, "id">) => ActionResult;
  updatePeserta: (id: string, p: Partial<Peserta>) => ActionResult;
  deletePeserta: (id: string) => ActionResult;

  akun: Akun[];
  addAkun: (a: Omit<Akun, "id" | "dibuat">) => ActionResult;
  updateAkun: (id: string, a: Partial<Akun>) => ActionResult;
  toggleAkunStatus: (id: string) => ActionResult;
  deleteAkun: (id: string) => ActionResult;

  absensi: Absensi[];
  addAbsensi: (pesertaId: string) => ActionResult;

  laporan: Laporan[];
  addLaporan: (l: LaporanInput) => ActionResult;
  updateLaporan: (id: string, l: LaporanUpdateInput) => ActionResult;
  reviewLaporan: (
    id: string,
    status: StatusLaporan,
    nilai?: number,
    komentar?: string,
  ) => ActionResult;

  tugas: Tugas[];
  addTugas: (t: TugasInput) => ActionResult;
  updateTugas: (id: string, t: Partial<TugasInput>) => ActionResult;
  reviewTugas: (id: string, status: StatusTugas, nilai?: number, komentar?: string) => ActionResult;
  deleteTugas: (id: string) => ActionResult;
  setSubTugasStatus: (id: string, status: StatusTugas) => ActionResult;
  addProgres: (tugasId: string, p: ProgresInput) => ActionResult;
  deleteProgres: (id: string) => ActionResult;

  evaluasi: Evaluasi[];
  addEvaluasi: (e: Omit<Evaluasi, "id">) => ActionResult;

  getNilaiAkhir: (pesertaId: string) => {
    kehadiran: number;
    tugas: number;
    evaluasi: number;
    akhir: number;
  };
}

const Ctx = createContext<StoreCtx | null>(null);
const SESSION_KEY = "internhub-current-user";

const isRole = (value: unknown): value is Role =>
  value === "admin" || value === "mentor" || value === "user";

const readStoredUser = (): CurrentUser | null => {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<CurrentUser>;
    if (!isRole(parsed.role) || !parsed.nama || !parsed.email) return null;
    return {
      role: parsed.role,
      nama: parsed.nama,
      email: parsed.email,
      pesertaId: parsed.pesertaId,
      mentorId: parsed.mentorId,
    };
  } catch {
    return null;
  }
};

const saveStoredUser = (nextUser: CurrentUser | null) => {
  if (typeof window === "undefined") return;
  if (nextUser) window.localStorage.setItem(SESSION_KEY, JSON.stringify(nextUser));
  else window.localStorage.removeItem(SESSION_KEY);
};

const cleanText = (value?: string) => {
  const next = value?.trim();
  return next ? next : undefined;
};

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [sessionReady, setSessionReady] = useState(false);
  const [dataReady, setDataReady] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);
  const [institusi, setInstitusi] = useState<Institusi[]>([]);
  const [periode, setPeriode] = useState<Periode[]>([]);
  const [mentor, setMentor] = useState<Mentor[]>([]);
  const [peserta, setPeserta] = useState<Peserta[]>([]);
  const [akun, setAkun] = useState<Akun[]>([]);
  const [absensi, setAbsensi] = useState<Absensi[]>([]);
  const [laporan, setLaporan] = useState<Laporan[]>([]);
  const [tugas, setTugas] = useState<Tugas[]>([]);
  const [evaluasi, setEvaluasi] = useState<Evaluasi[]>([]);

  const refreshData = useCallback(async () => {
    const activeUser = readStoredUser();
    if (!activeUser) {
      setDataReady(true);
      setDataError(null);
      return;
    }

    setDataReady(false);
    setDataError(null);
    try {
      const [reference, nextPeserta, nextAkun, nextAbsensi, nextLaporan, nextTugas, nextEvaluasi] =
        await Promise.all([
          api.reference(),
          api.peserta(),
          activeUser.role === "admin" ? api.akun() : Promise.resolve([]),
          api.absensi(),
          api.laporan(),
          api.tugas(),
          api.evaluasi(),
        ]);
      await api.nilai();

      setInstitusi(reference.institusi);
      setPeriode(reference.periode);
      setMentor(reference.mentor);
      setPeserta(nextPeserta);
      setAkun(nextAkun);
      setAbsensi(nextAbsensi);
      setLaporan(nextLaporan);
      setTugas(nextTugas);
      setEvaluasi(nextEvaluasi);
      setDataReady(true);
    } catch (error) {
      setDataError(toFriendlyError(error));
      setDataReady(true);
    }
  }, []);

  useEffect(() => {
    setUser(readStoredUser());
    setSessionReady(true);
    void refreshData();
  }, [refreshData]);

  const login = useCallback(
    async (email: string, password: string): Promise<{ error: string | null; role?: Role }> => {
      if (!email || !password) return { error: "Email dan password wajib diisi." };

      try {
        const result = await api.login({ email, password });
        if (result.error || !result.role || !result.user) {
          return { error: result.error ?? "Email atau password tidak sesuai." };
        }

        setUser(result.user);
        saveStoredUser(result.user);
        await refreshData();
        return { error: null, role: result.role };
      } catch (error) {
        return { error: toFriendlyError(error) };
      }
    },
    [refreshData],
  );

  const logout = useCallback(() => {
    setUser(null);
    saveStoredUser(null);
  }, []);

  const addPeserta: StoreCtx["addPeserta"] = async (p) => {
    try {
      const saved = await api.createPeserta(p);
      setPeserta((items) => [...items, saved].sort((a, b) => a.nama.localeCompare(b.nama)));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const updatePeserta: StoreCtx["updatePeserta"] = async (id, p) => {
    try {
      const saved = await api.updatePeserta(id, p);
      setPeserta((items) => items.map((item) => (item.id === id ? saved : item)));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const deletePeserta: StoreCtx["deletePeserta"] = async (id) => {
    try {
      await api.deletePeserta(id);
      setPeserta((items) => items.filter((item) => item.id !== id));
      setAbsensi((items) => items.filter((item) => item.pesertaId !== id));
      setLaporan((items) => items.filter((item) => item.pesertaId !== id));
      setTugas((items) => items.filter((item) => item.pesertaId !== id));
      setEvaluasi((items) => items.filter((item) => item.pesertaId !== id));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const addAkun: StoreCtx["addAkun"] = async (a) => {
    try {
      const saved = await api.createAkun(a);
      setAkun((items) => [saved, ...items]);
      await refreshData();
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const updateAkun: StoreCtx["updateAkun"] = async (id, a) => {
    try {
      const saved = await api.updateAkun(id, a);
      setAkun((items) => items.map((item) => (item.id === id ? saved : item)));
      await refreshData();
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const toggleAkunStatus: StoreCtx["toggleAkunStatus"] = async (id) => {
    try {
      const saved = await api.toggleAkunStatus(id);
      setAkun((items) => items.map((item) => (item.id === id ? saved : item)));
      await refreshData();
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const deleteAkun: StoreCtx["deleteAkun"] = async (id) => {
    try {
      await api.deleteAkun(id);
      setAkun((items) => items.filter((item) => item.id !== id));
      await refreshData();
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const addAbsensi: StoreCtx["addAbsensi"] = async (pesertaId) => {
    try {
      const saved = await api.createAbsensi({ pesertaId });
      setAbsensi((items) => [saved, ...items]);
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const addLaporan: StoreCtx["addLaporan"] = async (l) => {
    try {
      const saved = await api.createLaporan({
        ...l,
        lampiran: cleanText(l.lampiran),
        lampiranFile: l.lampiranFile,
      });
      setLaporan((items) => [saved, ...items]);
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const updateLaporan: StoreCtx["updateLaporan"] = async (id, l) => {
    try {
      const saved = await api.updateLaporan(id, {
        ...l,
        lampiran: cleanText(l.lampiran),
        lampiranFile: l.lampiranFile,
      });
      setLaporan((items) => items.map((item) => (item.id === id ? saved : item)));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const reviewLaporan: StoreCtx["reviewLaporan"] = async (id, status, nilai, komentar) => {
    try {
      const saved = await api.reviewLaporan(id, {
        status,
        nilai: status === "Approved" ? nilai : undefined,
        komentar: cleanText(komentar),
      });
      setLaporan((items) => items.map((item) => (item.id === id ? saved : item)));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const upsertTugas = (saved: Tugas) =>
    setTugas((items) =>
      items.some((item) => item.id === saved.id)
        ? items.map((item) => (item.id === saved.id ? saved : item))
        : [saved, ...items],
    );

  const addTugas: StoreCtx["addTugas"] = async (t) => {
    try {
      const saved = await api.createTugas(t);
      setTugas((items) => [saved, ...items]);
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const updateTugas: StoreCtx["updateTugas"] = async (id, t) => {
    try {
      upsertTugas(await api.updateTugas(id, t));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const reviewTugas: StoreCtx["reviewTugas"] = async (id, status, nilai, komentar) => {
    try {
      upsertTugas(
        await api.reviewTugas(id, {
          status,
          nilai: status === "Selesai" ? nilai : undefined,
          komentar: cleanText(komentar),
        }),
      );
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const deleteTugas: StoreCtx["deleteTugas"] = async (id) => {
    try {
      await api.deleteTugas(id);
      setTugas((items) => items.filter((item) => item.id !== id));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const setSubTugasStatus: StoreCtx["setSubTugasStatus"] = async (id, status) => {
    try {
      upsertTugas(await api.reviewSubTugas(id, status));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const addProgres: StoreCtx["addProgres"] = async (tugasId, p) => {
    try {
      upsertTugas(await api.createProgres(tugasId, p));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const deleteProgres: StoreCtx["deleteProgres"] = async (id) => {
    try {
      upsertTugas(await api.deleteProgres(id));
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const addEvaluasi: StoreCtx["addEvaluasi"] = async (e) => {
    try {
      const saved = await api.createEvaluasi(e);
      setEvaluasi((items) => [saved, ...items]);
      return null;
    } catch (error) {
      return toFriendlyError(error);
    }
  };

  const getNilaiAkhir = useCallback(
    (pesertaId: string) => {
      const target = peserta.find((item) => item.id === pesertaId);
      if (!target) return { kehadiran: 0, tugas: 0, evaluasi: 0, akhir: 0 };

      const totalHari = 20;
      const hadir = absensi.filter((item) => item.pesertaId === pesertaId).length;
      const nilaiKehadiran = Math.min(100, Math.round((hadir / totalHari) * 100));
      const tugasSelesai = tugas.filter(
        (item) => item.pesertaId === pesertaId && item.status === "Selesai" && item.nilai != null,
      );
      const nilaiTugas = tugasSelesai.length
        ? Math.round(
            tugasSelesai.reduce((sum, item) => sum + (item.nilai ?? 0), 0) / tugasSelesai.length,
          )
        : 0;
      const nilaiEvaluasi = evaluasi.find((item) => item.pesertaId === pesertaId)?.nilai ?? 0;
      const akhir = Math.round(nilaiKehadiran * 0.3 + nilaiTugas * 0.3 + nilaiEvaluasi * 0.4);

      return { kehadiran: nilaiKehadiran, tugas: nilaiTugas, evaluasi: nilaiEvaluasi, akhir };
    },
    [peserta, absensi, tugas, evaluasi],
  );

  const value = useMemo<StoreCtx>(
    () => ({
      user,
      sessionReady,
      dataReady,
      dataError,
      refreshData,
      login,
      logout,
      institusi,
      periode,
      mentor,
      peserta,
      addPeserta,
      updatePeserta,
      deletePeserta,
      akun,
      addAkun,
      updateAkun,
      toggleAkunStatus,
      deleteAkun,
      absensi,
      addAbsensi,
      laporan,
      addLaporan,
      updateLaporan,
      reviewLaporan,
      tugas,
      addTugas,
      updateTugas,
      reviewTugas,
      deleteTugas,
      setSubTugasStatus,
      addProgres,
      deleteProgres,
      evaluasi,
      addEvaluasi,
      getNilaiAkhir,
    }),
    [
      user,
      sessionReady,
      dataReady,
      dataError,
      refreshData,
      login,
      logout,
      institusi,
      periode,
      mentor,
      peserta,
      akun,
      absensi,
      laporan,
      tugas,
      evaluasi,
      getNilaiAkhir,
    ],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const value = useContext(Ctx);
  if (!value) throw new Error("StoreProvider belum terpasang.");
  return value;
}
