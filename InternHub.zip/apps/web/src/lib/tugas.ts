import { API_BASE_URL, type StatusTugas, type Tugas } from "@/lib/api";

export const STATUS_TUGAS: StatusTugas[] = ["Ditugaskan", "Dikerjakan", "Revisi", "Selesai"];

/** URL lampiran: file lokal diberi prefix API, tautan eksternal dibiarkan apa adanya. */
export function attachmentHref(url: string): string {
  return url.startsWith("/uploads/") ? `${API_BASE_URL}${url}` : url;
}

/** Tanggal ramah-baca, mis. "8 Jun 2026". */
export function formatTanggal(value?: string): string {
  if (!value) return "-";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(date);
}

const startOfToday = () => {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
};

export type DeadlineInfo = { text: string; tone: "merah" | "kuning" | "netral" };

/** Info tenggat untuk badge: terlambat / hari ini / H- berapa hari. Tugas Selesai tidak mendesak. */
export function deadlineInfo(tanggalSelesai: string, status: StatusTugas): DeadlineInfo | null {
  if (status === "Selesai") return null;
  const due = new Date(`${tanggalSelesai}T00:00:00`);
  if (Number.isNaN(due.getTime())) return null;
  const diffDays = Math.round((due.getTime() - startOfToday().getTime()) / 86_400_000);
  if (diffDays < 0) return { text: `Terlambat ${Math.abs(diffDays)} hari`, tone: "merah" };
  if (diffDays === 0) return { text: "Jatuh tempo hari ini", tone: "merah" };
  if (diffDays <= 3) return { text: `H-${diffDays}`, tone: "kuning" };
  return { text: `${diffDays} hari lagi`, tone: "netral" };
}

export const deadlineToneClass: Record<DeadlineInfo["tone"], string> = {
  merah: "bg-red-50 text-red-700 border-red-200",
  kuning: "bg-amber-50 text-amber-700 border-amber-200",
  netral: "bg-gray-50 text-gray-600 border-gray-200",
};

/** True jika ada progres baru dari peserta sejak terakhir mentor meninjau (perlu perhatian mentor). */
export function adaProgresBaru(tugas: Tugas): boolean {
  if (!tugas.progres.length) return false;
  const terakhirReview = tugas.reviewedAt ? new Date(tugas.reviewedAt).getTime() : 0;
  return tugas.progres.some((p) => new Date(p.createdAt).getTime() > terakhirReview);
}
