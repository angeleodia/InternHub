export type Role = "admin" | "mentor" | "user";
export type StatusMagang = "Aktif" | "Selesai" | "Nonaktif";
export type StatusLaporan = "Menunggu" | "Approved" | "Rejected";
export type StatusAkun = "Aktif" | "Nonaktif";
export type StatusTugas = "Ditugaskan" | "Dikerjakan" | "Revisi" | "Selesai";
export type TipeLampiran = "File" | "Link";

export interface CurrentUser {
  role: Role;
  nama: string;
  email: string;
  pesertaId?: string;
  mentorId?: string;
}

export interface Institusi {
  id: string;
  nama: string;
}

export interface Periode {
  id: string;
  nama: string;
  mulai: string;
  selesai: string;
  aktif: boolean;
}

export interface Mentor {
  id: string;
  nama: string;
  email: string;
  departemen: string;
  telepon?: string;
}

export interface Peserta {
  id: string;
  nama: string;
  email: string;
  telepon: string;
  institusiId: string;
  programStudi: string;
  periodeId: string;
  mentorId: string;
  status: StatusMagang;
}

export interface Akun {
  id: string;
  nama: string;
  email: string;
  role: Role;
  status: StatusAkun;
  password: string;
  dibuat: string;
  departemen?: string;
  telepon?: string;
}

export interface Absensi {
  id: string;
  pesertaId: string;
  tanggal: string;
  jam: string;
}

export interface Laporan {
  id: string;
  pesertaId: string;
  mentorId: string;
  tanggal: string;
  deskripsi: string;
  lampiran?: string;
  status: StatusLaporan;
  nilai?: number;
  komentar?: string;
}

export type LaporanInput = Omit<Laporan, "id" | "status"> & {
  lampiranFile?: File | null;
};
export type LaporanUpdateInput = Partial<LaporanInput> &
  Partial<Pick<Laporan, "status" | "nilai" | "komentar">>;

export interface TugasLampiran {
  id: string;
  tipe: TipeLampiran;
  url: string;
  nama?: string;
}

export interface TugasProgres {
  id: string;
  tugasId: string;
  pesertaId: string;
  ringkasan: string;
  createdAt: string;
  lampiran: TugasLampiran[];
}

export interface SubTugas {
  id: string;
  tugasId: string;
  judul: string;
  tanggalMulai?: string;
  tanggalSelesai?: string;
  status: StatusTugas;
  urutan: number;
}

export interface Tugas {
  id: string;
  pesertaId: string;
  mentorId: string;
  judul: string;
  deskripsi: string;
  tanggalMulai: string;
  tanggalSelesai: string;
  status: StatusTugas;
  nilai?: number;
  komentar?: string;
  reviewedAt?: string;
  urutan: number;
  subTugas: SubTugas[];
  progres: TugasProgres[];
}

export interface SubTugasInput {
  id?: string;
  judul: string;
  tanggalMulai?: string | null;
  tanggalSelesai?: string | null;
}

export interface TugasInput {
  pesertaId: string;
  judul: string;
  deskripsi: string;
  tanggalMulai: string;
  tanggalSelesai: string;
  subTugas?: SubTugasInput[];
}

export interface LinkLampiranInput {
  url: string;
  nama?: string;
}

export interface ProgresInput {
  ringkasan: string;
  links?: LinkLampiranInput[];
  files?: File[];
}

export interface Evaluasi {
  id: string;
  pesertaId: string;
  mentorId: string;
  nilai: number;
  komentar: string;
  tanggal: string;
}

export interface NilaiAkhir {
  pesertaId?: string;
  kehadiran: number;
  tugas: number;
  evaluasi: number;
  akhir: number;
}

export interface RankingInstitusi {
  institusiId: string;
  institusi: string;
  total: number;
  totalInterns: number;
  rata: number;
  rankPosition: number;
}

export interface ReferenceData {
  institusi: Institusi[];
  periode: Periode[];
  mentor: Mentor[];
}

export interface LoginResult {
  error: string | null;
  role?: Role;
  user?: CurrentUser;
}

const rawBaseUrl = import.meta.env.VITE_API_URL ?? "http://localhost:3000/api";
export const API_BASE_URL = rawBaseUrl.replace(/\/$/, "");
const SESSION_KEY = "internhub-current-user";

function getSessionHeaders() {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    if (!raw) return {};
    const user = JSON.parse(raw) as Partial<CurrentUser>;
    return {
      ...(user.role ? { "x-user-role": user.role } : {}),
      ...(user.email ? { "x-user-email": user.email } : {}),
      ...(user.pesertaId ? { "x-peserta-id": user.pesertaId } : {}),
      ...(user.mentorId ? { "x-mentor-id": user.mentorId } : {}),
    };
  } catch {
    return {};
  }
}

function getErrorMessage(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object") {
    const value = payload as { message?: unknown; error?: unknown };
    if (typeof value.message === "string") return value.message;
    if (Array.isArray(value.message)) return value.message.join(", ");
    if (typeof value.error === "string") return value.error;
  }
  return fallback;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const isForm = options.body instanceof FormData;
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      ...getSessionHeaders(),
      ...(isForm ? {} : { "Content-Type": "application/json" }),
      ...(options.headers ?? {}),
    },
  });

  const text = await response.text();
  let payload: unknown = null;
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = null;
    }
  }

  if (!response.ok) {
    throw new Error(getErrorMessage(payload, "Permintaan belum berhasil diproses."));
  }

  return payload as T;
}

function laporanFormData(body: Partial<LaporanInput>) {
  const form = new FormData();
  for (const [key, value] of Object.entries(body)) {
    if (key === "lampiranFile") continue;
    if (value != null) form.append(key, String(value));
  }
  if (body.lampiranFile) form.append("lampiranFile", body.lampiranFile);
  return form;
}

export function toFriendlyError(error: unknown) {
  if (error instanceof TypeError) {
    return "Layanan data belum terhubung. Pastikan layanan InternHub sudah berjalan, lalu coba lagi.";
  }
  if (error instanceof Error) return error.message;
  return "Terjadi kendala. Silakan coba lagi.";
}

export const api = {
  login(body: { email: string; password: string }) {
    return request<LoginResult>("/auth/login", {
      method: "POST",
      body: JSON.stringify(body),
    });
  },
  reference() {
    return request<ReferenceData>("/reference");
  },
  peserta() {
    return request<Peserta[]>("/peserta");
  },
  createPeserta(body: Omit<Peserta, "id">) {
    return request<Peserta>("/peserta", {
      method: "POST",
      body: JSON.stringify(body),
    });
  },
  updatePeserta(id: string, body: Partial<Peserta>) {
    return request<Peserta>(`/peserta/${id}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    });
  },
  deletePeserta(id: string) {
    return request<{ success: boolean }>(`/peserta/${id}`, { method: "DELETE" });
  },
  akun() {
    return request<Akun[]>("/akun");
  },
  createAkun(body: Omit<Akun, "id" | "dibuat">) {
    return request<Akun>("/akun", {
      method: "POST",
      body: JSON.stringify(body),
    });
  },
  updateAkun(id: string, body: Partial<Akun>) {
    return request<Akun>(`/akun/${id}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    });
  },
  toggleAkunStatus(id: string) {
    return request<Akun>(`/akun/${id}/toggle-status`, { method: "PATCH" });
  },
  deleteAkun(id: string) {
    return request<{ success: boolean }>(`/akun/${id}`, { method: "DELETE" });
  },
  absensi() {
    return request<Absensi[]>("/absensi");
  },
  createAbsensi(body: { pesertaId: string; tanggal?: string }) {
    return request<Absensi>("/absensi", {
      method: "POST",
      body: JSON.stringify(body),
    });
  },
  laporan() {
    return request<Laporan[]>("/laporan");
  },
  createLaporan(body: LaporanInput) {
    return request<Laporan>("/laporan", {
      method: "POST",
      body: laporanFormData(body),
    });
  },
  updateLaporan(id: string, body: LaporanUpdateInput) {
    return request<Laporan>(`/laporan/${id}`, {
      method: "PATCH",
      body: laporanFormData(body),
    });
  },
  reviewLaporan(id: string, body: { status: StatusLaporan; nilai?: number; komentar?: string }) {
    return request<Laporan>(`/laporan/${id}/review`, {
      method: "PATCH",
      body: JSON.stringify(body),
    });
  },
  tugas() {
    return request<Tugas[]>("/tugas");
  },
  createTugas(body: TugasInput) {
    return request<Tugas>("/tugas", { method: "POST", body: JSON.stringify(body) });
  },
  updateTugas(id: string, body: Partial<TugasInput>) {
    return request<Tugas>(`/tugas/${id}`, { method: "PATCH", body: JSON.stringify(body) });
  },
  reviewTugas(id: string, body: { status: StatusTugas; nilai?: number; komentar?: string }) {
    return request<Tugas>(`/tugas/${id}/review`, { method: "PATCH", body: JSON.stringify(body) });
  },
  deleteTugas(id: string) {
    return request<{ success: boolean }>(`/tugas/${id}`, { method: "DELETE" });
  },
  reviewSubTugas(id: string, status: StatusTugas) {
    return request<Tugas>(`/subtugas/${id}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status }),
    });
  },
  createProgres(tugasId: string, body: ProgresInput) {
    const form = new FormData();
    form.append("ringkasan", body.ringkasan);
    if (body.links?.length) form.append("links", JSON.stringify(body.links));
    for (const file of body.files ?? []) form.append("lampiranFiles", file);
    return request<Tugas>(`/tugas/${tugasId}/progres`, { method: "POST", body: form });
  },
  deleteProgres(id: string) {
    return request<Tugas>(`/tugas/progres/${id}`, { method: "DELETE" });
  },
  evaluasi() {
    return request<Evaluasi[]>("/evaluasi");
  },
  createEvaluasi(body: Omit<Evaluasi, "id">) {
    return request<Evaluasi>("/evaluasi", {
      method: "POST",
      body: JSON.stringify(body),
    });
  },
  nilai() {
    return request<Array<Peserta & { nilai: NilaiAkhir }>>("/nilai");
  },
  ranking(periodeId: string) {
    return request<RankingInstitusi[]>(`/ranking?periodeId=${encodeURIComponent(periodeId)}`);
  },
};
